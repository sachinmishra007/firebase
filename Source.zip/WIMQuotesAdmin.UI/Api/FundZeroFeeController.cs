﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class FundZeroFeeController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IFundZeroFeeLogic _fundZeroFeeLogic;

        public FundZeroFeeController(Domain.Logic.Contracts.IFundZeroFeeLogic fundZeroFeeLogic)
        {
            _fundZeroFeeLogic = fundZeroFeeLogic;
        }

        #endregion

        // GET api/FundZeroFee
        public List<Entities.FundZeroFee> Get()
        {
            return _fundZeroFeeLogic.GetFundZeroFee();
        }


        // GET api/FundZeroFee/GetFund
        [Route("api/FundZeroFee/GetFund/{fundType}")]

        public List<Entities.Fund> GetFund(string fundType)
        {
            return _fundZeroFeeLogic.GetFund(fundType);
        }

        // POST api/FundZeroFee
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void Post([FromBody]Entities.FundZeroFee fundZeroFee, [ModelBinder]IPrincipal user)
        {
            if (fundZeroFee == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundZeroFeeLogic.StageFundZeroFee(fundZeroFee, user.Identity.Name);
        }
        // GET api/FundZeroFee/GetPendingFundZeroFees
        [Route("api/FundZeroFee/GetPendingFundZeroFee")]
        public List<Entities.FundZeroFee> GetPendingFundZeroFees()
        {
            return _fundZeroFeeLogic.GetPendingFundZeroFees();
        }

        [HttpPost]
        [Route("api/FundZeroFee/UpdatePendingStatuses")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingFundTERsUpdateStatus([FromBody]List<Entities.FundZeroFee> fundZeroFee, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (fundZeroFee == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundZeroFeeLogic.PendingFundZeroFeesUpdateStatus(fundZeroFee, user.Identity.Name);
        }

        [HttpPost]
        [Route("api/FundZeroFee/addNewFund")]
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void PendingFundTERsUpdateStatus([FromBody]Entities.FundZeroFee fundZeroFee, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (fundZeroFee == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundZeroFeeLogic.AddNewFund(fundZeroFee, user.Identity.Name);
        }
    }
}