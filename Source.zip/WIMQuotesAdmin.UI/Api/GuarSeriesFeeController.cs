﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class GuarSeriesFeeController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IGuarFee _guarFeeLogic;

        public GuarSeriesFeeController(Domain.Logic.Contracts.IGuarFee guarFeeLogic)
        {
            _guarFeeLogic = guarFeeLogic;
        }

        #endregion

        // GET api/GuarSeriesFee
        public List<Entities.GuarFees> Get(Entities.GuarFeesType? guarFeesType)
        {
            if (!guarFeesType.HasValue)
                return null;

            return _guarFeeLogic.GetGuarFees(guarFeesType.Value);
        }

        // GET api/GuarSeriesFee/Pending
        [Route("api/GuarSeriesFee/Pending")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public List<Entities.GuarFees> GetPendingGuarFees()
        {
            return _guarFeeLogic.GetPendingGuarFees();
        }

        //  POST api/saveGuarFees
        //[HttpPost]
        //[Route("api/GuarSeriesFee/saveGuarFees")]
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void Post([FromBody]Entities.GuarFees guarFees, [ModelBinder]IPrincipal user)
        {
            if (guarFees == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return; 

            _guarFeeLogic.StageGuarFees(guarFees,  user.Identity.Name);
        }


        // POST api/ProductNotes/UpdateStatus
        [HttpPost]
        [Route("api/GuarSeriesFee/UpdatePendingGuarFeeStatus")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingNotesUpdateStatus([FromBody]List<Entities.GuarFees> guarfees, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (guarfees == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _guarFeeLogic.PendingGuarFeesUpdateStatus(guarfees, user.Identity.Name); 
        }
    }
}
