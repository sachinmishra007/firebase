﻿using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;

using WIMQuotesAdmin.Common.Helpers;

namespace WIMQuotesAdmin.UI.Web.ActionResults
{
    public class ExcelResult<TModel> : ActionResult
    {
        private readonly List<TModel> _model;
        private readonly string _fileName;

        public ExcelResult(List<TModel> model, string fileName)
        {
            _model = model;
            _fileName = fileName;
        }

        public void WriteExcelResponse()
        {
            var context = HttpContext.Current;
            context.Response.Clear();

            var excelFile = ExcelHelper.CollectionToExcel(_model);

            context.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            context.Response.AddHeader("content-disposition", "attachment; filename=" + _fileName);
            context.Response.BinaryWrite(excelFile);
            context.Response.End();
        }

        public override void ExecuteResult(ControllerContext context)
        {
            WriteExcelResponse();
        }
    }
}