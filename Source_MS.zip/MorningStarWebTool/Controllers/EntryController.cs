﻿using MorningStarWebTool.SessionAPI;
using MorningStarWebTool.DataLayer.Class;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using MorningStarWebTool.Web.ActionFilters;
using MorningStarWebTool.Common.ApplicationConstant;
using MorningStarWebTool.Model.Domain.Contract;

namespace MorningStarWebTool.Controllers
{
    [RoutePrefix("Entry")]
    [HandleError(ExceptionType = typeof(Exception), View = "Error")]
    [SessionTimeout]
    public class EntryController : Controller
    {
        private static SessionVariable[] _variables = null;
        private static string ApplicationId = null;
        private readonly ISettingLogic _settingLogic = null;
        public EntryController(ISettingLogic settingLogic)
        {
            _settingLogic = settingLogic;
        }

        public ActionResult Index(string AppId)
        {
            try
            {
                ApplicationId = AppId;
                string _sessionKey = Request.QueryString["enterprise"];
                _sessionKey = "765306c0ad5759c3ac6a"; 
                var SessionAPI = new SessionAPI.SessionServiceSoapClient();
                _variables = SessionAPI.GetSessionVariables(_sessionKey);
                if (_variables != null && _variables.Length > 0)
                {
                    //Forms Authentication using Username
                    FormsAuthentication.SetAuthCookie(_variables[0].Value, false);
                    return View();
                }
                else
                {
                    return RedirectToAction("UnauthorizedAccess");
                }
            }
            catch (Exception ecx)
            {
                throw ecx;
            }
        }

        [AuthorizeRoles(Constants.Roles.ALL)]
        public ActionResult LandingPage()
        {
            return View();
        }

        [AuthorizeRoles(Constants.Roles.ALL)]
        public ActionResult FundReport()
        {
            return View();
        }

        [AuthorizeRoles(Constants.Roles.ALL)]
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
            return View();
        }

        [AuthorizeRoles(Constants.Roles.ALL)]
        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            return View();
        }

        [AuthorizeRoles(Constants.Roles.ALL)]
        public ActionResult call_fundreport()
        {
            return View();
        }

        [AuthorizeRoles(Constants.Roles.ALL)]
        public ActionResult call_xrayreport()
        {
            return View();
        }

        [AuthorizeRoles(Constants.Roles.ALL)]
        public ActionResult ECLoader_FundScreener()
        {
            return View();
        }

        [AuthorizeRoles(Constants.Roles.ALL)]
        public ActionResult ECLoader_XRay()
        {
            return View();
        }

        [AuthorizeRoles(Constants.Roles.ALL)]
        public ActionResult FundScreener()
        {
            return View();
        }

        [AuthorizeRoles(Constants.Roles.ALL)]
        public ActionResult UserInput()
        {
            return View();
        }

        [AuthorizeRoles(Constants.Roles.ALL)]
        public ActionResult UserXrayReportInput()
        {
            return View();
        }

        [HttpGet]
        [AuthorizeRoles(Constants.Roles.ALL)]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult GetBrokerCodeFormSession()
        {
            return Json(_variables, JsonRequestBehavior.AllowGet);

        }

        public ActionResult UnauthorizedAccess()
        {
            if (ApplicationId == null || ApplicationId == "AI" || ApplicationId == string.Empty)
            {
                ViewBag.LoginUrl = _settingLogic.GetApplicationSetting<string>("AI");
            }
            else
            {
                ViewBag.LoginUrl = _settingLogic.GetApplicationSetting<string>("EI");
            }
            return View();
        }

        [HttpPost]
        [ActionName("Closed")]
        public ActionResult UserApplicationClosed()
        {
            FormsAuthentication.SignOut();
            Session.Abandon(); Session.Clear();
            Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookieName, String.Empty)
            {
                Expires = DateTime.Now.AddYears(-1)
            });

            Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", "")
            {
                Expires = DateTime.Now.AddYears(-1)
            });
            return new EmptyResult();
        }
    }
}