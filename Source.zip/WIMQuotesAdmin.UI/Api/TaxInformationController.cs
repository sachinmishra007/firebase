﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class TaxInformationController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.ITaxInformationLogic _taxInformationLogic;

        public TaxInformationController(Domain.Logic.Contracts.ITaxInformationLogic taxInformationLogic)
        {
            _taxInformationLogic = taxInformationLogic;
        }

        #endregion

        // GET api/TaxInformation
        [Route("api/TaxInformation/GetTaxTables")]
        public IEnumerable<Entities.TaxTables>GetTaxTables()
        {
            return _taxInformationLogic.GetTaxTables();
        }

        // GET api/TaxInformation
        [Route("api/TaxInformation/GetTaxInformation")]
        public IEnumerable<Entities.TaxInformation> GetTaxInformation()
        {
            return _taxInformationLogic.GetTaxInformation();
        }

        [Route("api/TaxInformation/SaveTaxBrackets")]
        public void Post([FromBody]Entities.TaxTables taxTables,string userId)
        {
            _taxInformationLogic.SaveTaxBracketsStaging(taxTables,userId);
        }

        [HttpPost]
        [Route("api/TaxInformation/SaveTaxRebates")]
        public void SaveTaxRebates([FromBody]Entities.TaxRebates taxRebates, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (taxRebates == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;
            
            _taxInformationLogic.SaveTaxRebatesStaging(taxRebates, user.Identity.Name);
        }

        [HttpPost]
        [Route("api/TaxInformation/AuthoriseRebates")]
        public void AuthoriseRebates([FromBody]Entities.TaxRebates taxRebates, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            _taxInformationLogic.AuthoriseTaxRebates(taxRebates, user.Identity.Name);
        }

         [HttpPost]
        [Route("api/TaxInformation/AuthoriseTaxBrackets")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingTaxTablesUpdateStatus([FromBody]List<Entities.TaxTables> taxTables, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (taxTables == null || taxTables.Count == 0 || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;
            _taxInformationLogic.UpdatePendingStatus(taxTables,user.Identity.Name);
        }

        [Route("api/TaxInformation/RejectTaxBrackets/{reject=y}")]
       public IEnumerable<Entities.TaxTables> Post(string reject)
        {
           return _taxInformationLogic.RejectTaxTables();
        }

        [Route("api/TaxInformation/GetTaxRebates")]
        public Entities.TaxRebates GetTaxRebates()
        {
           return _taxInformationLogic.GetTaxRebates();
        }

        [Route("api/TaxInformation/RejectRebates")]
        public void RejectRebates()
        {
            _taxInformationLogic.RejectRebates();
        }

        [Route("api/TaxInformation/Pending")]
        public List<Entities.TaxTables> GetPendingTaxTables()
        {
            return _taxInformationLogic.GetPendingTaxTables();
        }
    }
}
