﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorningStarWebTool.Common.ApplicationConstant
{
    public struct Constants
    {
        public struct Roles
        {
            public const string Advisor = "2";
            public const string BrokerHouse = "3";
            public const string ALL = "";
        }
    }
}
