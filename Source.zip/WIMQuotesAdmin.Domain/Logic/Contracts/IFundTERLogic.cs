﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IFundTERLogic
    {
        List<Entities.FundTER> Get(Entities.FundType fundType, string fundCode);
        List<Entities.FundTER> GetPendingFundTERs();
        List<Entities.Fund> GetUnmappedFunds();

        void StageFundTER(Entities.FundTER fundTER, string userId);
        void PendingFundTERsUpdateStatus(List<Entities.FundTER> fundTERs, string userId);
    }
}