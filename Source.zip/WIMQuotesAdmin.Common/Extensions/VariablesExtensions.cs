﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;

namespace WIMQuotesAdmin.Common.Extensions
{
    public static class VariablesExtensions
    {
        #region String Extensions

        /// <summary>
        /// Returns string value as sentence case i.e. "StringName" as "String Name"
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToSentenceCase(this string value)
        {
            return Regex.Replace(value, "(?!^)([A-Z])", " $1");
        }

        /// <summary>
        /// Converts string to Enum value for where T is Enum
        /// </summary>
        /// <typeparam name="T">T : Enum</typeparam>
        public static T ToEnum<T>(this string value) where T : struct
        {
            return (T)Enum.Parse(typeof(T), value, true);
        }

        /// <summary>
        /// Converts array of strings to Enum values for where T is Enum
        /// </summary>
        /// <typeparam name="T">T : Enum</typeparam>
        public static List<T> ToEnumList<T>(this string[] values) where T : struct
        {
            return values.Select(t => t.ToEnum<T>()).ToList();
        }

        /// <summary>
        /// Converts a string to a Guid, return empty Guid if invalid guid
        /// </summary>
        public static Guid ToGuid(this string value)
        {
            Guid guid;
            return Guid.TryParse(value, out guid) ? guid : Guid.Empty;
        }

        /// <summary>
        /// Checks to see if supplied string is within source string, allowing for StringComparison to be used
        /// </summary>
        public static bool Contains(this string source, string toCheck, StringComparison comp)
        {
            return source != null && toCheck != null && source.IndexOf(toCheck, comp) >= 0;
        }

        #endregion

        #region Int Extensions

        /// <summary>
        /// Converts string to Enum value for where T is Enum
        /// </summary>
        /// <typeparam name="T">T : Enum</typeparam>
        public static T ToEnum<T>(this int value) where T : struct
        {
            if (!Enum.IsDefined(typeof (T), value))
                return default(T);

            return (T)Enum.ToObject(typeof(T), value);
        }

        #endregion

        #region Enum Extensions

        /// <summary>
        /// Returns Enum value as sentence case i.e. "EnumValue" as "Enum Value"
        /// </summary>
        public static string ToSentenceCase(this Enum value)
        {
            return ToSentenceCase(value.ToString());
        }

        /// <summary>
        /// Returns Description if set by description attribute for Enum
        /// </summary>
        public static string ToDescription(this Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());

            if (null == fi) 
                return value.ToString();

            object[] attrs = fi.GetCustomAttributes(typeof(DescriptionAttribute), true);

            return attrs.Length > 0 ? ((DescriptionAttribute)attrs[0]).Description : value.ToString();
        }

        #endregion

        #region List Extensions

        public static byte[] ToXmlSerialisedBytes<T>(this List<T> collection)
        {
            string xml;

            XmlDocument xmlDoc = new XmlDocument();
            XmlSerializer xmlSerializer = new XmlSerializer(collection.GetType());

            using (MemoryStream xmlStream = new MemoryStream())
            {
                xmlSerializer.Serialize(xmlStream, collection);
                xmlStream.Position = 0;
                xmlDoc.Load(xmlStream);
                xml = xmlDoc.InnerXml;
            }

            byte[] fileContents = Encoding.UTF8.GetBytes(xml);
            
            return fileContents;
        }

        #endregion

        #region Type Extensions

        public static List<string> PropertyNamesForType(this Type objectType, Type propertyType)
        {
            return (from property in objectType.GetProperties() 
                    let type = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType 
                    where type == propertyType 
                    select property.Name).ToList();
        }

        #endregion
    }
}
