﻿
(function ()
{
    'use strict';

    angular.module('adminApp.services')
        .factory('userAccessReportService', ['$http', function ($http)
        {
            var userAccessReportService = {};

            userAccessReportService.getUserAccessControlReportData = function (dtoReportDetails)
            {
                return $http({ method: 'GET', url: 'api/UserAccessControlReport/Get', params: dtoReportDetails });
            };

            userAccessReportService.getUserRolesReportData = function (dtoReportDetails)
            {
                return $http({ method: 'GET', url: 'api/UserAccessControlReport/GetRoles', params: dtoReportDetails });
            };

            userAccessReportService.getUserRoleCount = function ()
            {
                return $http({ method: 'GET', url: 'api/UserAccessControlReport/GetRoleCounts' });
            };

            return userAccessReportService;
        }]);
})();

    