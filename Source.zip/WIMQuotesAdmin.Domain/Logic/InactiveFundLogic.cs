﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.DataAccess.Repositories.Contracts;
using WIMQuotesAdmin.Domain.Logic.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class InactiveFundLogic : IinactiveFundLogic
    {
        #region Constructor
        private readonly IinactiveFundRepository _inactiveFundRepository;
        public InactiveFundLogic(IinactiveFundRepository inactiveFundRepository)
        {
            _inactiveFundRepository = inactiveFundRepository;
        }
        
        #endregion


        public List<Entities.InactiveFund> GetInactiveFunds()
        {
            return _inactiveFundRepository.GetInactiveFunds();
        }


        public List<Entities.InactiveFund> GetUnmappedFunds()
        {
            return _inactiveFundRepository.GetUnmappedFunds();
        }

        public void AddInactiveFund(Entities.InactiveFund inactiveFund,string userId)
        {
             _inactiveFundRepository.AddInactiveFund(inactiveFund,userId);
        }

        public void DeleteInactiveFund(string fundCode,string userId)
        {
            _inactiveFundRepository.DeleteInactiveFund(fundCode,userId);
        }


      
    }
}
