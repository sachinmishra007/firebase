﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class FundTERRepository : Contracts.IFundTERRepository
    {
        public List<Entities.FundTER> GetFundTERs(Entities.FundType fundType, string fundCode)
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var fundTERs = context.GetFundTERs(Mappings.PortfolioAdminServiceMapping.ToFundType(fundType), fundCode);

                if (fundTERs == null)
                    return null;

                return fundTERs.Select(f => new Entities.FundTER
                {
                    FundCode = f.FundCode,
                    FundName = f.FundName,
                    TotalExpenseRatio = f.TotalExpenseRatio,
                    ModifiedDateTime = f.DateModified
                }).ToList();
            }
        }

        public List<Entities.FundTER> GetPendingFundTERs()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.FundTERStagings
                    .Where(f => f.Status == (int)Entities.StagingStatus.PendingAuthorise)
                    .Select(Mappings.WIMQuotesAdminStagingMapping.FromFundTERStaging).ToList();
            }
        }

        public Entities.FundTER GetPendingFundTER(string fundCode)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.FundTERStagings
                    .Where(f => f.Status == (int)Entities.StagingStatus.PendingAuthorise && f.FundCode == fundCode)
                    .Select(Mappings.WIMQuotesAdminStagingMapping.FromFundTERStaging)
                    .FirstOrDefault();
            }
        }

        public List<Entities.Fund> GetUnmappedFunds()
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var funds = context.GetUnmappedTERFunds();
                return funds == null ? new List<Entities.Fund>() : funds.Select(Mappings.PortfolioAdminServiceMapping.FromFund).ToList();
            }
        }

        public void SaveFundTERToStaging(Entities.FundTER fundTER)
        {
            if (fundTER == null || string.IsNullOrWhiteSpace(fundTER.UserId))
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundIMLs = Mappings.WIMQuotesAdminStagingMapping.ToFundTERStaging(fundTER);

                if (contextFundIMLs == null)
                    return;

                context.FundTERStagings.Add(contextFundIMLs);
                context.SaveChanges();
            }
        }

        public void UpdateFundTERStagingStatus(string fundCode, Entities.StagingStatus status, string userId)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundTERs = context.FundTERStagings
                    .Where(f => f.FundCode == fundCode &&
                                f.Status == (int)Entities.StagingStatus.PendingAuthorise);

                foreach (var contextFundTER in contextFundTERs)
                {
                    contextFundTER.Status = (int)status;
                    contextFundTER.ModifiedUserId = userId;
                    contextFundTER.ModifiedDateTime = DateTime.Now;
                }

                context.SaveChanges();
            }
        }

        public void SaveAuthorisedFundTER(Entities.FundTER fundTER)
        {
            if (fundTER == null)
                return;

            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.SaveFundTER(Mappings.PortfolioAdminServiceMapping.ToFundTER(fundTER));
            }
        }

        public void DeleteAuthorisedFundTER(string fundCode)
        {
            if (String.IsNullOrWhiteSpace(fundCode))
                return;

            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.DeleteFundTER(new PortfolioAdminService.FundTER { FundCode = fundCode });
            }
        }
    }
}

