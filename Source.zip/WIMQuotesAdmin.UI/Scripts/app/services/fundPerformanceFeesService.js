﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('fundPerformanceFeesService', ['$http', function ($http)
        {
            
            var fundPerformanceFeesService = {};

            fundPerformanceFeesService.getAvailableFunds = function ()
            {
                return $http({ url: 'api/FundPerformanceFees/GetAvailableFunds' });
            };

            fundPerformanceFeesService.getFundPerformanceFees = function (fundCode)
            {
                return $http({ url: 'api/FundPerformanceFees/' + fundCode });
            }

            fundPerformanceFeesService.getUnmappedFunds = function ()
            {
                return $http({ url: 'api/FundPerformanceFees/UnmappedFunds' });
            };

            fundPerformanceFeesService.getTimePeriod = function (fundCode)
            {
                return $http({ url: 'api/FundPerformanceFees/TimePeriod/' + fundCode });
            };

            fundPerformanceFeesService.saveFundPerfomanceFees = function (performanceFees, fundCode)
            {
                return $http.post('api/FundPerformanceFees/?fundCode=' + fundCode, performanceFees, fundCode);
            };

            fundPerformanceFeesService.getPendingFundPerformanceFees = function ()
            {
                return $http({ url: 'api/FundPerformanceFees/Pending' });
            };

            fundPerformanceFeesService.updatePendingFundPerformanceFeesStatus = function (fundPerformanceFees)
            {

                return $http.post('api/FundPerformanceFees/UpdatePendingFundPerformanceFeesStatus', fundPerformanceFees);
            }
            return fundPerformanceFeesService;
        }]);
})();

