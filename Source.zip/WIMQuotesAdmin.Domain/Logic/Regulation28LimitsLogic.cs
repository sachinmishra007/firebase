﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class Regulation28LimitsLogic : Contracts.IRegulation28LimitsLogic
    {
        #region Constructor

        private readonly DataAccess.Repositories.Contracts.IRegulation28LimitsRepository _regulation28LimitsRepository;

        public Regulation28LimitsLogic(DataAccess.Repositories.Contracts.IRegulation28LimitsRepository regulation28LimitsRepository)
        {
            _regulation28LimitsRepository = regulation28LimitsRepository;
        }

        #endregion

        public List<Entities.Regulation28Limits> GetRegulation28Limits()
        {
            var limits = _regulation28LimitsRepository.GetRegulation28Limits();
            var pendingLimits = _regulation28LimitsRepository.GetPendingRegulation28Limits();

            if (pendingLimits == null || pendingLimits.Count == 0)
                return limits;

            foreach (var pendingLimit in pendingLimits)
            {
                var limit = limits.FirstOrDefault(f => f.Code == pendingLimit.Code);

                if (limit == null)
                    continue;

                limit.Status = pendingLimit.Status;
                limit.UserId = pendingLimit.UserId;
                limit.ModifiedDateTime = pendingLimit.ModifiedDateTime;
            }

            return limits;
        }

        public void StagingRegulation28Limits(Entities.Regulation28Limits limit, string userId)
        {
            if (limit == null || string.IsNullOrWhiteSpace(userId))
                return;

            limit.Status = Entities.StagingStatus.PendingAuthorise;
            limit.UserId = userId;
            limit.ModifiedDateTime = DateTime.Now;

            _regulation28LimitsRepository.StagingRegulation28Limits(limit);
        }

        public List<Entities.Regulation28Limits> GetPendingRegulation28Limits()
        {
            _regulation28LimitsRepository.GetPendingRegulation28Limits();
        }

        public void PendingRegulation28LimitsUpdateStatus(List<Entities.Regulation28Limits> limits, string userId)
        {
            if (limits == null || limits.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return;

            foreach (var limit in limits)
            {
                switch (limit.Status)
                {
                    case Entities.StagingStatus.Authorise:
                        PendingLimitAuthorise(limit.Code, userId);
                        break;
                    case Entities.StagingStatus.Reject:
                        PendingLimitReject(limit.Code, userId);
                        break;
                }
            }
        }

        #region Private Methods

        private void PendingLimitAuthorise(string fundCode, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            var fundTER = _regulation28LimitsRepository.GetPendingRegulation28Limits(fundCode);

            if (fundTER == null)
                return;

            _regulation28LimitsRepository.SaveAuthorisedLimit(fundTER);
            _regulation28LimitsRepository.UpdateLimitStagingStatus(fundCode, Entities.StagingStatus.Authorise, userId);
        }

        private void PendingLimitReject(string fundCode, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            _regulation28LimitsRepository.UpdateLimitStagingStatus(fundCode, Entities.StagingStatus.Reject, userId);
        }

        #endregion
    }
}
