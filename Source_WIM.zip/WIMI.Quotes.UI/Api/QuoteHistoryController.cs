﻿using System.Collections.Generic;
using System.Web.Http;

using WIMI.Quotes.Common;
using WIMI.Quotes.UI.Web.ActionFilters;

namespace WIMI.Quotes.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class QuoteHistoryController : ApiController
    {
        #region Contructors & DI

        private readonly Model.Domain.Contracts.IQuoteItemLogic _quoteItemLogic;

        public QuoteHistoryController(Model.Domain.Contracts.IQuoteItemLogic quoteItemLogic)
        {
            _quoteItemLogic = quoteItemLogic;
        }

        #endregion

        // GET: api/QuoteHistory/?
        [AuthorizeApiMustBeUser(Constants.Roles.Advisor, "brokerCode")]
        public IEnumerable<Entities.QuoteHistoryItem> Get(string brokerCode, string clientNumber, Entities.QuoteItemStatus status)
        {
            return _quoteItemLogic.GetQuoteHistoryItems(brokerCode, clientNumber, status) ?? new List<Entities.QuoteHistoryItem>();
        }
    }
}
