﻿using System.Collections.Generic;


namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IUserAccessControlReportRepository
    {
        List<Entities.UserAccessControlReport> GetUserAccessControlReport(Entities.UserAccessControlReportDetail detail);
        List<Entities.User> GetUserRolesReport();
    }
}
