﻿namespace WIMQuotesAdmin.Entities
{
    public class Product
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
