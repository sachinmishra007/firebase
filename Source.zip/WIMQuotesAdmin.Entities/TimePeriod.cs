﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Entities
{
    public class TimePeriod
    {
        public int TimePeriodId { get; set; }
        public string TimePeriodDescription { get; set; }
    }
}
