﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('additionController', ['$scope', 'clientService', function ($scope, clientService)
        {
            // Behaviours 

            $scope.init = function (profile)
            {
                
                $scope.quoteItem.additionProfile = profile;

                //clientService.getClientPolicies($scope.application.selectedClient.ClientNumber, $scope.quoteItem.Product.Code)
                //    .success(function (response)
                //    {
                //        $scope.quoteItem.additionProfile.ClientPolicies = response;
                //    });
            };
        }]);
})();