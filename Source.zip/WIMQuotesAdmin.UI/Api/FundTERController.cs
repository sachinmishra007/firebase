﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class FundTERController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IFundTERLogic _fundTERLogic;

        public FundTERController(Domain.Logic.Contracts.IFundTERLogic fundTERLogic)
        {
            _fundTERLogic = fundTERLogic;
        }

        #endregion

        // GET api/FundTER
        public List<Entities.FundTER> Get(Entities.FundType fundType, string fundCode)
        {
            return _fundTERLogic.Get(fundType, fundCode);
        }

        // POST api/FundTER
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void Post([FromBody]Entities.FundTER fundTER, [ModelBinder]IPrincipal user)
        {
            if (fundTER == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundTERLogic.StageFundTER(fundTER, user.Identity.Name);
        }

        // GET: api/FundTER/GetUnmappedFunds
        [Route("api/FundTER/GetUnmappedFunds")]
        public IEnumerable<Entities.Fund> GetUnmappedFunds()
        {
            return _fundTERLogic.GetUnmappedFunds();
        }

        // GET api/FundTER/Pending
        [Route("api/FundTER/Pending")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public List<Entities.FundTER> GetPendingFundTERs()
        {
            return _fundTERLogic.GetPendingFundTERs();
        }

        // POST api/FundTER/UpdatePendingStatuses
        [HttpPost]
        [Route("api/FundTER/UpdatePendingStatuses")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingFundTERsUpdateStatus([FromBody]List<Entities.FundTER> fundTERs, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (fundTERs == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundTERLogic.PendingFundTERsUpdateStatus(fundTERs, user.Identity.Name);
        }
    }
}
