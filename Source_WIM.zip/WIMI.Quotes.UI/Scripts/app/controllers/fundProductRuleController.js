﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('fundProductRuleController', ['$scope', 'fundProductRuleService', function ($scope, fundProductRuleService)
        {
            $scope.fundMinimum = undefined;

            // Private Methods

            var onPrePersist = $scope.$on('quoteDetails.onPrePersist', function (event, promises)
            {
                
                if (!$scope.profile.IsActive)
                    return;

                var fundMinimumDetails = {
                    ClientNumber: $scope.application.selectedClient.ClientNumber,
                    ProductId: $scope.quoteItem.Product.Code,
                    Type: $scope.profile.Type === 'LumpSum' && ($scope.quoteItem.additionProfile || {}).IsActive ? 'Addition' : 'NewBusiness',
                    Funds: $scope.profile.Funds
                }
                promises
                    .push(fundProductRuleService.checkMinimumFundRule(fundMinimumDetails)
                    .success(function (response)
                    {
                        $scope.fundMinimum = response.FundProductRules;
                        $scope.profile.IsFundMinimunInvalid = !response.IsOverallCompliant;
                    }));
            });


            // On Unload

            $scope.$on("$destroy", function ()
            {
                onPrePersist();
            });

        }]);
})();