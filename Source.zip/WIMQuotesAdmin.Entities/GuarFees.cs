﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMQuotesAdmin.Entities
{
    public class GuarFees
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public double MinAmnt { get; set; }
        public double MaxAmnt { get; set; }
        public double effrate { get; set; }
        public DateTime startdate { get; set; }
        public DateTime enddate { get; set; }
        public DateTime tranchedate { get; set; }
        public double absalifefee { get; set; }
        public double Revisedaimsfee { get; set; }
        public double Revisedabsalifefee { get; set; }
        public double RevisedTaxLossFee { get; set; }
        public double aimsfee { get; set; }
        public double acmbfee { get; set; }
        public double TaxLossFee { get; set; }
        public double rsclevy { get; set; }
        public double ACMBRateNaca { get; set; }
        public double NACS { get; set; }
        public string Guarantor { get; set; }
        public DateTime MaturityDate { get; set; }
        public string TradeNumber { get; set; }
        public string GuaranteedTradeNumber { get; set; }
        public DateTime FirstIncPmtDate { get; set; }
        public double AbcapMaturity { get; set; }
        public double AbcapAnnuity { get; set; }
        public string Capturer { get; set; }
        public DateTime Captured { get; set; }
        public string Authorizer { get; set; }
        public DateTime Authorized { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public StagingStatus Status { get; set; }
        public string Modifiedby { get; set; }
        public DateTime? ModifiedDateTime { get; set; }
        public string UserID { get; set; }
    }
}
