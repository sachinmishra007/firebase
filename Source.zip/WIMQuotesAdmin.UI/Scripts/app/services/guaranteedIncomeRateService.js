﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('guaranteedIncomeRateService', ['$http', function ($http)
        {
            var guaranteedIncomeRateService = {};

            guaranteedIncomeRateService.CaptureRates = function (rates)
            {
                return $http.post('api/IncomeRates/CaptureRates', rates);
            }

            guaranteedIncomeRateService.AuthoriseRates = function (rates)
            {
                return $http.post('api/IncomeRates/AuthoriseRates', rates);
            }

            guaranteedIncomeRateService.GetLatestRates = function (productCode)
            {
                
                return $http({ url: 'api/IncomeRates/GetLatestRates?productCode=' + productCode });
            }

            guaranteedIncomeRateService.RejectRates = function (productCode)
            {
                return $http.post('api/IncomeRates/RejectRates', productCode);
            }

            guaranteedIncomeRateService.GetProductTypes = function ()
            {
                return [
                    { Code: 'INCOME', Name: 'INCOME' },
                    { Code: 'GUARDINC', Name: 'GUARDINC' }
                ];
            }

            guaranteedIncomeRateService.GetGuarantors = function ()
            {
                return [
                    { Code: 'ABCAP', Name: 'Absa Capital' },
                    { Code: 'ABSABANKLTD', Name: 'Absa Bank Limited' }
                ];
            }

            return guaranteedIncomeRateService;
        }]);
})();

