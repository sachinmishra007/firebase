﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class FundFactSheetLogic : Contracts.IFundFactSheetLogic
    {
        #region Constructor

        private readonly DataAccess.Repositories.Contracts.IFundFactSheetRepository _fundFactSheetRepository;

        public FundFactSheetLogic(DataAccess.Repositories.Contracts.IFundFactSheetRepository fundFactSheetRepository)
        {
            _fundFactSheetRepository = fundFactSheetRepository;
        }

        #endregion

        public List<Entities.FundFactSheet> Get(Entities.FundType fundType, string fundCode)
        {
            var fundFactSheets = _fundFactSheetRepository.GetFundFactSheets(fundType, fundCode);
            var pendingFundFactSheets = GetPendingFundFactSheets();

            if (pendingFundFactSheets == null || pendingFundFactSheets.Count == 0)
                return fundFactSheets;

            foreach (var pendingFundFactSheet in pendingFundFactSheets)
            {
                var fundFactSheet = fundFactSheets.FirstOrDefault(f => f.FundCode == pendingFundFactSheet.FundCode);

                if (fundFactSheet == null)
                    continue;

                fundFactSheet.Status = pendingFundFactSheet.Status;
                fundFactSheet.UserId = pendingFundFactSheet.UserId;
                fundFactSheet.ModifiedDateTime = pendingFundFactSheet.ModifiedDateTime;
            }

            return fundFactSheets;
        }

        public List<Entities.Fund> GetUnmappedFunds()
        {
            return _fundFactSheetRepository.GetUnmappedFunds();
        }

        public List<Entities.FundFactSheet> GetPendingFundFactSheets()
        {
            return _fundFactSheetRepository.GetPendingFundFactSheets();
        }

        public void StageFundFactSheet(Entities.FundFactSheet fundFactSheet, string userId)
        {
            if (fundFactSheet == null || string.IsNullOrWhiteSpace(userId))
                return;

            fundFactSheet.Status = Entities.StagingStatus.PendingAuthorise;
            fundFactSheet.UserId = userId;
            fundFactSheet.ModifiedDateTime = DateTime.Now;
            fundFactSheet.FileName = string.Format("{0}.pdf", fundFactSheet.FundCode);

            _fundFactSheetRepository.SaveFundFactSheetToStaging(fundFactSheet);
        }

        public void PendingFundFactSheetsUpdateStatus(List<Entities.FundFactSheet> fundFactSheets, string userId)
        {
            if (fundFactSheets == null || fundFactSheets.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return;

            foreach (var fundFactSheet in fundFactSheets)
            {
                switch (fundFactSheet.Status)
                {
                    case Entities.StagingStatus.Authorise:
                        PendingFundFactSheetAuthorise(fundFactSheet.FundCode, userId);
                        break;
                    case Entities.StagingStatus.Reject:
                        PendingFundFactSheetReject(fundFactSheet.FundCode, userId);
                        break;
                }
            }
        }

        public Entities.File GetFundFactSheetFile(string fundCode)
        {
            return _fundFactSheetRepository.GetFundFactSheetFile(fundCode);
        }

        public Entities.File GetPendingFundFactSheetFile(string fundCode)
        {
            var fundFactSheet = _fundFactSheetRepository.GetPendingFundFactSheet(fundCode);

            return new Entities.File
            {
                Name = fundFactSheet.FileName,
                FullQualifiedName = fundFactSheet.FileName,
                Data = fundFactSheet.FileData
            };
        }

        #region Private Methods

        private void PendingFundFactSheetAuthorise(string fundCode, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            var pendingFundFactSheet = _fundFactSheetRepository.GetPendingFundFactSheet(fundCode);

            if (pendingFundFactSheet == null)
                return;

            switch (pendingFundFactSheet.InstructionType)
            {
                case Entities.InstructionType.Delete:
                    _fundFactSheetRepository.DeleteAuthorisedFundFactSheet(fundCode);
                    break;
                default:
                    _fundFactSheetRepository.SaveAuthorisedFundFactSheet(pendingFundFactSheet);
                    break;
            }

            _fundFactSheetRepository.UpdateFundFactSheetStagingStatus(fundCode, Entities.StagingStatus.Authorise, userId);
        }

        private void PendingFundFactSheetReject(string fundCode, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            _fundFactSheetRepository.UpdateFundFactSheetStagingStatus(fundCode, Entities.StagingStatus.Reject, userId);
        }

        #endregion


        public List<Entities.Fund> GetUnmappedFundsByType(Entities.FundType fundType)
        {
           return _fundFactSheetRepository.GetUnmappedFundsByType(fundType);
           

        }
    }
}
