﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IUserAccessControlReportLogic
    {
        List<Entities.UserAccessControlReport> GetUserAccessControlReportData(
            Entities.UserAccessControlReportDetail detail);

        List<Entities.User> GetUserRolesReport();

        int[] GetUserRoleCount();
    }
}
