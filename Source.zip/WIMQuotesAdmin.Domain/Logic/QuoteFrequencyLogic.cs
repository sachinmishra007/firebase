﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.Domain.Logic.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class QuoteFrequencyLogic : IQuoteFrequencyLogic
    {
        #region Constructor
        private readonly DataAccess.Repositories.Contracts.IQuoteFrequencyRepository _quoteFrequencyRepository;

        public QuoteFrequencyLogic(DataAccess.Repositories.Contracts.IQuoteFrequencyRepository quoteFrequencyRepository)
        {
            _quoteFrequencyRepository = quoteFrequencyRepository;
        }
        #endregion

        public List<Entities.QuoteFrequencyReport> GetQuoteFrequencyReport(Entities.QuoteFrequencyReportDetail detail)
        {
            if(detail == null )
                return null;

            detail.BrokerCode = detail.ReportType == Entities.ReportType.AllQuotes ? string.Empty : detail.BrokerCode;

            return _quoteFrequencyRepository.GetQuoteFrequencyReport(detail.StartDate,detail.EndDate,detail.BrokerCode);
        }

        public List<Entities.Broker> GetBrokers(string searchTerm)
        {
            return _quoteFrequencyRepository.GetBrokers(searchTerm);         
        }


        public List<Entities.Broker> GetBrokerHouse(string searchTerm)
        {
            return _quoteFrequencyRepository.GetBrokerHouse(searchTerm);
        }
    }
}
