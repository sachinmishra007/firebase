﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('taxInformationController', ['$scope', '$timeout', 'taxInformationService', function ($scope, $timeout, taxInformationService)
        {
            $scope.taxTables = [];
            $scope.pendingTaxTables = [];
            $scope.taxInfoList = [];
            $scope.includeFileName = undefined;

            $scope.isReadOnlyUser = true;
            $scope.status = undefined;
            $scope.UserRole = undefined;
            $scope.isSuperUser = false;
            $scope.isAdminUser = false;
            $scope.showSuccessMessage = false;
            $scope.message = '';
            $scope.taxRebates = {};
            $scope.canSave = true;

            $scope.isViewVisible = false;
            $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' ||
                $scope.application.currentMenuItem.AccessLevel === 'AdminRights';

            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';

            // On Load
            $scope.init = function ()
            {
                $scope.getTaxRebates();
            };

            $scope.application.showLoading = true;

            taxInformationService.getTaxInformation().success(function (response)
            {
                $scope.taxInfoList = response;

                $scope.application.showLoading = false;

            });

            //Private Methods

            var removePendingTaxes = function (id) {
                ////debugger;
                for (var i = 0; i < $scope.pendingTaxTables.length; i++) {
                    if ($scope.pendingTaxTables[i].Id === id)
                        $scope.pendingTaxTables.splice(i, 1);
                }
            }

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 3000);
            };

            var getPending = function () {
                ////debugger;
                taxInformationService.getPendingTaxTables().success(function (response) {
                    $scope.pendingTaxTables = response;
                    $scope.isViewVisible = response.length === 0;
                    $scope.isPendingVisible = $scope.pendingTaxTables.length === 0 ? false : true;

                });
            };

            var getTaxData = function () {
                ////debugger;
                taxInformationService.getTaxTables().success(function (response) {

                    $scope.taxTables = response;

                });
            };

            

            // Behaviours

            $scope.setPendingTaxTables = function (taxTable, status) {
                //debugger;
                taxTable.Status = taxTable.Status !== status ? status : "PendingAuthorise";
            };

            $scope.anyPendingTaxTablesSelected = function () {
                
                for (var i = 0; i < $scope.pendingTaxTables.length; i++) {
                    if ($scope.pendingTaxTables[i].Status !== "PendingAuthorise")
                        return true;
                }

                return false;
            };

            $scope.selectTaxOption = function (selectedTax)
            {
                switch (selectedTax.Id)
                {
                    case 1:
                        $scope.includeFileName = 'Views/Partials/Product/TaxBrackets.html';
                        $scope.getTaxTables();
                        break;
                    case 2:
                        $scope.includeFileName = 'Views/Partials/Product/TaxRebates.html';
                        $scope.getTaxRebates();
                        break;
                }
            };

           

            $scope.getTaxTables = function ()
            {
                //debugger;

                getTaxData();

                if ($scope.isPendingVisible) {
                    getPending();
                    
                }
                else
                {
                    
                    $scope.isViewVisible = true;
                }
               
            };

          

            $scope.saveTaxBrackets = function (taxTables)
            {
              
                if (typeof taxTables === 'undefined' || taxTables === null)
                    return;

                var userObj = $scope.application.userProfile;
                taxTables.Status = "PendingAuthorise";
                taxInformationService.saveTaxBrackets(taxTables, userObj.Id).success(function ()
                {
                    taxTables.$editMode = false;

                    if (userObj.Role === "SuperUser")
                    {
                        showMessage('Tax Brackets Will be amended once authorised by another Super User.');
                    }
                    else if (userObj.Role === "AdminUser")
                    {
                        showMessage('Tax Brackets will be amended once Authorised by a Super User.');
                    }

                }
                 );

            };

            $scope.authoriseTaxBrackets = function ()
            {
                //debugger;
                var pendingTaxes= [];
                for (var i = 0; i < $scope.pendingTaxTables.length; i++) {
                    if ($scope.pendingTaxTables[i].Status !== "PendingAuthorise")

                        pendingTaxes.push($scope.pendingTaxTables[i])

                }

                taxInformationService.authoriseTaxBrackets(pendingTaxes).success(function ()
                {
                    for (var i = 0; i < pendingTaxes.length; i++) {
                        removePendingTaxes(pendingTaxes[i].Id);
                    }
                   
                    showMessage("Selected Tax Brackets were updated successfully");
                    $scope.showSuccessMessage = true;
                    if ($scope.pendingTaxTables.length === 0) {
                        $scope.isViewVisible = true;

                        $scope.taxTables = [];

                        getTaxData();
                    }
                    
                });
            };

            $scope.rejectTaxBrackets = function (reject)
            {
                taxInformationService.rejectTaxBrackets(reject).success(function (response)
                {
                    $scope.taxTablesPending = [];
                    $scope.taxTablesPending = response;

                    if ($scope.taxTablesPending.length > 0)
                    {
                        showMessage('Amendments for the Tax Brackets has been rejected.');
                    }
                    else
                    {
                        showMessage('None of the Tax Brackets in pending mode.');
                    }
                });
            };

            $scope.getTaxRebates = function ()
            {
               // debugger;
                taxInformationService.getTaxRebates().success(function (response)
                {
                    $scope.taxRebates = response;
                    $scope.taxRebates.LoggedInUser = $scope.application.userProfile.Id;
                    $scope.determineAccess();
                });
            };

            $scope.saveTaxRebates = function ()
            {
                debugger;
                taxInformationService.saveTaxRebates($scope.taxRebates, $scope.taxRebates.LoggedInUser).success(function ()
                {
                    showMessage('Tax Rebates save successfully. Status is Pending Authorisation.');
                    $scope.canSave = false;
                    $scope.canAuth = false;
                });
            };

            $scope.determineAccess = function ()
            {
                //debugger;
                $scope.canAuth = (($scope.application.userProfile.Role === 'SuperUser') && ($scope.application.userProfile.Id !== $scope.taxRebates.ModifiedUser )&& $scope.taxRebates.Status !== 0);
                $scope.canSave = (($scope.application.userProfile.Role === 'SuperUser' || $scope.application.userProfile.Role === 'AdminUser') && $scope.taxRebates.Status === 0);
                //$scope.canSave = (($scope.application.userProfile.Role === 'SuperUser' && $scope.taxRebates.Status === 0) || ($scope.application.userProfile.Role === 'AdminUser' && $scope.taxRebates.Status !== 0));
                //$scope.canSave = (($scope.application.userProfile.Role === 'SuperUser') && $scope.taxRebates.Status === 0);
            };

            $scope.authoriseRebates = function ()
            {
                taxInformationService.authoriseRebates($scope.taxRebates).success(function ()
                {
                    $scope.taxRebates.Status = 'Authorised';
                    $scope.canAuth = false;
                    $scope.canSave = true;;
                    showMessage('Tax Rebates authorised successfully.');
                });
            };

            $scope.rejectRebates = function ()
            {
                taxInformationService.rejectRebates().success(function ()
                {
                    $scope.taxRebates.Status = 'Uncaptured';
                    $scope.canAuth = false;
                    $scope.getTaxRebates();
                    $scope.canSave = true;
                    showMessage('Tax Rebates rejected successfully.');
                });
            }
        }]);
})();
