﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IValidationLogic
    {
        List<Entities.Validation> GetUIValidations();
        void SaveValidationToStaging(Entities.Validation validation, string userId);
        List<Entities.Validation> GetPendingValidation();
        void PendingValidationUpdateStatus(List<Entities.Validation> validations, string userId);
    }
}
