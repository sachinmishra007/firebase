﻿namespace WIMQuotesAdmin.Entities
{
    public enum Language
    {
        English,
        Afrikaans
    }
}
