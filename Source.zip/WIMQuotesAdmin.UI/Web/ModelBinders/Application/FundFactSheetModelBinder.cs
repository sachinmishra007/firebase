﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common.Extensions;
using WIMQuotesAdmin.UI.Web.StreamProviders;

namespace WIMQuotesAdmin.UI.Web.ModelBinders
{
    /// <summary>
    /// Model Binder to bind Multipart File Data for actual Fund Fact Sheet File to be bound to Entities.FundFactSheet
    /// </summary>
    public class FundFactSheetModelBinder : IModelBinder
    {
        public bool BindModel(System.Web.Http.Controllers.HttpActionContext actionContext, ModelBindingContext bindingContext)
        {
            if (bindingContext.ModelType != typeof(Entities.FundFactSheet))
                return false;

            if (!actionContext.Request.Content.IsMimeMultipartContent())
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);

            var provider = new MultipartFormDataMemoryStreamProvider();
 
            IDictionary<string, byte[]> fileStreams = null;
            Task.Factory
                .StartNew(() => fileStreams = actionContext.Request.Content.ReadAsMultipartAsync(provider).Result.FileStreams,
                    CancellationToken.None,
                    TaskCreationOptions.LongRunning, // Guarantees separate thread
                    TaskScheduler.Default)
                .Wait();

            var fundFactSheet = new Entities.FundFactSheet
            {
                FundCode = provider.FormData.Get("fundCode"),
                FundName = provider.FormData.Get("fundName"),
                InstructionType = provider.FormData.Get("instructionType").ToEnum<Entities.InstructionType>(),
                Type = provider.FormData.Get("type").ToEnum<Entities.FundType>()
            };

            var file = fileStreams.FirstOrDefault();

            if (string.IsNullOrWhiteSpace(fundFactSheet.FundCode) || file.Value.Length == 0)
                throw new HttpResponseException(HttpStatusCode.BadRequest);

            fundFactSheet.FileName = file.Key;
            fundFactSheet.FileData = file.Value;

            bindingContext.Model = fundFactSheet;

            return true;
        }
    }
}