﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IProductRepository
    {
        List<Entities.Note> GetProductNotes(string productCode, Entities.Language language);
        Entities.Note GetProductNote(int noteId);
        List<Entities.Product> GetNotesProducts();
        List<Entities.Note> GetPendingProductNotes();
        void SaveProductNoteToStaging(Entities.Note note);
        void UpdateNoteStagingStatus(int noteId, Entities.StagingStatus status, string userId);
        void SaveAuthorisedNote(Entities.Note note);
    }
}
