﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Configuration;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class FundTICLogic : Contracts.IFundTICLogic
    {

        #region Constructor

        private readonly DataAccess.Repositories.Contracts.IFundTICRepository _fundTICRepository;

        public FundTICLogic(DataAccess.Repositories.Contracts.IFundTICRepository fundTICRepository)
        {
            _fundTICRepository = fundTICRepository;
        }

        #endregion
        public void StageFundTICSheet(Entities.FundTIC file, string userID)
        {
            file.FileName = System.IO.Path.Combine(ConfigurationManager.AppSettings["FilePathUploadTIC"].ToString(), file.FileName);

            if (Common.Helpers.FileHelper.CreateFile(file.FileData, file.FileName))
            {
                String excelConnString = String.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0\"", file.FileName);

                //Create Connection to Excel work book 
                using (OleDbConnection excelConnection = new OleDbConnection(excelConnString))
                {
                    //Create OleDbCommand to fetch data from Excel 
                    using (OleDbCommand cmd = new OleDbCommand(ConfigurationManager.AppSettings["FundITLQuery"].ToString(), excelConnection)) //"Select [FundCode],[FundName],[TIC] from [Sheet2$]"
                    {
                        excelConnection.Open();

                        OleDbDataReader reader = cmd.ExecuteReader();

                        _fundTICRepository.StageFundTICSheet(reader, userID);


                    }
                }

                //Delete file 
                Common.Helpers.FileHelper.Delete(file.FileName);
            }

        }




        public List<Entities.FundTIC> GetPendingFundTICs()
        {
            return _fundTICRepository.GetPendingFundTICs();
        }


        public void SaveFundTIC(string userID)
        {
            _fundTICRepository.SaveAuthorisedFundTIC();
            _fundTICRepository.AutoriseRejectFundTIC(Entities.StagingStatus.Authorise, userID);
        }


        public void RejectFundTIC(string userID)
        {
            _fundTICRepository.AutoriseRejectFundTIC(Entities.StagingStatus.Reject, userID);
        }
    }
}
