﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('fundTERService', ['$http', function ($http)
        {
            var fundTERService = {};

            fundTERService.getFundTERs = function (fundType, fundCode)
            {
                return $http({ url: 'api/FundTER/?fundType=' + fundType + '&fundCode=' + fundCode });
            };

            fundTERService.getUnmappedFunds = function ()
            {
                return $http({ url: 'api/FundTER/GetUnmappedFunds' });
            };

            fundTERService.saveFundTER = function (fundTER)
            {
                return $http.post('api/FundTER', fundTER);
            };

            fundTERService.getPendingFundTERs = function ()
            {
                return $http({ url: 'api/FundTER/Pending' });
            };

            fundTERService.updatePendingStatuses = function (fundTERList)
            {
                return $http.post('api/FundTER/UpdatePendingStatuses', fundTERList);
            };

            return fundTERService;
        }]);
})();
