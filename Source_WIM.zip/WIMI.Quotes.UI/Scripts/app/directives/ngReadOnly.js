﻿(function ()
{
    'use strict';

    angular.module('common.directives')
        .directive('ngReadOnly', ['$parse', '$timeout', function ($parse, $timeout)
        {
            return {
                restrict: 'A',
                link: function (scope, element, attrs)
                {
                    $timeout(function ()
                    {
                        var newVal = $parse(attrs.ngReadOnly)(scope);

                        if (typeof newVal === "undefined" || newVal === null)
                            return;

                        var elements = element.find(':input:not(.ng-read-only-ignore)');
                        elements.prop('disabled', newVal || false);
                    }, 0);
                }
            };
        }]);

})();
