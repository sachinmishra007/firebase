﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Entities
{
    public class AdminActivityReport
    {
        public DateTime? ActivityTimeStamp { get; set; }
        public string UserId { get; set; }
        public string UserRole { get; set; }
        public string Action { get; set; }
        public string Section { get; set; }
        public string ChangeType { get; set; }
        public string ChangeField { get; set; }

    }
}
