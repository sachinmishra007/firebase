﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IFundZeroFeeRepository
    {
        List<Entities.FundZeroFee> GetFundZeroFee();

        List<Entities.Fund> GetFund(string fundType);

        List<Entities.FundZeroFee> GetPendingFundZeroFees();

        List<Entities.FundZeroFee> GetPendingFundZeroFee(string FundId);

        void SaveFundZeroFeesToStaging(Entities.FundZeroFee fundZeroFee);

        void SaveAuthorisedFundZeroFees(Entities.FundZeroFee fundZeroFee);

        void DeleteAuthorisedFundZeroFees(Entities.FundZeroFee fundZeroFee);

        void UpdateFundZeroFeesStagingStatus(Entities.FundZeroFee fundZeroFee);

        void AddNewFund(Entities.FundZeroFee fundZeroFee);
    }
}
