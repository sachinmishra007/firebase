﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('wrapBreakdownReportService', ['$http', function ($http)
        {
            var wrapBreakdownReportService = {};

            wrapBreakdownReportService.getAvailableWraps = function ()
            {
                return $http({ url: 'api/Wrap' });
            };

            wrapBreakdownReportService.getFundsForWrap = function (wrapCode)
            {
                return $http({ url: 'api/Wrap/' + wrapCode });
            };

            return wrapBreakdownReportService;
        }]);
})();
