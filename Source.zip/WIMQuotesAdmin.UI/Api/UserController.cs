﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class UserController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IUserLogic _userLogic;

        public UserController(Domain.Logic.Contracts.IUserLogic userLogic)
        {
            _userLogic = userLogic;
        }

        #endregion

        // GET api/User
        public Entities.User Get([ModelBinder]IPrincipal user)
        {
            if (user == null)
                return null;

            return _userLogic.GetUser(user.Identity.Name);
        }

        // GET api/User/Roles
        [Route("api/User/Roles")]
        public List<string> GetUserRoles()
        {
            return Enum.GetNames(typeof (Entities.UserRole)).ToList();
        }

        // GET api/User/AccessLevels
        [Route("api/User/AccessLevels")]
        public List<string> GetUserAccessLevels()
        {
            return Enum.GetNames(typeof(Entities.AccessLevel)).ToList();
        }

        // GET api/User/Access
        [HttpGet]
        [Route("api/User/Access/{userId}")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public Entities.UserAccess GetUserAccess(string userId)
        {
            return _userLogic.GetUserAccess(userId);
        }

        // GET api/User/SearchNewUsers
        [HttpGet]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        [Route("api/User/SearchNewUsers/{searchTerm}")]
        public List<Entities.User> SearchNewUsers(string searchTerm)
        {
            return _userLogic.SearchUnmappedUsers(searchTerm);
        }

        // GET api/User/SearchExistingUsers
        [HttpGet]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        [Route("api/User/SearchExistingUsers/{searchTerm}")]
        public List<Entities.User> SearchExistingUsers(string searchTerm)
        {
            return _userLogic.SearchExistingUsers(searchTerm);
        }

        // POST api/User
        [HttpPost]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void Post([FromBody]Entities.User user, [ModelBinder]IPrincipal systemUser)
        {
            _userLogic.SaveUser(user, systemUser.Identity.Name);
        }

        // POST api/User/SaveUserAccess
        [HttpPost]
        [Route("api/User/SaveUserAccess")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void SaveUserAccess([FromBody]Entities.UserAccess userAccess, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal systemUser)
        {
            _userLogic.SaveUserAccess(userAccess, systemUser.Identity.Name);
        }

        // DELETE api/User
        [HttpPost]
        [Route("api/User/Delete")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void DeleteUser([FromBody]Entities.User user, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal systemUser)
        {
            _userLogic.DeleteUser(user, systemUser.Identity.Name);
        }
    }
}
