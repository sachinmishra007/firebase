﻿
(function ()
{
    'use strict';

    var adminApp = angular.module('adminApp', [
        'adminApp.services',
        'adminApp.controllers',
        'common.directives',
        'ngSanitize',
        'angularFileUpload',
        'chart.js'
    ]);

    angular.module('adminApp.controllers', []);
    angular.module('adminApp.services', []);


    // Global Configuration

    adminApp.constant('numberFormat',
    {
        fraction: 2,
        thousandSeparator: ',',
        separatorRegex: /\B(?=(\d{3})+(?!\d))/g
    });

    adminApp.constant('dateFormat',
    {
        defaultTimezoneOffset: '+0200'
    });

    adminApp.config(['$httpProvider', '$compileProvider', function ($httpProvider) //, $compileProvider)
    {
        $httpProvider.interceptors.push('authInterceptorService');
        //$compileProvider.debugInfoEnabled(false); //Set to false in Production for performance increase
    }]);

})();
