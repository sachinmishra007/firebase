﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('wrapBreakdownReportController', ['$scope', 'wrapBreakdownReportService', function ($scope, wrapBreakdownReportService)
        {
            $scope.wrapsList = [];
            $scope.wrapFundsList = [];


            // Private Methods

            var retrieveWrapsList = function ()
            {
                $scope.application.showLoading = true;

                wrapBreakdownReportService.getAvailableWraps().success(function (response)
                {
                    $scope.wrapsList = response;
                    $scope.application.showLoading = false;
                });
            };

           


            // On Load

            retrieveWrapsList();


            // Behaviours

          

        }]);
})();