﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('quoteSelectionController', ['$scope', '$rootScope', function ($scope, $rootScope)
        {
            //  Events

            var preNextStep = $rootScope.$on('navigation.preNextStep', function ()
            {
                $scope.application.showLoading = true;
            });

            $scope.$on("$destroy", function ()
            {
                preNextStep();
            });
        }]);
})();