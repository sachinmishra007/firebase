﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('fundSecurityFeesService', ['$http', function ($http)
        {
            var fundSecurityFeesService = {};

            fundSecurityFeesService.uploadFileToUrl = function (file, uploadUrl)
            {
                debugger;
                var fileName = file.name;
                
                 fileName = fileName.replace('.xlsx', '');
                 return $http.post('api/FundSecurityFees/SaveToStaging/' + fileName);
            };

            fundSecurityFeesService.getPendingFundTICs = function () {
                return $http({ url: 'api/FundSecurityFees/Pending' });
            };

            fundSecurityFeesService.updatePendingStatuses = function () {
                return $http.post('api/FundSecurityFees/UpdatePendingStatuses');
            };

            fundSecurityFeesService.updateRejectStatuses = function () {
                debugger;
                return $http.post('api/FundSecurityFees/UpdateRejectStatuses');
            };

            return fundSecurityFeesService;
        }]);
})();
