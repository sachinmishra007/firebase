﻿using System;
using System.Collections.Generic;
using System.Linq;

using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class FundManagementRepository : IFundManagementFeesRepository
    {
        public List<Entities.FundManagementFees> GetFundManagementFees(Entities.FundType fundType, string fundCode)
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var fundManageFees = context.GetFundManagementFees(Mappings.PortfolioAdminServiceMapping.ToFundType(fundType), fundCode);

                return fundManageFees.Select(m => new Entities.FundManagementFees
                {
                    FundCode = m.FundCode,
                    FundName = m.FundName,
                    ManagementFee = m.ManagementFee,
                    ModifiedDateTime = m.DateModified
                }).ToList();
            }
        }

        public void SaveFundManagementFeesToStaging(Entities.FundManagementFees fundManagementFees)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundFees = Mappings.WIMQuotesAdminStagingMapping.ToFundManagementFeeStaging(fundManagementFees);

                if (contextFundFees == null)
                    return;

                context.FundManagementFeeStagings.Add(contextFundFees);
                context.SaveChanges();

            }
        }


        public List<Entities.Fund> GetUnmappedFunds()
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var funds = context.GetUnmappedFundManagementFeesFund();
                return funds == null ? new List<Entities.Fund>() : funds.Select(Mappings.PortfolioAdminServiceMapping.FromFund).ToList();
 
            }
        }


        public Entities.FundManagementFees GetPendingFundManagementFees(string fundCode)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.FundManagementFeeStagings
                        .Where(fm => fm.Status == (int)Entities.StagingStatus.PendingAuthorise && fm.FundCode == fundCode)
                        .Select(Mappings.WIMQuotesAdminStagingMapping.FromFundManagementFeesStaging)
                        .FirstOrDefault();
            }
        }


        public List<Entities.FundManagementFees> GetPendingFundManagementFees()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.FundManagementFeeStagings
                               .Where(f=> f.Status ==(int) Entities.StagingStatus.PendingAuthorise)
                               .Select(Mappings.WIMQuotesAdminStagingMapping.FromFundManagementFeesStaging)
                               .ToList();
            }
        }


        public void SaveAuthorisedFundManagementFees(Entities.FundManagementFees fundManagementFees)
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.SaveFundManagementFees(Mappings.PortfolioAdminServiceMapping.ToFundManagementFees(fundManagementFees));
            }
        }

        public void UpdateFundManagementFeesStagingStatus(string fundCode, Entities.StagingStatus status, string userId)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundManagementFees = context.FundManagementFeeStagings
                    .Where(f => f.FundCode == fundCode &&
                                f.Status == (int)Entities.StagingStatus.PendingAuthorise);

                foreach (var contextFundManagementFee in contextFundManagementFees)
                {
                    contextFundManagementFee.Status = (int)status;
                    contextFundManagementFee.ModifiedUserId = userId;
                    contextFundManagementFee.ModifiedDateTime = DateTime.Now;
                }

                context.SaveChanges();
            }
        }

        public void DeleteAuthorisedFundManagementFees(string fundCode)
        {
            if (String.IsNullOrWhiteSpace(fundCode))
                return;

            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var manfeeService = new PortfolioAdminService.FundManagementFees();
                manfeeService.FundCode = fundCode;
                context.DeleteFundManagementFees(manfeeService);
            }
        }
    }
}
