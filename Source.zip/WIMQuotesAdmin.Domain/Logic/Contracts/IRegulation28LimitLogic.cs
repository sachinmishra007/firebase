﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IRegulation28LimitLogic
    {
        List<Entities.Regulation28Limits> Get();
        List<Entities.Regulation28Limits> GetPendingLimits();
        void StageLimit(Entities.Regulation28Limits limit, string userId);
        void PendingLimitUpdateStatus(List<Entities.Regulation28Limits> limits, string userId);
    }
}