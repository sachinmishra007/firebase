﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('validationsController', ['$scope', '$timeout', 'validationService', function ($scope, $timeout, validationService)
        {
            $scope.validationList = [];
            $scope.pendingValidationList

            $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' ||
                $scope.application.currentMenuItem.AccessLevel === 'AdminRights' ;

            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
            
            $scope.isViewVisible = false;

            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];

            // Private Methods

            var removePendingValidations = function (id) {
                for (var i = 0; i < $scope.pendingValidationList.length; i++) {
                    if ($scope.pendingValidationList[i].Id === id)
                        $scope.pendingValidationList.splice(i, 1);
                }
            }

            var retrieveValidationList = function () {
              
                $scope.application.showLoading = true;

                validationService.getValidations().success(function (response) {
                    $scope.validationList = response;
                    $scope.application.showLoading = false;
                });
            }

            

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 3000);
            }

          
            // Behaviours

            $scope.editValidations = function (valid) {
               
                valid.MessageRevised = valid.Message;
                valid.$editMode = true;
            };

            $scope.cancelEditValidations = function (valid) {
                
                valid.Message = valid.MessageRevised;
                valid.$editMode = false;
            };


            $scope.saveEditValidations = function (valid) {
               
                validationService.saveValidations(valid).success(function () {
                    valid.Status = 'PendingAuthorise';
                    valid.$editMode = false;

                    showMessage('Validation saved successfully. Pending authorisation.');
                });
            };

            $scope.setPendingValidationStatus = function (valid, status) {
                valid.Status = valid.Status !== status ? status : "PendingAuthorise";
            };

            $scope.anyPendingValidationSelected = function () {
                for (var i = 0; i < $scope.pendingValidationList.length; i++) {
                    if ($scope.pendingValidationList[i].Status !== "PendingAuthorise")
                        return true;
                }

                return false;
            };

            $scope.updatePendingValidationStatus = function () {
                
                var pendingValidation = [];
                for (var i = 0; i < $scope.pendingValidationList.length; i++) {
                    if ($scope.pendingValidationList[i].Status !== "PendingAuthorise")
                        
                        pendingValidation.push($scope.pendingValidationList[i])
                        
                }

                validationService.updatePendingStatuses(pendingValidation).success(function ()
                {
                    for (var i = 0; i < pendingValidation.length; i++) {
                        removePendingValidations(pendingValidation[i].Id);
                    }

                    showMessage("Selected Validations were updated successfully");

                    if ($scope.pendingValidationList.length === 0) {
                        $scope.isViewVisible = true;
                        
                        $scope.validationList = [];

                        retrieveValidationList();
                        
                    }

                    $scope.application.showLoading = false;
                });


            };

            // On Load

            retrieveValidationList();

            if ($scope.isPendingVisible) {
                validationService.getPendingValidation().success(function (response) {
                    $scope.pendingValidationList = response;
                    $scope.isViewVisible = response.length === 0;
                    
                });
            }
            else
            {
                $scope.isViewVisible = true;
            }
            
            // Pagination
            $scope.firstPage = function () {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function () {
                if ($scope.currentPage > 0) {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function () {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function () {
                return Math.ceil(($scope.validationList || []).length / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function () {
                if ($scope.currentPage < $scope.pageCount()) {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function () {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function () {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n) {
                $scope.currentPage = n;
            };

            $scope.range = function () {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0) {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize) {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++) {
                    range.push(i);
                }

                return range;
            };

        }]);
})();
