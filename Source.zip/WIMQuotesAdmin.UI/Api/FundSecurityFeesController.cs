﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ActionResults;
using WIMQuotesAdmin.UI.Web.ModelBinders;
using System.IO;
using System.Web;
using System.Data.OleDb;
using System.Data.SqlClient;



namespace WIMQuotesAdmin.UI.Api
{
    public class FundSecurityFeesController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IFundSecurityFeesLogic _fundSecurityFeesLogic;

        public FundSecurityFeesController(Domain.Logic.Contracts.IFundSecurityFeesLogic fundSecurityFeesLogic)
        {
            _fundSecurityFeesLogic = fundSecurityFeesLogic;
        }

        #endregion
        [ValidateApiAntiForgeryToken]
        [Route("api/FundSecurityFees/SaveToStaging/{fileName}")]

        public void SaveTICToStaging(string fileName, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            fileName = @"C:\Users\exag218\Desktop\TIC\" + fileName + ".xlsx";

            // _fundSecurityFeesLogic.StageFundSecuiryFees(fileName, user.Identity.Name);

        }

        // GET api/FundTER/Pending
        [Route("api/FundSecurityFees/Pending")]
        //[AuthorizeRoles(Constants.Roles.SuperUser)]
        public List<Entities.FundSecurityFees> GetPendingFundTICs()
        {
            return _fundSecurityFeesLogic.GetPendingFundSecurityFees();
        }

        [HttpPost]
        [ValidateApiAntiForgeryToken]
        [Route("api/FundSecurityFees/UpdatePendingStatuses")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingFundTICUpdateStatus([ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {

            _fundSecurityFeesLogic.SaveFundSecurityFees(User.Identity.Name);
        }

        [HttpPost]
        [ValidateApiAntiForgeryToken]
        [Route("api/FundSecurityFees/UpdateRejectStatuses")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void RejectFundTICUpdateStatus([ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {

            _fundSecurityFeesLogic.RejectFundSecurityFees(user.Identity.Name);
        }
    
        [HttpPost]
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        [Route("api/FundSecurityFees/UploadFile")]
        public HttpResponseMessage UploadFundSecurityFeeFile(
            [ModelBinder(typeof(FundSecurityFeesModelBinder))]Entities.FundSecurityFeesFile fundSecurityFeesFile,
            [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {

            if (fundSecurityFeesFile == null ||
                fundSecurityFeesFile.FileData == null || fundSecurityFeesFile.FileData.Length == 0)
                throw new HttpResponseException(HttpStatusCode.BadRequest);

            if (user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            _fundSecurityFeesLogic.StageFundSecuiryFees(fundSecurityFeesFile, user.Identity.Name);

            return Request.CreateResponse(HttpStatusCode.OK);
        }

    }
}
