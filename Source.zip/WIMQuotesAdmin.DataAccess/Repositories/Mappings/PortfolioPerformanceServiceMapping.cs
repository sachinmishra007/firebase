﻿using System.Linq;

namespace WIMQuotesAdmin.DataAccess.Repositories.Mappings
{
    public static class PortfolioPerformanceServiceMapping
    {
        #region To Mappings

        public static PortfolioPerformanceService.Language ToLanguage(Entities.Language language)
        {
            switch (language)
            {
                case Entities.Language.Afrikaans:
                    return PortfolioPerformanceService.Language.Afrikaans;
                default:
                    return PortfolioPerformanceService.Language.English;
            }
        }

        public static PortfolioPerformanceService.DocumentType ToDocumentType(Entities.DocumentType documentType)
        {
            switch (documentType)
            {
                case Entities.DocumentType.ProductBrochure:
                    return PortfolioPerformanceService.DocumentType.ProductBrochure;
                case Entities.DocumentType.ApplicationForm:
                    return PortfolioPerformanceService.DocumentType.ApplicationForm;
                case Entities.DocumentType.FundFactSheet:
                    return PortfolioPerformanceService.DocumentType.FundFactSheet;
                default:
                    return PortfolioPerformanceService.DocumentType.Unspecified;
            }
        }

        #endregion
    }
}
