﻿using System;
using System.Collections.Generic;
using System.Linq;

using WIMQuotesAdmin.DataAccess.Repositories.Mappings;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class ProductRepository : Contracts.IProductRepository
    {
        public List<Entities.Product> GetNotesProducts()
        {
            using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                return context.GetQuoteNotesProducts()
                    .Select(p => new Entities.Product
                    {
                        Code = p.ProductCode,
                        Name = p.ProductName
                    }).ToList();
            }
        }

        public Entities.Note GetProductNote(int noteId)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextNote = context.ProductNoteStagings.FirstOrDefault(n => n.NoteId == noteId);
                return WIMQuotesAdminStagingMapping.FromProductNoteStaging(contextNote);
            }
        }

        public List<Entities.Note> GetProductNotes(string productCode, Entities.Language language)
        {
            using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                return context.GetProductNotes(productCode, WIMQuotesApplicationServiceMapping.ToLanguage(language))
                    .Select(n => new Entities.Note
                    {
                        Id = n.Id,
                        ProductCode = n.ProductCode,
                        Language = WIMQuotesApplicationServiceMapping.FromLanguage(n.Language),
                        Header = n.Header,
                        Description = n.Content,
                        NoteType = n.NoteType,
                        Sequence = n.Sequence
                    }).ToList();
            }
        }

        public List<Entities.Note> GetPendingProductNotes()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.ProductNoteStagings
                    .Where(n => n.Status == (int)Entities.StagingStatus.PendingAuthorise)
                    .Select(WIMQuotesAdminStagingMapping.FromProductNoteStaging)
                    .ToList();
            }
        }

        public void SaveProductNoteToStaging(Entities.Note note)
        {
            if (note == null || string.IsNullOrWhiteSpace(note.RevisedByUserId))
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextNote = context.ProductNoteStagings.FirstOrDefault(n => n.NoteId == note.Id);

                if (contextNote == null)
                {
                    context.ProductNoteStagings.Add(WIMQuotesAdminStagingMapping.ToProductNoteStaging(note));
                }
                else
                {
                    contextNote.ProductCode = note.ProductCode;
                    contextNote.ProductName = note.ProductName;
                    contextNote.LanguageCode = WIMQuotesAdminStagingMapping.ToLanguage(note.Language);
                    contextNote.LanguageName = note.LanguageName;
                    contextNote.HeaderOriginal = note.Header;
                    contextNote.HeaderRevised = note.HeaderRevised;
                    contextNote.NoteType = note.NoteType;
                    contextNote.NoteOriginal = note.Description;
                    contextNote.NoteRevised = note.DescriptionRevised;
                    contextNote.Status = (int)note.Status;
                    contextNote.CapturedUserId = note.RevisedByUserId;
                    contextNote.ModifiedDateTime = note.RevisionDate.GetValueOrDefault();
                }

                context.SaveChanges();
            }
        }

        public void UpdateNoteStagingStatus(int noteId, Entities.StagingStatus status, string userId)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextNote = context.ProductNoteStagings.FirstOrDefault(n => n.NoteId == noteId);

                if (contextNote == null)
                    return;

                contextNote.Status = (int)status;
                contextNote.ModifiedUserId = userId;
                contextNote.ModifiedDateTime = DateTime.Now;
                context.SaveChanges();
            }
        }

        public void SaveAuthorisedNote(Entities.Note note)
        {
            if (note == null)
                return;

            using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                context.SaveProductNote(WIMQuotesApplicationServiceMapping.ToNote(note));
            }
        }
    }
}
