﻿
(function () {
    'use strict';

    angular
        .module('adminApp.services')
        .factory('fundMinimumService', ['$http', function ($http) {
            var fundMinimumService = {};

            fundMinimumService.getFundMinimumAmounts = function () {
                return $http({ url: 'api/FundMinimum/Fund' });
            };

            fundMinimumService.getPendingFundMinimum = function () {
                return $http({ url: 'api/FundMinimum/GetPendingFundMinimum' });

            };

            fundMinimumService.saveFundMinimum = function (FundMinimum) {
                return $http.post('api/FundMinimum', FundMinimum);
            };

            fundMinimumService.addNewFundMinimum = function (FundMinimum) {
               return $http.post('api/FundMinimum/AddNewFundMinimum', FundMinimum);
            };

            fundMinimumService.updatePendingStatuses = function (fundMinimumList) {
                
                return $http.post('api/FundMinimum/UpdatePendingStatuses', fundMinimumList);
            };

            fundMinimumService.getProducts = function () {
                return $http({ url: 'api/FundMinimum/GetProducts' });
            };

            fundMinimumService.getFundList = function (Product) {
                return $http({ url: 'api/FundMinimum/GetFunds/' + Product });
            };

            fundMinimumService.getTransactionTypeList = function (product, fund) {
                
                return $http({ url: 'api/FundMinimum/GetTransactionType/?productId=' + product + '&fundId=' + fund });

            };

            return fundMinimumService;
        }]);
}) ();
