﻿using System.Collections.Generic;
using System.Web.Http;

using WIMI.Quotes.Common;
using WIMI.Quotes.UI.Web.ActionFilters;

namespace WIMI.Quotes.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class ValidationController : ApiController
    {
        #region Constructor

        private readonly Model.Domain.Contracts.IUserLogic _userLogic;
        private readonly Model.Domain.Contracts.IValidationLogic _validationLogic;

        public ValidationController(
            Model.Domain.Contracts.IUserLogic userLogic,
            Model.Domain.Contracts.IValidationLogic validationLogic)
        {
            _userLogic = userLogic;
            _validationLogic = validationLogic;
        }

        #endregion

        // GET: api/Validations
        [AuthorizeApiMustBeUser(Constants.Roles.Advisor, "brokerCode")]
        public IEnumerable<Entities.Validation> Get(string productCode, string brokerCode, int stepId)
        {
            return _validationLogic.GetValidations(productCode, brokerCode, stepId);
        }
    }
}
