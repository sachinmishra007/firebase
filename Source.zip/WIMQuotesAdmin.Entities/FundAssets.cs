﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;

namespace WIMQuotesAdmin.Entities
{
    public class FundAssets
    {
        public FundAssets()
        {
            AssetClass = new List<Entities.AssetClass>();
        }
        public string FundCode { get; set; }
        public string FundName { get; set; }
        public List <AssetClass> AssetClass { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public StagingStatus Status { get; set; }
        public string UserId { get; set; }
        public DateTime ModifiedDatetime { get; set; }
    }
}
