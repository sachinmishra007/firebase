﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IFundSecurityFeesRepository
    {
        void StageFundSecurityFees(OleDbDataReader fundSecurityFees, string userID);
        List<Entities.FundSecurityFees> GetPendingFundSecurityFees();
        void AutoriseRejectFundSecurityFees(Entities.StagingStatus status, string userID);
        void SaveAuthorisedFundSecurityFees();
    }
}
