﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
namespace MorningStarWebTool.DataLayer.Class
{
    public class Connection
    {
        private SqlConnection _con = null;
        private SqlCommand _cmd = null;
        private DataTable dt = null;
        private SqlDataAdapter _adp = null;

        public Connection()
        {
            _con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        }

        public DataTable getFundSLAMappings()
        {
            try
            {
                dt = new DataTable();
                if (_con.State == ConnectionState.Open)
                {
                    _con.Close();
                }

                _cmd = new SqlCommand()
                {
                    CommandType = CommandType.StoredProcedure,
                    Connection = _con,
                    CommandText = ConfigurationManager.AppSettings["GetFundSLAMappings"].ToString()
                };

                _adp = new SqlDataAdapter(_cmd);
                _adp.Fill(dt);
                return dt;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _con.Close();
            }

        }

        public DataTable getClientDetails(string ClientParam, string BrokerCode)
        {
            try
            {
                dt = new DataTable();
                if (_con.State == ConnectionState.Open)
                {
                    _con.Close();
                }

                _cmd = new SqlCommand()
                {
                    Connection = _con,
                    CommandText = ConfigurationManager.AppSettings["ClientDetails"].ToString()
                };
                _cmd.Parameters.AddWithValue("ClientParam", ClientParam);
                _cmd.Parameters.AddWithValue("BrokerCode", BrokerCode);

                _adp = new SqlDataAdapter(_cmd);
                _adp.Fill(dt);
                return dt;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _con.Close();
            }

        }

        public DataTable getClientPolicyDetails(string ClientNumber)
        {
            try
            {
                dt = new DataTable();
                if (_con.State == ConnectionState.Open)
                {
                    _con.Close();
                }

                _cmd = new SqlCommand()
                {
                    Connection = _con,
                    CommandText = ConfigurationManager.AppSettings["ClientPolicyDetails"].ToString()
                };
                _cmd.Parameters.AddWithValue("ClientNumber", ClientNumber);

                _adp = new SqlDataAdapter(_cmd);
                _adp.Fill(dt);
                return dt;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _con.Close();
            }
            return dt;
        }

        public DataTable getClientPolicyFundDetails(string ClientNumber, string PolicyNumber)
        {
            try
            {
                dt = new DataTable();
                if (_con.State == ConnectionState.Open)
                {
                    _con.Close();
                }

                _cmd = new SqlCommand()
                {
                    Connection = _con,
                    CommandText = ConfigurationManager.AppSettings["ClientPolicyFundDetail"].ToString()
                };
                _cmd.Parameters.AddWithValue("ClientNumber", ClientNumber);
                _cmd.Parameters.AddWithValue("PolicyNumber", PolicyNumber);

                _adp = new SqlDataAdapter(_cmd);
                _adp.Fill(dt);
                return dt;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _con.Close();
            }
        }

        public DataTable getMSConfigToolInformation(string ConfigName, string Type)
        {
            try
            {
                dt = new DataTable();
                if (_con.State == ConnectionState.Open)
                {
                    _con.Close();
                }

                _cmd = new SqlCommand()
                {
                    CommandType = CommandType.StoredProcedure,
                    Connection = _con,
                    CommandText = ConfigurationManager.AppSettings["MSToolConfigInformation"].ToString()
                };
                _cmd.Parameters.AddWithValue("@ConfigName", ConfigName);
                _cmd.Parameters.AddWithValue("@Type", Type);
                _adp = new SqlDataAdapter(_cmd);
                _adp.Fill(dt);
                return dt;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _con.Close();
            }
        }
    }
}
