﻿using System.Web.Http;

namespace WIMI.Quotes.UI.Web.ActionFilters
{
    public class AuthorizeApiAttribute : AuthorizeAttribute
    {
        #region Constructor

        public AuthorizeApiAttribute() { }

        public AuthorizeApiAttribute(params string[] roleCodes)
        {
            Roles = string.Join(",", roleCodes);
        }

        #endregion
    }
}