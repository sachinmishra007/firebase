﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;

namespace WIMQuotesAdmin.Entities
{
    public class FundMinimum
    {
        public string FundCode { get; set; }
        public string FundName { get; set; }
        public string FundMinimumAmount { get; set; }
        public string ProductName { get; set; }
        public string ProductId { get; set; }
        public string TransactionDesc { get; set; }
        public int TransactionTypeId { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public StagingStatus Status { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public InstructionType InstructionType { get; set; }
        public string CapturedUserId { get; set; }
        public string ModifiedUserId { get; set; }
        public DateTime ModifiedDateTime { get; set; }

    }
}
