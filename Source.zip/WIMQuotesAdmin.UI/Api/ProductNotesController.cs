﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class ProductNotesController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IProductNotesLogic _productNotesLogic;

        public ProductNotesController(Domain.Logic.Contracts.IProductNotesLogic productNotesLogic)
        {
            _productNotesLogic = productNotesLogic;
        }

        #endregion

        // GET api/ProductNotes
        public List<Entities.Note> Get(string productCode, Entities.Language? language)
        {
            if (string.IsNullOrWhiteSpace(productCode) || !language.HasValue)
                return null;

            return _productNotesLogic.GetProductNotes(productCode, language.Value);
        }

        [Route("api/ProductNotes/Products")]
        // GET api/ProductNotes
        public List<Entities.Product> GetNotesProducts()
        {
            return _productNotesLogic.GetNotesProducts();
        }

        // GET api/ProductNotes/Pending
        [Route("api/ProductNotes/Pending")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public List<Entities.Note> GetPendingProductNotes()
        {
            return _productNotesLogic.GetPendingProductNotes();
        }

        // POST api/ProductNotes
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void Post([FromBody]Entities.Note note, [ModelBinder]IPrincipal user)
        {
            if (note == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _productNotesLogic.StageProductNote(note, user.Identity.Name);
        }

        // POST api/ProductNotes/UpdateStatus
        [HttpPost]
        [Route("api/ProductNotes/UpdatePendingNotesStatus")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingNotesUpdateStatus([FromBody]List<Entities.Note> notes, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (notes == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _productNotesLogic.PendingNotesUpdateStatus(notes, user.Identity.Name);
        }
    }
}
