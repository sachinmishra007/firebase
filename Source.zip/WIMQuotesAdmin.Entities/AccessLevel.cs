﻿namespace WIMQuotesAdmin.Entities
{
    public enum AccessLevel
    {
        AdminRights = 1,
        ReadOnlyRights = 2
    }
}
