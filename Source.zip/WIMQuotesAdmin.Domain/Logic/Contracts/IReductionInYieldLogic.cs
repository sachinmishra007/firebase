﻿using System.Collections.Generic;
using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IReductionInYieldLogic
    {
         List<Entities.ReductionInYield> Get();
         List<Entities.ReductionInYield> GetPendingYields();

         void StageLimit(Entities.ReductionInYield yield, string userId);

         void PendingLimitUpdateStatus(List<Entities.ReductionInYield> limits, string userId);
    }
}
