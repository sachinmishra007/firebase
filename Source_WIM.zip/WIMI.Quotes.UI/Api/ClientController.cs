﻿using System.Collections.Generic;
using System.Web.Http;

using WIMI.Quotes.Common;
using WIMI.Quotes.UI.Web.ActionFilters;

namespace WIMI.Quotes.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class ClientController : ApiController
    {
        #region Contructors & DI

        private readonly Model.Domain.Contracts.IClientLogic _clientLogic;

        public ClientController(Model.Domain.Contracts.IClientLogic clientLogic)
        {
            _clientLogic = clientLogic;
        }

        #endregion

        // GET: api/Client
        [AuthorizeApiMustBeUser(Constants.Roles.Advisor, "brokerCode")]
        public IEnumerable<Entities.Client> Get(string brokerCode, string searchTerm)
        {
            return _clientLogic.GetBrokerClients(brokerCode, searchTerm);
        }

        // POST: api/Client
        public string Post(Entities.Client client)
        {
            return _clientLogic.CreateClient(client);
        }

        // GET: api/Product/ExistingProductValue
        [Route("api/Client/ExistingInvestmentValue")]
        [AuthorizeApiMustBeUser(Constants.Roles.Advisor, "brokerCode")]
        public decimal? GetExistingInvestmentValue(string clientNumber, string brokerCode, string productCode)
        {
            return _clientLogic.GetExistingInvestmentValue(clientNumber, brokerCode, productCode);
        }

        // GET: api/Product/Contributions
        [Route("api/Client/Contributions")]
        public Entities.ClientContribution GetClientContribution(string clientNumber, string productCode)
        {
            return _clientLogic.GetClientContributions(clientNumber, productCode);
        }

        // GET: api/Product/Policies
        [Route("api/Client/Policies")]
        public List<Entities.Policy> GetClientPolicies(string clientNumber, string productCode)
        {
            return _clientLogic.GetClientPolicies(clientNumber, productCode);
        }

        // GET: api/Policy/Fund
        [Route("api/Policy/Fund")]
        public List<Entities.Fund> GetClientPolicyFund(string clientNumber, string policyNumber)
        {
            return _clientLogic.GetClientPolicyFund(clientNumber, policyNumber);
        }
        // GET: api/Policy/PhaseIn
        [Route("api/Policy/PhaseIn")]
        public List<Entities.ClientPolicyPhaseInDetails> GetClientPolicyPhaseInDetails(string clientNumber, string policyNumber)
        {
            return _clientLogic.GetClientPolicyPhaseInDetails(clientNumber, policyNumber);

        }

    }
}