﻿using System;
using System.Collections.Generic;
using System.Linq;
using WIMQuotesAdmin.DataAccess.Repositories.Mappings;




namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class GuarFeeRepository : Contracts.IGuarFeeRepository
    {
        public List<Entities.GuarFees> GetGuarFees(Entities.GuarFeesType guarFeesType)
        {
            try
            {
                using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
                {
                    return context.GetGuarFees(WIMQuotesApplicationServiceMapping.ToGuarfee(guarFeesType))
                        .Select(n => new Entities.GuarFees
                        {
                            Type = n.type,
                            MinAmnt = n.MinAmnt,
                            MaxAmnt = n.MaxAmnt,
                            effrate = n.effrate,
                            startdate = n.startdate,
                            enddate = n.enddate,
                            tranchedate = n.tranchedate,
                            absalifefee = n.absalifefee,
                            aimsfee = n.aimsfee,
                            acmbfee = n.acmbfee,
                            TaxLossFee = n.TaxLossFee,
                            rsclevy = n.rsclevy,
                            ACMBRateNaca = n.ACMBRateNaca,
                            NACS = n.NACS,
                            Guarantor = n.Guarantor,
                            MaturityDate = n.MaturityDate,
                            TradeNumber = n.TradeNumber,
                            GuaranteedTradeNumber = n.GuaranteedTradeNumber,
                            FirstIncPmtDate = n.FirstIncPmtDate,
                            AbcapMaturity = n.AbcapMaturity,
                            AbcapAnnuity = n.AbcapAnnuity,
                            Capturer = n.Capturer,
                            Captured = n.Captured,
                            Authorizer = n.Authorizer,
                            Authorized = n.Authorized,
                        }).ToList();
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public void SaveGuarFeesStaging(Entities.GuarFees guarfee)
        {

            if (guarfee == null || string.IsNullOrWhiteSpace(guarfee.Capturer))
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var guarfeesingle = from n in context.GuarFeesStagings
                                    where n.type == guarfee.Type && n.MinAmnt == guarfee.MinAmnt && n.startdate == guarfee.startdate
                                    select n;

                var contextguarfee = guarfeesingle.FirstOrDefault();

                if (contextguarfee == null)
                {
                    context.GuarFeesStagings.Add(WIMQuotesAdminStagingMapping.ToGuarFeesStaging(guarfee));
                }
                else
                {
                    contextguarfee.type = guarfee.Type;
                    contextguarfee.MinAmnt = guarfee.MinAmnt;
                    contextguarfee.MaxAmnt = guarfee.MaxAmnt;
                    contextguarfee.effrate = guarfee.effrate;
                    contextguarfee.startdate = Convert.ToDateTime(guarfee.startdate);
                    contextguarfee.enddate = Convert.ToDateTime(guarfee.enddate);
                    contextguarfee.tranchedate = Convert.ToDateTime(guarfee.tranchedate);
                    contextguarfee.TaxLossFeeOriginal = guarfee.RevisedTaxLossFee;
                    contextguarfee.absalifefeeOriginal = guarfee.Revisedabsalifefee;
                    contextguarfee.aimsfeeOriginal = guarfee.Revisedaimsfee;
                    contextguarfee.absalifefeeRevised = guarfee.absalifefee;
                    contextguarfee.aimsfeeRevised = guarfee.aimsfee;
                    contextguarfee.TaxLossFeeRevised = guarfee.TaxLossFee;
                    contextguarfee.acmbfee = guarfee.acmbfee;
                    contextguarfee.rsclevy = guarfee.rsclevy;
                    contextguarfee.ACMBRateNaca = guarfee.ACMBRateNaca;
                    contextguarfee.NACS = guarfee.NACS;
                    contextguarfee.Guarantor = guarfee.Guarantor;
                    contextguarfee.MaturityDate = Convert.ToDateTime(guarfee.MaturityDate);
                    contextguarfee.TradeNumber = guarfee.TradeNumber;
                    contextguarfee.GuaranteedTradeNumber = guarfee.GuaranteedTradeNumber;
                    contextguarfee.FirstIncPmtDate = guarfee.FirstIncPmtDate;
                    contextguarfee.AbcapMaturity = guarfee.AbcapMaturity;
                    contextguarfee.AbcapAnnuity = guarfee.AbcapAnnuity;
                    contextguarfee.CapturedUserId = guarfee.Capturer;
                    contextguarfee.Captured = guarfee.Captured;
                    contextguarfee.Status = (int)guarfee.Status;
                    contextguarfee.ModifiedDateTime = DateTime.Now;
                }
                context.SaveChanges();
            }
        }

        public List<Entities.GuarFees> GetPendingGuarFees()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.GuarFeesStagings
                    .Where(n => n.Status == (int)Entities.StagingStatus.PendingAuthorise)
                    .Select(WIMQuotesAdminStagingMapping.FromGuarFeesStaging)
                    .ToList();
            }
        }

        public void GuarFeesStagingStatus(string type, DateTime startdate, double MinAmt, Entities.StagingStatus status, string userId)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextGuarFees = (from n in context.GuarFeesStagings
                                       where n.type == type && n.MinAmnt == MinAmt && n.startdate == startdate
                                       select n).FirstOrDefault();

                if (contextGuarFees == null)
                    return;

                contextGuarFees.Status = (int)status;
                contextGuarFees.Authorizer = userId;
                contextGuarFees.Authorized = DateTime.Now;
                contextGuarFees.modifiedbyUserID = userId;
                contextGuarFees.ModifiedDateTime = DateTime.Now;
                context.SaveChanges();
            }
        }

        public void SaveAuthorisedGuarFees(Entities.GuarFees guarFee)
        {
            if (guarFee == null)
                return;

            using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                context.UpdateGuarFeesTable(WIMQuotesApplicationServiceMapping.ToGuarFeesEntity(guarFee));
            }
        }

        public Entities.GuarFees GetGuarFee(string type, DateTime startdate, double minAmt)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextGuarFees = (from n in context.GuarFeesStagings
                                      where n.type == type && n.MinAmnt == minAmt && n.startdate == startdate
                                      select n).FirstOrDefault();

                return WIMQuotesAdminStagingMapping.FromGuarFeesStaging(contextGuarFees);
            }
        }
    }
}
