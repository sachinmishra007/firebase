﻿using System;
using System.Collections.Generic;
using WIMQuotesAdmin.Entities;
using System.Linq;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class AssetClassesLogic : Contracts.IAssetClassesLogic
    {
        #region Constructor

        private readonly DataAccess.Repositories.Contracts.IPortfolioPerformanceRepository _portfolioPerformanceRepository;
        private readonly DataAccess.Repositories.Contracts.IPortfolioAdminRepository _portfolioAdminRepository;

        public AssetClassesLogic(DataAccess.Repositories.Contracts.IPortfolioPerformanceRepository portfolioPerformanceRepository,
            DataAccess.Repositories.Contracts.IPortfolioAdminRepository portfolioAdminRepository)
        {
            _portfolioPerformanceRepository = portfolioPerformanceRepository;
            _portfolioAdminRepository = portfolioAdminRepository;
        }

        #endregion

        public List<Entities.AssetClass> Get(string fundCode)
        {
            return _portfolioPerformanceRepository.GetFundAssetClasses(fundCode);
        }

        public List<Entities.Fund> GetAvailableFunds()
        {
            return _portfolioAdminRepository.GetAssetClassesAvailableFunds();
        }

        public List<Entities.AssetClass> GetUnmappedAssetClassesTypes(string fundCode)
        {
            var unAvailabeAssetsList = new List<AssetClass>();
            var fundAssets = Get(fundCode) ?? new List<AssetClass>();
            var availableAssets = _portfolioPerformanceRepository.GetAssetClassesTypes();

            var unavailableAssets = from availableAsset in availableAssets
                                    where !fundAssets.Any(X => X.Id == availableAsset.Id)
                                    select availableAsset;

            unAvailabeAssetsList = unavailableAssets.ToList();
            foreach (var unalloc in unAvailabeAssetsList)
            {
                if (unalloc.Name == "Unallocated")
                {
                    unAvailabeAssetsList.Remove(unAvailabeAssetsList.Single(una => una.Name == "Unallocated"));
                    break;
                }
            }

            

         return unAvailabeAssetsList;
        }

        //public void SaveFundAssetsStaging(string fundCode, List<AssetClass> assetClasses, string userId)
        //{
        //    _portfolioPerformanceRepository.SaveFundAssetsStaging(fundCode, assetClasses, userId);
        //}

        public void SaveFundAssetsStaging(Entities.AssetClass assetClass,string fundCode, string userId)
        {
            if (assetClass == null || string.IsNullOrWhiteSpace(fundCode) || string.IsNullOrWhiteSpace(userId))
                return;

            assetClass.Status = Entities.StagingStatus.PendingAuthorise;
            _portfolioPerformanceRepository.SaveFundAssetsStaging(assetClass,fundCode, userId);
        }

        public List<FundAssets> GetPendingFundAssets()
        {
            return _portfolioPerformanceRepository.GetPendingFundAssets();
        }

        public void PendingFundAssetsAuthoriseSave(string fundCode,string userId, int assetClassTypeId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            var fundAssets = _portfolioPerformanceRepository.GetPendingFundAsset(fundCode);
            var assetListToUpdate = from updateAssetList in fundAssets.AssetClass
                            where updateAssetList.Id == assetClassTypeId
                            select updateAssetList;

            fundAssets.AssetClass = assetListToUpdate.ToList();

            
           _portfolioPerformanceRepository.UpdateFundAssetsStagingStatus(fundCode, Entities.StagingStatus.Authorise, userId, assetClassTypeId);

            
            if (fundAssets == null)
                return;

            _portfolioPerformanceRepository.SaveAuthorisedFundAsset(fundAssets);

        }

        public void PendingFundAssetsAuthoriseDelete(string fundCode, string userId, int assetClassTypeId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            var fundAssets = _portfolioPerformanceRepository.GetPendingFundAsset(fundCode);

            var assetListToUpdate = from updateAssetList in fundAssets.AssetClass
                                    where updateAssetList.Id == assetClassTypeId
                                    select updateAssetList;

            fundAssets.AssetClass = assetListToUpdate.ToList();

            _portfolioPerformanceRepository.UpdateFundAssetsStagingStatus(fundCode, Entities.StagingStatus.Authorise, userId,assetClassTypeId);

            
            if (fundAssets == null)
                return;

            _portfolioPerformanceRepository.DeleteAuthorisedFundAsset(fundAssets);

        }

        public void PendingFundAssetsUpdateStatus(List<FundAssets> fundAssets, string userId)
        {
            if (fundAssets == null || fundAssets.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return;

            foreach (var fundAsset in fundAssets)
            {
                foreach(var assets in fundAsset.AssetClass)
                {
                    switch (assets.Status)
                    {
                        case Entities.StagingStatus.Authorise:
                            switch (assets.InstructionType)
                            {
                                case Entities.InstructionType.Update:
                                    PendingFundAssetsAuthoriseSave(fundAsset.FundCode, userId,assets.Id);
                                    break;

                                case Entities.InstructionType.Add:
                                    PendingFundAssetsAuthoriseSave(fundAsset.FundCode, userId, assets.Id);
                                    break;
                                case Entities.InstructionType.Delete:
                                    PendingFundAssetsAuthoriseDelete(fundAsset.FundCode, userId,assets.Id);
                                    break;
                            }
                            break;
                        case Entities.StagingStatus.Reject:
                            PendingFundAssetsReject(fundAsset.FundCode, userId,assets.Id);
                            break;
                    }
                    
                        
                }

            }
        }

        private void PendingFundAssetsReject(string fundCode, string userId,int assetClassTypeId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            _portfolioPerformanceRepository.UpdateFundAssetsStagingStatus(fundCode, Entities.StagingStatus.Reject, userId,assetClassTypeId);
        }

        public FundAssets GetFundAssets(string fundCode)
        {
            var fundAssets = _portfolioPerformanceRepository.GetFundWithAssetClasses(fundCode);
            
            var pendingFundAssets = _portfolioPerformanceRepository.GetPendingFundAsset(fundCode);
            

            if (pendingFundAssets == null)
                return fundAssets;

            foreach (var pendingAssets in pendingFundAssets.AssetClass)
            {
                var assets = fundAssets.AssetClass.FirstOrDefault(a => (a.Id == pendingAssets.Id));
                if (assets == null)
                    continue;
                assets.Status = pendingAssets.Status;
                assets.InstructionType = pendingAssets.InstructionType;
            }
             
            fundAssets.UserId = pendingFundAssets.UserId;
            fundAssets.ModifiedDatetime = pendingFundAssets.ModifiedDatetime;

            return fundAssets;
        }


    }
}
