﻿using System.Web.Mvc;

using WIMQuotesAdmin.UI.Web.ActionResults;

namespace WIMQuotesAdmin.UI.Controllers
{
    public class ReportController : Controller
    {
        #region Contructors & DI

        private readonly Domain.Logic.Contracts.IUserAccessControlReportLogic _userAccessControlReportLogic;
        private readonly Domain.Logic.Contracts.IQuoteFrequencyLogic _quoteFrequencyLogic;
        private readonly Domain.Logic.Contracts.IAdminActivityReportLogic _adminActivityReportLogic;
        private readonly Domain.Logic.Contracts.ICDSBreakdownLogic _cdsBreakdownLogic;
        private readonly Domain.Logic.Contracts.IFundTICLogic _fundTICLogic;
        private readonly Domain.Logic.Contracts.IFundSecurityFeesLogic _fundSecurityFeesLogic;

        public ReportController(Domain.Logic.Contracts.IUserAccessControlReportLogic userAccessControlReportLogic,
            Domain.Logic.Contracts.IQuoteFrequencyLogic quoteFrequencyLogic,
            Domain.Logic.Contracts.IAdminActivityReportLogic adminActivityReportLogic,
            Domain.Logic.Contracts.ICDSBreakdownLogic cdsBreakdownLogic,
            Domain.Logic.Contracts.IFundTICLogic fundTICLogic,
            Domain.Logic.Contracts.IFundSecurityFeesLogic fundSecurityFeesLogic)
        {
            _userAccessControlReportLogic = userAccessControlReportLogic;
            _quoteFrequencyLogic = quoteFrequencyLogic;
            _adminActivityReportLogic = adminActivityReportLogic;
            _cdsBreakdownLogic = cdsBreakdownLogic;
            _fundTICLogic = fundTICLogic;
            _fundSecurityFeesLogic = fundSecurityFeesLogic;
        }

        #endregion

        public ActionResult UserAccessControlReportOutput(Entities.UserAccessControlReportDetail details)
        {
            var results = _userAccessControlReportLogic.GetUserAccessControlReportData(details);
            return new ExcelResult<Entities.UserAccessControlReport>(results, "UserAccessControlReport.xlsx");
        }

        public ActionResult UserRolesReportOutput()
        {
            var results = _userAccessControlReportLogic.GetUserRolesReport();
            return new ExcelResult<Entities.User>(results, "UserRolesReport.xlsx");
        }

        public ActionResult QuoteFrequencyReportOutput(Entities.QuoteFrequencyReportDetail reportDetail)
        {
            if (reportDetail == null || (reportDetail.ReportType == Entities.ReportType.BrokerId && string.IsNullOrWhiteSpace(reportDetail.BrokerCode)))
                return new EmptyResult();

            var results = _quoteFrequencyLogic.GetQuoteFrequencyReport(reportDetail);
            return new ExcelResult<Entities.QuoteFrequencyReport>(results, "QuoteFrequencyReport.xlsx");
        }

        public ActionResult AdminActivityReportOutput(Entities.AdminActivityReportDetail reportDetail)
        {
            if (reportDetail == null)
                return new EmptyResult();

            var results = _adminActivityReportLogic.GetAdminActivityReport(reportDetail);
            return new ExcelResult<Entities.AdminActivityReport>(results, "AdminActivityReport.xlsx");
        }

        public ActionResult CDSBreakdownOutput(Entities.QuoteFrequencyReportDetail reportDetail)
        {
            if (reportDetail == null)
                return new EmptyResult();

            var results = _cdsBreakdownLogic.GetCDSBreakdownReport(reportDetail);
            return new ExcelResult<Entities.CDSBreakdownReport>(results, "CDSBreakdownReport.xlsx");
        }

        public ActionResult TICExcelOutput()
        {
            
            var results = _fundTICLogic.GetPendingFundTICs();
            return new ExcelResult<Entities.FundTIC>(results, "FundTICPending.xlsx");
        }

        public ActionResult SecuityFeesExcelOutput()
        {

            var results = _fundSecurityFeesLogic.GetPendingFundSecurityFees();
            return new ExcelResult<Entities.FundSecurityFees>(results, "FundSecurityFeesPending.xlsx");
        }
    }
}