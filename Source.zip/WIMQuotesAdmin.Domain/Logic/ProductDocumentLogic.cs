﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class ProductDocumentLogic : Contracts.IProductDocumentLogic
    {
        #region Constructor

        private readonly DataAccess.Repositories.Contracts.IProductDocumentRepository _productDocumentRepository;

        public ProductDocumentLogic(DataAccess.Repositories.Contracts.IProductDocumentRepository productDocumentRepository)
        {
            _productDocumentRepository = productDocumentRepository;
        }

        #endregion

        public List<Entities.Product> GetProducts()
        {
            return _productDocumentRepository.GetProducts();
        }

        public Entities.File GetProductDocumentFile(string productCode, Entities.Language language, Entities.DocumentType documentType)
        {
            return _productDocumentRepository.GetProductDocument(productCode, language, documentType);
        }

        public bool CheckDocumentExists(string productCode, Entities.Language language, Entities.DocumentType documentType, Entities.Platform platform)
        {
            var document = GetProductDocumentFile(productCode, language, documentType);
            return document != null && document.Data != null && document.Data.Length > 0;
        }
    }
}
