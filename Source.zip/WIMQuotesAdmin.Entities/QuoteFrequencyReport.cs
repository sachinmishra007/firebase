﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Entities
{
   public class QuoteFrequencyReport
    {
        public DateTime DateCreated { get; set; }
        
        public string BrokerCode { get; set; }
        
        public string BrokerFullName { get; set; }
        
        public string BrokerHouse { get; set; }
        
        public string ProductName { get; set; }
        
        public int QuoteNumber { get; set; }
        
        public bool? IsAddition { get; set; }
        
        public bool? IsLumpSum { get; set; }
        
        public bool? IsDebitOrder { get; set; }
        
        public bool? IsIncome { get; set; }
        
        public bool? IsGrowth { get; set; }
        
        public bool? IsCapital { get; set; }

        //public DateTime StartDate { get; set; }
        //public DateTime EndDate { get; set; }
        //public Entities.GenerateReport ReportType { get; set; }
    }
}
