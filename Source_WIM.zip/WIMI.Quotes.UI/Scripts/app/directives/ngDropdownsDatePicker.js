﻿(function ()
{
    'use strict';

    angular.module('common.directives')
        .directive('ngDropdownsDatepicker', function ()
        {
            var isLeapYear = function (year)
            {
                return ((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0);
            };

            return {
                template: '<div>' +
                        '<select ng-chosen="{ width: \'100px\' }" data-placeholder="Year" class="datepicker-year"><option><option></select>' +
                        '<select ng-chosen="{ width: \'140px\' }" data-placeholder="Month" class="datepicker-month"><option><option></select>' +
                        '<select ng-chosen="{ width: \'80px\' }" data-placeholder="Day" class="datepicker-day"><option><option></select>' +
                        '<input type="hidden" name="{{inputName}}" class="datepicker-value" /></div>',
                restrict: 'A',
                require: 'ngModel',
                replace: true,
                scope: {
                    inputName: '=',
                    ngDropdownsDatepicker: '='
                },
                link: function (scope, element, attrs, ngModelCtrl)
                {
                    scope.inputName = element.attr('name');

                    var minDate = new Date();
                    var offsetMs = minDate.getTime() - 1000 * 60 * 60 * 24 * 365 * 100; // Offset by 100 Years;
                    minDate.setTime(offsetMs);

                    var settings = {
                        months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                        monthDaysCount: [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
                        maxDate: new Date(),
                        minDate: minDate,
                        descendingYears: true,
                        daysLimit: undefined,
                        disabled: false
                    };

                    $.extend(settings, scope.ngDropdownsDatepicker);

                    settings.maxDate.setHours(0, 0, 0, 0);
                    settings.minDate.setHours(0, 0, 0, 0);
                    
                    var yearsDropDown = element.find('select.datepicker-year');
                    var monthsDropDown = element.find('select.datepicker-month') ;
                    var daysDropDown = element.find('select.datepicker-day');
                    var dateInput = element.find('input.datepicker-value');


                    // Private Methods

                    var yearOptionsHtml = function ()
                    {
                        var yearDropDowns = "";
                        var startYear = settings.descendingYears ? settings.maxDate.getFullYear() : settings.minDate.getFullYear();
                        var endYear = settings.descendingYears ? settings.minDate.getFullYear() : settings.maxDate.getFullYear();

                        for (var i = startYear; (settings.descendingYears ? i >= endYear : i <= endYear); (settings.descendingYears ? i-- : i++))
                        {
                            yearDropDowns += '<option value="' + i + '">' + i + '</option>';
                        }

                        return yearDropDowns;
                    };

                    var monthsOptionsHtml = function ()
                    {
                        var monthDropDowns = "";

                        for (var i = 0; i < settings.months.length; i++)
                        {
                            monthDropDowns += '<option value="' + (i + 1) + '">' + settings.months[i] + '</option>';
                        }

                        return monthDropDowns;
                    };

                    var getSelectedDateString = function ()
                    {
                        var month = (monthsDropDown.val() < 10 ? '0' : '') + monthsDropDown.val();
                        var day = (daysDropDown.val() < 10 ? '0' : '') + daysDropDown.val();
                        var dateString = yearsDropDown.val() + '-' + month + '-' + day + 'T00:00:00.000Z';

                        return dateString;
                    };

                    var getSelectedDate = function ()
                    {
                        return new Date(getSelectedDateString());
                    };

                    var isValidSelectedDate = function ()
                    {
                        var date = getSelectedDate();
                        return !isNaN(date.getTime());
                    };

                    var daysOptionsHtml = function ()
                    {
                        var dayDropDowns = "";
                        
                        if (typeof settings.daysLimit !== "undefined" && settings.daysLimit.length > 0)
                        {
                            for (var y = 0; y < settings.daysLimit.length; y++)
                            {
                                dayDropDowns += '<option value="' + settings.daysLimit[y] + '">' + settings.daysLimit[y] + '</option>';
                            }
                        } 
                        else 
                        {
                            for (var i = 1; i <= 31; i++)
                            {
                                dayDropDowns += '<option value="' + i + '">' + i + '</option>';
                        }
                        }

                        return dayDropDowns;
                    };

                    var setDropDownYear = function ()
                    {
                        var selectedYear = yearsDropDown.val();
                        var minYear = settings.minDate.getFullYear();

                        yearsDropDown.find('option').filter(function ()
                        {
                            return $(this).attr("value") < minYear;
                        }).prop('disabled', true);

                        if (selectedYear !== "" && selectedYear < minYear)
                        {
                            yearsDropDown.val(minYear);
                        }

                        yearsDropDown.trigger('chosen:updated');
                    };

                    var setDropDownMonth = function ()
                    {
                        monthsDropDown.find('option').prop('disabled', false);

                        var selectedDate = getSelectedDate();
                        var selectedMonth = monthsDropDown.val();

                        var maxMonth = 12;
                        var minMonth = 1;

                        if (selectedDate.getFullYear() === settings.minDate.getFullYear())
                        {
                            minMonth = settings.minDate.getMonth() + 1;
                        }

                        if (selectedDate.getFullYear() === settings.maxDate.getFullYear())
                        {
                            maxMonth = settings.maxDate.getMonth() + 1;
                        }

                        monthsDropDown.find('option').filter(function ()
                        {
                            return $(this).attr("value") < minMonth || $(this).attr("value") > maxMonth;
                        }).prop('disabled', true);

                        if (selectedDate.getFullYear() === settings.minDate.getFullYear() &&
                            selectedMonth < minMonth)
                        {
                            monthsDropDown.val(minMonth);
                        }

                        if (selectedDate.getFullYear() === settings.maxDate.getFullYear() &&
                            selectedMonth > maxMonth)
                        {
                            monthsDropDown.val(maxMonth);
                        }

                        monthsDropDown.trigger('chosen:updated');
                    };

                    var setDropdownDays = function ()
                    {
                        daysDropDown.find('option').prop('disabled', false);

                        var maxDay;
                        var minDay = 1;

                        var selectedDate = getSelectedDate();
                        var selectedDay = daysDropDown.val();
                        
                        if (selectedDate.getMonth() === settings.minDate.getMonth() &&
                            selectedDate.getFullYear() === settings.minDate.getFullYear())
                        {
                            minDay = settings.minDate.getDate();
                        }

                        if (monthsDropDown.val() === '2')
                        {
                            maxDay = isLeapYear(yearsDropDown.val()) ? 29 : 28;
                        }
                        else
                        {
                            maxDay = settings.monthDaysCount[monthsDropDown.val() - 1];
                        }

                        if (selectedDate.getMonth() === settings.maxDate.getMonth() &&
                            selectedDate.getFullYear() === settings.maxDate.getFullYear() &&
                            maxDay > settings.maxDate.getDate())
                        {
                            maxDay = settings.maxDate.getDate();
                        }

                        daysDropDown.find('option').filter(function ()
                        {
                            return $(this).attr("value") < minDay || $(this).attr("value") > maxDay;
                        }).prop('disabled', true);

                        if (selectedDay !== "" && selectedDay < minDay)
                        {
                            daysDropDown.val(minDay);
                        }

                        if (selectedDay !== "" && selectedDay > maxDay)
                        {
                            daysDropDown.val(maxDay);
                        }

                        daysDropDown.trigger('chosen:updated');
                    };


                    // On Load

                    if (settings.disabled)
                    {
                        yearsDropDown.prop('disabled', true);
                        monthsDropDown.prop('disabled', true);
                        daysDropDown.prop('disabled', true);
                    }

                    yearsDropDown.append(yearOptionsHtml());
                    monthsDropDown.append(monthsOptionsHtml());
                    daysDropDown.append(daysOptionsHtml());

                    setDropDownYear();
                    setDropdownDays();
                    setDropDownMonth();


                    // Events / Hook Ins

                    ngModelCtrl.$render = function ()
                    {
                        if (typeof ngModelCtrl.$viewValue === "undefined" || ngModelCtrl.$viewValue === null)
                            return;

                        var timestamp = Date.parse(ngModelCtrl.$viewValue);

                        if (isNaN(timestamp))
                            return;

                        var date = new Date(ngModelCtrl.$viewValue);

                        yearsDropDown.val(date.getFullYear()).trigger('chosen:updated');
                        monthsDropDown.val(date.getMonth() + 1).trigger('chosen:updated');
                        daysDropDown.val(date.getDate());

                        setDropDownMonth();
                        setDropdownDays();

                        daysDropDown.val(date.getDate()).trigger('chosen:updated');
                        dateInput.val(getSelectedDateString());
                    }

                    element.find('select').bind('change', function ()
                    {
                        setDropDownMonth();
                        setDropdownDays();

                        ngModelCtrl.$setViewValue(getSelectedDate());

                        dateInput.val(isValidSelectedDate() ? getSelectedDateString() : '');
                    });
                }
            };
        });

})();
