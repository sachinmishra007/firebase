﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class ValidationRepository : IValidationRepository
    {
        public List<Entities.Validation> GetUIValidations()
        {
            using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                var validations = context.GetUIValidations();

                return validations.Select(v => new Entities.Validation
                {
                    Id = v.Id,
                    FieldName = v.FieldName,
                    Message = v.Message
                }).ToList();
            }
        }


        public void SaveValidationToStaging(Entities.Validation validation)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextValid = Mappings.WIMQuotesAdminStagingMapping.ToValidationStaging(validation);

                if (contextValid == null)
                    return;

                context.ValidationStagings.Add(contextValid);
                context.SaveChanges();
            }
        }


        public List<Entities.Validation> GetPendingValidation()
        {
            using(var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.ValidationStagings
                               .Where(v => v.Status == (int)Entities.StagingStatus.PendingAuthorise)
                               .Select(Mappings.WIMQuotesAdminStagingMapping.FromValidationStaging)
                               .ToList();
            }
        }


        public void UpdateValidationStagingStatus(Entities.Validation validation , Entities.StagingStatus status , string userId)
        {
            if (validation == null || string.IsNullOrWhiteSpace(userId))
                return;
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextValidations = context.ValidationStagings
                               .Where(v => v.Id == validation.Id &&
                                v.Status == (int)Entities.StagingStatus.PendingAuthorise);

                foreach (var contextValidation in contextValidations)
                {
                    contextValidation.Status = (int)status;
                    contextValidation.ModifiedUserId = userId;
                    contextValidation.ModifiedDateTime = DateTime.Now;
                }

                context.SaveChanges();
                               
            }
        }

        public void SaveAuthorisedValidation(Entities.Validation validation)
        {
            if (validation == null)
                return;

            using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                context.SaveValidation(Mappings.WIMQuotesApplicationServiceMapping.ToValidation(validation));
            }
        }


        public Entities.Validation GetPendinValidationById(int id)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.ValidationStagings
                       .Where(v => v.Id == id && v.Status == (int)Entities.StagingStatus.PendingAuthorise)
                       .Select(Mappings.WIMQuotesAdminStagingMapping.FromValidationStaging)
                       .FirstOrDefault();
            }
        }
    }
}
