﻿(function () {
    'use strict';

    angular
        .module('quotesApp.services')
        .factory('fundService', ['$http', function ($http) {
            var fundService = {};

            fundService.getFundsList = function (productCode, fundRangeCode, brokerCode, IsBringZeroAdminFund) {

                IsBringZeroAdminFund = IsBringZeroAdminFund || false;

                return $http({
                    url: 'api/Fund/?productCode=' + productCode + '&fundRangeCode=' + fundRangeCode + '&brokerCode=' + brokerCode + '&IsBringZeroAdminFund=' + IsBringZeroAdminFund
                });
            };

            fundService.getFundFactSheetsList = function (quoteNumber) {
                return $http({ url: 'api/Fund/FundFactSheetsList/?quoteNumber=' + quoteNumber });
            };

            return fundService;
        }]);
})();
