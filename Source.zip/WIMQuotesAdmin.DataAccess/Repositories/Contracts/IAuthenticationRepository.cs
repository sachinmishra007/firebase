﻿namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IAuthenticationRepository
    {
        bool AuthenticateUser(string username, string password);
        Entities.UserRole? GetUserRole(string userId);
    }
}
