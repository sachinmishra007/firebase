﻿using MorningStarWebTool.Common;
using MorningStarWebTool.Entites.Entities;
using MorningStarWebTool.Repositories.Contract;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorningStarWebTool.Repositories
{
    public class MorningStarDetailsRepository : IMorningStarDetailsRepository
    {
        private ToolConfig _msConfigTool = null;
        private Util _utilites = null;
        private readonly ISettingLogicRepository _settingLogic = null;

        public MorningStarDetailsRepository(ISettingLogicRepository settingLogic)
        {
            _settingLogic = settingLogic;
            _msConfigTool = new ToolConfig();
            _utilites = new Util();
        }
        public object GetMorningStarDetails(string _toolName)
        {
            var _AuthURL = _utilites.GetMorningStarInformation();
            var InstanceId = _settingLogic.GetApplicationSetting<string>("InstanceId");
            var Environment = _settingLogic.GetApplicationSetting<string>("Environment");
            var CustomStyles = _settingLogic.GetApplicationSetting<string>("CustomStyles");
            if (_toolName == _settingLogic.GetApplicationSetting<string>("FUNDSCREENER"))
            {
                var _fundScreenerLoadingDetails = new
                {
                    AuthUrlTemplate = _AuthURL,
                    InstanceId = InstanceId,
                    Environment = Environment,
                    CustomStyles = CustomStyles,
                    ConfigurationNamespace = _settingLogic.GetApplicationSetting<string>("ConfigurationNamespace_FundScreener")

                };
                return _fundScreenerLoadingDetails;
            }
            else if (_toolName == _settingLogic.GetApplicationSetting<string>("XRAY"))
            {
                var _fundScreenerXRAYDetails = new
                {
                    AuthUrlTemplate = _AuthURL,
                    InstanceId = InstanceId,
                    Environment = Environment,
                    CustomStyles = CustomStyles,
                    ConfigurationNamespace = _settingLogic.GetApplicationSetting<string>("ConfigurationNamespace_XRAY")
                };
                return _fundScreenerXRAYDetails;
            }
            else if (_toolName == _settingLogic.GetApplicationSetting<string>("FUNDREPORT"))
            {
                var _fundReportDetails = new
                {
                    AuthUrlTemplate = _AuthURL,
                    InstanceId = InstanceId,
                    Environment = Environment,
                    CustomStyles = CustomStyles,
                    ConfigurationNamespace = _settingLogic.GetApplicationSetting<string>("ConfigurationNamespace_FundReport")
                };
                return _fundReportDetails;
            }
            else
            {
                var _fundInvalidToolOption = new
                {
                    Result = "Invalid Tool Option"
                };
                return _fundInvalidToolOption;
            }
        }

    }

}

