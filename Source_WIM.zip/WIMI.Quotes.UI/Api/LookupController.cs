﻿using System.Collections.Generic;
using System.Web.Http;

using WIMI.Quotes.Model.Domain.Contracts;
using WIMI.Quotes.UI.Web.ActionFilters;

namespace WIMI.Quotes.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class LookupController : ApiController
    {
        #region Contructors & DI

        private readonly ILookupLogic _lookupLogic;

        private readonly ITaxYearLogic _taxYearLogic;

        public LookupController(ILookupLogic lookupLogic, ITaxYearLogic taxYearLogic)
        {
            _lookupLogic = lookupLogic;
            _taxYearLogic = taxYearLogic;
        }

        #endregion

        [Route("api/Lookup/Items")]
        public IEnumerable<Entities.LookupItem> GetItems(string productCode, string subCode)
        {
            return _lookupLogic.GetFundCategories(productCode,subCode);     
        }

        // GET: api/Lookup/{code}
        [Route("api/Lookup/{code}")]
        public List<Entities.LookupItem> Get(string code)
        {
            return _lookupLogic.Get(code);
        }


        // GET: api/TaxYear
        [Route("api/TaxYear")]
        public List<Entities.TaxYears> Get()
        {
            return _taxYearLogic.GetTaxYear();
        }
    }
}