﻿using System;
using System.Collections.Generic;
using Moq;

namespace WIMI.Quotes.Tests.Common.MockHelpers
{
    public static class MockRepositories
    {
        public static Mock<Repositories.Contracts.IWIMQuotesApplicationServiceRepository> MockQuotesApplicationService(string searchTerm)
        {
            var mockRepository = new Mock<Repositories.Contracts.IWIMQuotesApplicationServiceRepository>();

            mockRepository
                .Setup(r => r.GetAdvisors(searchTerm))
                .Returns(new List<Entities.Advisor> { new Entities.Advisor { Code = "0000", FullName = "Test, Test" } });

            mockRepository
                .Setup(r => r.GetClientsByBroker("00012346", "jon"))
                .Returns(new List<Entities.Client> { new Entities.Client { ClientNumber = "00001", FullName = "Test, Test" } });

            return mockRepository;
        }

        public static Mock<Repositories.Contracts.IWIMQuotesDataRepository> MockQuotesDataRepository()
        {
            var mockRepository = new Mock<Repositories.Contracts.IWIMQuotesDataRepository>();

            mockRepository
                .Setup(r => r.GetFundsList("INVACC", "SR", "00012346"))
                .Returns(new List<Entities.Fund> { new Entities.Fund { Code = "ABMM", Name = "Allan Gray Equity Fund" } });

            mockRepository
                .Setup(r => r.GetProductsList("00012346", "I", ""))
                .Returns(new List<Entities.Product> { new Entities.Product { Code = "INVACC", Name = "Investment Account" } });

            mockRepository
                .Setup(r => r.GetQuoteHistoryItems("00012346", "00001", Entities.QuoteItemStatus.Complete))
                .Returns(new List<Entities.QuoteHistoryItem> { new Entities.QuoteHistoryItem() });

            mockRepository
                .Setup(r => r.GetQuoteItem(Guid.Empty))
                .Returns(new Entities.QuoteItem { QuoteItemId = Guid.Empty });

            return mockRepository;
        }
    }
}
