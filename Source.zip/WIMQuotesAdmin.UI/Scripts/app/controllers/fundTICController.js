﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('fundTICController', ['$scope', '$timeout', 'FileUploader', 'fundTICService', function ($scope, $timeout, FileUploader, fundTICService)
        {
            var fileSizeLimit = 3000000; //2mb

            $scope.pendingFundTICsList = [];
            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
            $scope.isViewVisible = false;

            $scope.fundNameFilter = '';
            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];
            $scope.isUploadPendingVisible = $scope.application.userProfile.Role === 'AdminUser';
            // Private Methods



            var getPendingTIC = function ()
            {
                $scope.application.showLoading = true;
                fundTICService.getPendingFundTICs().success(function (response)
                {
                    $scope.pendingFundTICsList = response;
                    $scope.isViewVisible = response.length === 0;
                    $scope.isPendingVisible = !$scope.isPendingVisible ? true : $scope.isPendingVisible;
                    $scope.application.showLoading = false;

                });
            }


            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 3000);
            }


            var filteredFundTICCount = function ()
            {

                var count = 0;

                for (var i = 0; i < $scope.pendingFundTICsList.length; i++)
                {
                    if ($scope.filterFundTIC($scope.pendingFundTICsList[i]))
                        count++;
                }

                return count;
            };

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 3000);
            }

            $scope.uploader = new FileUploader({
                url: 'api/FundTIC/UploadFile'
            });


            $scope.uploader.filters.push({
                name: 'filterExcelOnly',
                fn: function (item)
                {
                    var valid = true;

                 

                    if (item.type !== "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    {
                        if (item.size > fileSizeLimit) {
                            valid = false;
                        }

                        valid = false;
                    }

                    return valid;
                }
            });
            // On Load

            if ($scope.isPendingVisible || $scope.isUploadPendingVisible)
            {
                getPendingTIC();
            }

            // Behaviours


            $scope.filterFundTIC = function (item)
            {

                var i = $scope.fundNameFilter;
                return (item.FundName.toLowerCase().indexOf($scope.fundNameFilter.toLowerCase()) !== -1 ||
                    item.FundCode.toLowerCase().indexOf($scope.fundNameFilter.toLowerCase()) !== -1);
            };



            $scope.updatePendingStatuses = function ()
            {

                $scope.application.showLoading = true;
                fundTICService.updatePendingStatuses().success(function (response)
                {
                    $scope.application.showLoading = false;
                    $scope.isPendingVisible = false;
                    $scope.isViewVisible = true;
                });
                showMessage('Fund TIC Authorized successfully.');
            };

            $scope.updateRejectStatuses = function ()
            {
                //debugger;
                $scope.application.showLoading = true;
                fundTICService.updateRejectStatuses().success(function (response)
                {
                    $scope.application.showLoading = false;
                    $scope.isPendingVisible = false;
                    $scope.isViewVisible = true;
                });
                showMessage('Fund TIC Rejected successfully.');

            };

            $scope.downloadReportOutput = function ()
            {

                $scope.downloadUrl = "Report/TICExcelOutput?rnd=" + new Date().getTime();
            };

            $scope.anyPendingFundTICSelected = function ()
            {

                if ($scope.pendingFundTICsList[0].UserId === $scope.application.userProfile.Id)
                {
                    return true;
                }

            };


            $scope.getUploadedFile = function ()
            {

                if ($scope.excelFile === undefined)
                {
                    return true;
                }

            };

            // Behaviours
            $scope.saveFundTICSheet = function ()
            {

                $scope.application.showLoading = true;
                $scope.uploader.uploadAll();
            };

            $scope.uploader.onCompleteAll = function ()
            {

                $scope.$addMode = false;

                $scope.application.showLoading = false;

                showMessage('File Uploaded successfully. Pending authorisation.');
                getPendingTIC();
            };

            // Pagination

            $scope.firstPage = function ()
            {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function ()
            {
                if ($scope.currentPage > 0)
                {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function ()
            {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function ()
            {
                return Math.ceil(filteredFundTICCount() / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function ()
            {
                if ($scope.currentPage < $scope.pageCount())
                {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function ()
            {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function ()
            {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n)
            {
                $scope.currentPage = n;
            };

            $scope.range = function ()
            {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0)
                {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize)
                {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++)
                {
                    range.push(i);
                }

                return range;
            };

        }]);
})();