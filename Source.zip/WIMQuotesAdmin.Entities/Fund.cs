﻿namespace WIMQuotesAdmin.Entities
{
    public class Fund
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public decimal SplitPercentage { get; set; }
    }
}
