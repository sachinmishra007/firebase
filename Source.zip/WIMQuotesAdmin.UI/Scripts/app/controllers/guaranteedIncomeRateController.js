﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('guaranteedIncomeRateController', ['$scope', 'guaranteedIncomeRateService', function ($scope, guaranteedIncomeRateService)
        {
            $scope.productTypes = guaranteedIncomeRateService.GetProductTypes();
            $scope.guarantors = guaranteedIncomeRateService.GetGuarantors();
            $scope.selectedProduct = {};
            $scope.selectedGuarantor = {};
            $scope.capturedRates = {};
            $scope.canAuth = false;
            $scope.minStartDate = new Date();
            $scope.maxMaturityDate = new Date();
            $scope.maxRateDate = new Date();
            $scope.maxPlacementDate = new Date();
            $scope.canSave = true;
            // On Load
            $scope.init = function ()
            {
                var offsetMs = 1000 * 60 * 60 * 24 * 7; // Offset by 7 Days;
                var offsetMsMaturity = 1000 * 60 * 60 * 24 * 3650; // Offset by 7 Days;

                $scope.minStartDate.setTime($scope.minStartDate.getTime() - offsetMs);
                $scope.maxMaturityDate.setTime($scope.maxMaturityDate.getTime() + offsetMsMaturity);
                $scope.capturedRates.StartDate = $scope.formatDate(new Date());
                $scope.populateDates();
                $scope.capturedRates.User = $scope.application.userProfile.Id;
                $scope.determineAccess();
            };

            //Behaviors
            $scope.determineAccess = function ()
            {
                //debugger;
                //if (($scope.application.userProfile.Role === 'SuperUser') && $scope.application.userProfile.Id !== $scope.capturedRates.User && $scope.capturedRates.RateAfterFees > 0)
                if (($scope.application.userProfile.Role === 'SuperUser') && $scope.application.userProfile.Id !== $scope.capturedRates.User && $scope.capturedRates.FeeStatus === "Pending") {
                    $scope.canAuth = true;
                    $scope.canSave = false;
                }

                else {
                    $scope.canAuth = false;
                    $scope.canSave = true;

                }

                if ($scope.capturedRates.FeeStatus === "Authorised")
                    $scope.canSave = false;
            };

            $scope.captureRates = function ()
            {
                debugger;
                $scope.capturedRates.Guarantor = $scope.selectedGuarantor.Code;
                $scope.capturedRates.ProductType = $scope.selectedProduct.Code;
                $scope.capturedRates.User = $scope.application.userProfile.Id;

                guaranteedIncomeRateService.CaptureRates($scope.capturedRates).success(function (response)
                {
                    $scope.capturedRates = response;
                    $scope.selectedGuarantor.Code = $scope.capturedRates.Guarantor;
                   
                    $scope.determineAccess();
                });
            };

            $scope.updateRates = function ()
            {
                guaranteedIncomeRateService.GetLatestRates($scope.selectedProduct.Code).success(function (response)
                {
                    
                    $scope.capturedRates = response;
                    $scope.selectedGuarantor.Code = $scope.capturedRates.Guarantor;
                    $scope.populateDates();
                    $scope.determineAccess();
                });
            };

            $scope.authoriseRates = function ()
            {
                guaranteedIncomeRateService.AuthoriseRates($scope.capturedRates).success(function (response)
                {
                    $scope.canAuth = false;
                });
            };

            $scope.rejectRates = function ()
            {
                var jsonProductCode = angular.toJson($scope.selectedProduct.Code);
                guaranteedIncomeRateService.RejectRates(jsonProductCode).success(function ()
                {
                    $scope.canAuth = false;
                });
            };

            $scope.populateDates = function ()
            {
                debugger;
                var date = new Date();
                var day = date.getUTCDate();

                if ($scope.capturedRates.StartDate !== null) {
                    if ($scope.capturedRates.StartDate.length !== 10) {
                        $scope.capturedRates.StartDate = $scope.formatDate($scope.capturedRates.StartDate);
                    }
                }
                else {
                    $scope.capturedRates.StartDate = $scope.formatDate(new Date());
                }

                var convertedDate = new Date(Date.parse($scope.capturedRates.StartDate.replace(/-/g, " ")));

                $scope.capturedRates.PlacementDate = $scope.formatDate($scope.getPlacementDate(convertedDate));
                $scope.capturedRates.EndDate = $scope.formatDate($scope.getEndDate(convertedDate));
                if ($scope.capturedRates.MaturityDate === null || $scope.capturedRates.MaturityDate === undefined)
                {
                    $scope.capturedRates.MaturityDate = $scope.getMaturityDate();
                }

                if ($scope.capturedRates.FirstIncomeDate === null || $scope.capturedRates.FirstIncomeDate === undefined)
                {
                    $scope.capturedRates.FirstIncomeDate = $scope.capturedRates.EndDate;
                }
               
               
            };

            $scope.getPlacementDate = function (date)
            {
                var date = new Date($scope.getNextWeekMonday(date));
                $scope.maxPlacementDate.setTime(date);
                return date;
               // return $scope.getNextWeekMonday(date);
            };

            $scope.getEndDate = function (date)
            {
                var date = new Date($scope.getNextWeekSaturday(date));
                $scope.maxRateDate.setTime(date);
                return date;
                //return $scope.getNextWeekSaturday(date);
            };

            $scope.getMaturityDate = function ()
            {
                var padLeft = new RegExp(".{2}$");
                var month = $scope.capturedRates.StartDate.substring(5, 7);
                var year = parseInt($scope.capturedRates.StartDate.substring(0, 4)) + 5;
                var day = $scope.capturedRates.StartDate.substring(8, 10);

                return (year + "/" + month + "/" + day);
            };

            $scope.getNextDayOfWeek = function (date, dayOfWeek)
            {
                // Code to check that date and dayOfWeek are valid left as an exercise ;)

                var date1 = Date();
                var date2 = date1.getDate();
                var resultDate = new date2.getTime();

                resultDate.setDate(date2.getDate() + (7 + dayOfWeek - date2.getDay()) % 7);

                return resultDate;
            };

            $scope.getNextWeekMonday = function (SDate) {
               //debugger;
                var date = new Date();

                var d = new Date(SDate);

                var d1 = d.getDate();
                var d2 = d.getDay();
                var diff = d.getDate() - d.getDay() + 1

                if (d.getDay() == 0)
                    diff -= 7;
                diff += 7; // ugly hack to get next monday instead of current one
                return new Date(d.setDate(diff));
            };

            //$scope.getNextWeekMonday = function ()
            //{
            //    var date = new Date();
            //    var d = new Date(date.getTime());
            //    var diff = d.getDate() - d.getDay() + 1;
            //    if (d.getDay() == 0)
            //        diff -= 7;
            //    diff += 7; // ugly hack to get next monday instead of current one
            //    return new Date(d.setDate(diff));
            //};

            $scope.getNextWeekSaturday = function (SDate) {
                
                //debugger;
                var date = new Date(SDate);
                var date0 = new Date()
                var d = $scope.getNextWeekMonday(date);
                var d0 = new Date(date0.getTime());
               // return d.getDate() < d0.getDate() ? new Date(d.setDate(d.getDate() - 2)) : new Date(d.setDate(d.getDate() + 5));

                return new Date(d.setDate(d.getDate() -2));
            };

            //$scope.getNextWeekSaturday = function ()
            //{
            //    var date = new Date();
            //    var d = $scope.getNextWeekMonday();
            //    return new Date(d.setDate(d.getDate() + 5));
            //};

            $scope.formatDate = function (date)
            {
                var year, month, day;
                year = String(date.getFullYear());
                month = String(date.getMonth() + 1);
                if (month.length == 1)
                {
                    month = "0" + month;
                }
                day = String(date.getDate());
                if (day.length == 1)
                {
                    day = "0" + day;
                }
                return year + "/" + month + "/" + day;
            };
        }]);
})();
