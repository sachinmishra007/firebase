﻿using System;

namespace WIMQuotesAdmin.Entities
{
    public class UserAccessControlReportDetail
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
