﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IValidationRepository
    {
        List<Entities.Validation> GetUIValidations();
        void SaveValidationToStaging(Entities.Validation validation);
        List<Entities.Validation> GetPendingValidation();
        void UpdateValidationStagingStatus(Entities.Validation validation, Entities.StagingStatus status, string userId);
        void SaveAuthorisedValidation(Entities.Validation validation);
        Entities.Validation GetPendinValidationById(int id);

    }
}
