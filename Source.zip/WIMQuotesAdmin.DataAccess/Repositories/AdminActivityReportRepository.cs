﻿using System.Collections.Generic;
using System.Linq;

using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class AdminActivityReportRepository : IAdminActivityReportRepository
    {
        public List<Entities.AdminActivityReport>GetAdminActivityReport(Entities.AdminActivityReportDetail detail)
        {
            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                var report = context.pActivityReport(detail.StartDate, detail.EndDate);

                return report.Select(r => new Entities.AdminActivityReport
                {
                    ActivityTimeStamp = r.ActivityTimeStamp,
                    UserId = r.UserId,
                    UserRole = r.UserRole,
                    Action = r.StagingStatus,
                    Section = r.Section,
                    ChangeType = r.ChangeType,
                    ChangeField = r.ChangeField
                }).ToList();
            }
        }
    }
}
