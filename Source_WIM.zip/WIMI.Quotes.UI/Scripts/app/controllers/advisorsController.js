﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('advisorsController', ['$scope', '$rootScope', 'advisorService', function ($scope, $rootScope, advisorService)
        {
            $scope.advisors = [];
            $scope.searchableAdvisors = $scope.application.role === "Admin";


            // Behaviours 

            $scope.searchAdvisors = function (searchTerm)
            {
                
                return advisorService.searchAdvisors(searchTerm).success(function (response)
                {
                    $scope.advisors = response;
                });
            };

            $scope.setAdvisor = function (selectedAdvisor)
            {
                
                $scope.application.selectedAdvisor = selectedAdvisor;
                $scope.application.selectedClient = undefined;

                $rootScope.$emit('Advisor.Selected', { advisorCode: (selectedAdvisor || {}).Code });
            };


            // On Load

            if (!$scope.searchableAdvisors)
            {
                advisorService.getCurrentAdivsor().success(function (response)
                {
                    $scope.application.selectedAdvisor = response;
                });
            }
            
        }]);
})();