﻿using System.Net;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMI.Quotes.UI.Web.ActionFilters;

namespace WIMI.Quotes.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class IntegrationController : ApiController
    {
        #region Contructors & DI

        private readonly Model.Domain.Contracts.IIntegrationLogic _integrationLogic;

        public IntegrationController(Model.Domain.Contracts.IIntegrationLogic integrationLogic)
        {
            _integrationLogic = integrationLogic;
        }

        #endregion

        // GET: api/Integration/CreateNewApplicationForm
        [Route("api/Integration/CreateNewApplicationForm/{quoteNumber}")]
        [HttpGet]
        public Entities.Transfer.TransferSessionDetails CreateNewApplicationForm(int quoteNumber, [ModelBinder]IPrincipal user)
        {
            if (user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return _integrationLogic.OnlineTransactingProcessApplication(quoteNumber, user.Identity.Name);
        }
    }
}
