﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class UserAccessControlReportRepository : IUserAccessControlReportRepository
    {
        public List<Entities.UserAccessControlReport> GetUserAccessControlReport(Entities.UserAccessControlReportDetail detail)
        {
            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                return context.UserAudits
                    .Where(u => DbFunctions.TruncateTime(u.ActivityTimestamp) >= DbFunctions.TruncateTime(detail.StartDate) && 
                                DbFunctions.TruncateTime(u.ActivityTimestamp) <= DbFunctions.TruncateTime(detail.EndDate))
                    .Select(r => new Entities.UserAccessControlReport
                    {
                        Activity = r.Activity,
                        ActivityTimeStamp = r.ActivityTimestamp.Value,
                        SuperUserId = r.SuperUser,
                        UserImpacted = r.ImpactedUser,
                        UserRoleAssigned = r.RoleAssigned
                    }).ToList();
            }
        }

        public List<Entities.User> GetUserRolesReport()
        {
            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                return context.Users.Where(u => u.IsActive).Select(u => new Entities.User
                {
                    Name = u.UserName,
                    Id = u.Id.ToString(),
                    IsActive = u.IsActive,
                    CreatedOn = u.CreatedOn,
                    Role = (Entities.UserRole) u.RoleId,
                    SuperUSer = u.SuperUser
                }).ToList();
            }
        }
    }
}
