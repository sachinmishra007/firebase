﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('fundMangementFeesController', ['$scope', '$timeout', 'fundManagementFeesService', 'lookupService', 'wrapService',
            function ($scope, $timeout, fundManagementFeesService, lookupService, wrapService)
        {
            $scope.fundManageFeesList = [];
            $scope.unmappedFundsList = [];
            $scope.pendingFundManageFeeList = [];
            $scope.wrapsList = [];

            $scope.fundTypes = lookupService.getFundTypes();
            $scope.selectedFundType = $scope.fundTypes[0];

            $scope.fundNameFilter = '';
            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];

            $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' ||
                $scope.application.currentMenuItem.AccessLevel === 'AdminRights';
            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';


            // Private Methods

            var removePendingFundManageFee = function (FundId)
            {
                for (var i = 0; i < $scope.pendingFundManageFeeList.length; i++)
                {
                    if ($scope.pendingFundManageFeeList[i].FundId === FundId)
                        $scope.pendingFundManageFeeList.splice(i, 1);
                }
            }

            var filteredFundManageFeeCount = function ()
            {
                var count = 0;

                for (var i = 0; i < $scope.fundManageFeesList.length; i++)
                {
                    if ($scope.filterFundManageFee($scope.fundManageFeesList[i]))
                        count++;
                }

                return count;
            };

            var retrieveFundManagementFeesList = function ()
            {
                $scope.application.showLoading = true;

                var fundType = $scope.selectedFundType.Code;
                var fundCode = angular.isDefined($scope.selectedWrap) ? $scope.selectedWrap.Code : '';

                fundManagementFeesService.getFundManagementFees(fundType, fundCode).success(function (response)
                {
                    $scope.fundManageFeesList = response;
                    $scope.application.showLoading = false;
                });
            }

            var retrieveFundManagementFeesList = function (isShow) {
                
                $scope.application.showLoading = isShow;

                var fundType = $scope.selectedFundType.Code;
                var fundCode = angular.isDefined($scope.selectedWrap) ? $scope.selectedWrap.Code : '';

                fundManagementFeesService.getFundManagementFees(fundType, fundCode).success(function (response) {
                    $scope.fundManageFeesList = response;
                    $scope.application.showLoading = false;
                });
            }

            var retrieveUnmappedFundsList = function ()
            {
                fundManagementFeesService.getUnmappedFunds().success(function (response)
                {
                    $scope.unmappedFundsList = response;
                });
            };

            var retrieveWrapsList = function ()
            {
                wrapService.getAvailableWraps().success(function (response)
                {
                    $scope.wrapsList = response;
                });
            };

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function () {
                    $scope.showSuccessMessage = false;
                }, 5000);
            }


            // On Load

            retrieveFundManagementFeesList();
            retrieveUnmappedFundsList();
            retrieveWrapsList();

            if ($scope.isPendingVisible)
            {
                fundManagementFeesService.getPendingFundManagementFees().success(function (response)
                {
                    $scope.pendingFundManageFeeList = response;
                    $scope.isViewVisible = response.length === 0;
                });
            }
            else
            {
                $scope.isViewVisible = true;
            }
            
            // Behaviours

            $scope.editManageFees = function (fundManageFees)
            {
                
                fundManageFees.OriginalValue = fundManageFees.Value;
                fundManageFees.$editMode = true;
            };

            $scope.cancelEditManageFees = function (fundManageFees)
            {
                fundManageFees.Value = fundManageFees.OriginalValue;
                fundManageFees.$editMode = false;
            };

            $scope.saveEditManageFees = function (fundManageFees)
            {
                fundManagementFeesService.saveFundManagementFees(fundManageFees).success(function ()
                {
                    fundManageFees.Status = 'PendingAuthorise';
                    fundManageFees.$editMode = false;

                    showMessage('Fund Management Fees saved successfully. Pending authorisation.');
                });
            };


            $scope.deleteManageFees = function (fundManageFees)
            {
                fundManageFees.InstructionType = 'Delete';

                fundManagementFeesService.saveFundManagementFees(fundManageFees).success(function ()
                {
                    fundManageFees.Status = 'PendingAuthorise';
                    fundManageFees.$editMode = false;

                    showMessage('Fund Management Fees set for deletion. Pending authorisation.');
                });
            };

            $scope.openAddManageFees = function ()
            {
                $scope.newFundManageFee = undefined
                $scope.$addMode = true;
            };

            $scope.addManageFeesCancel = function ()
            {
                $scope.newSelectedFund = undefined;
                $scope.newFundManageFee = undefined;
                $scope.$addMode = false;
            }

            $scope.addNewFundManageFee = function (fund, managementFee)
            {
                
                var fundManageFee = {
                    FundCode: fund.Code,
                    FundName: fund.Name,
                    ManagementFee: managementFee,
                    InstructionType: 'Add'
                }

                fundManagementFeesService.saveFundManagementFees(fundManageFee).success(function ()
                {
                    retrieveFundManagementFeesList(false);
                    $scope.$addMode = false;
                                       
                    for (var i = 0 ; i < $scope.unmappedFundsList.length; i++)
                    {
                        if ($scope.unmappedFundsList[i].Code === fund.Code)
                            $scope.unmappedFundsList.splice(i, 1);
                        

                    }
                    
                    
                    showMessage('Fund Management Fee added successfully. Pending authorisation.');
                });
            };

            $scope.filterFundManageFee = function (item)
            {
                return (item.FundName.toLowerCase().indexOf($scope.fundNameFilter.toLowerCase()) !== -1 ||
                    item.FundCode.toLowerCase().indexOf($scope.fundNameFilter.toLowerCase()) !== -1);
            };

            $scope.anyPendingFundManageFeeSelected = function ()
            {
                for (var i = 0; i < $scope.pendingFundManageFeeList.length; i++)
                {
                    if ($scope.pendingFundManageFeeList[i].Status !== "PendingAuthorise")
                        return true;
                }

                return false;
            };

            $scope.setPendingFundManageFeeStatus = function (fundManage, status)
            {
                fundManage.Status = fundManage.Status !== status ? status : "PendingAuthorise";
            };

            $scope.updatePendingStatuses = function ()
            {
                $scope.application.showLoading = true;

                var pendingFunds = [];

                for (var i = 0; i < $scope.pendingFundManageFeeList.length; i++)
                {
                    if ($scope.pendingFundManageFeeList[i].Status !== "PendingAuthorise")
                        pendingFunds.push($scope.pendingFundManageFeeList[i]);
                }

                fundManagementFeesService.updatePendingStatuses(pendingFunds).success(function ()
                {
                    for (var i = 0; i < pendingFunds.length; i++)
                    {
                        removePendingFundManageFee(pendingFunds[i].FundCode);
                    }

                    showMessage("Selected Fund Total Expense Ratios were updated successfully");

                    if ($scope.pendingFundManageFeeList.length === 0) {
                        $scope.isViewVisible = true;
                        $scope.fundManageFeesList = [];

                        retrieveFundManagementFeesList();
                        retrieveUnmappedFundsList();
                    }

                    $scope.application.showLoading = false;
                });
            };

            $scope.selectedFundTypeChanged = function ()
            {
                $scope.selectedWrap = undefined;
                $scope.fundNameFilter = '';
                retrieveFundManagementFeesList();
            };

            $scope.selectedWrapChanged = function ()
            {
                retrieveFundManagementFeesList();
            };


            // Pagination
            $scope.firstPage = function () {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function () {
                if ($scope.currentPage > 0) {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function () {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function () {
                return Math.ceil(filteredFundManageFeeCount() / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function () {
                if ($scope.currentPage < $scope.pageCount()) {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function () {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function () {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n) {
                $scope.currentPage = n;
            };

            $scope.range = function () {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0) {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize) {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++) {
                    range.push(i);
                }

                return range;
            };

            
        }]);
})();