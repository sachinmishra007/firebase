﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('taxRebatesController', ['$scope', '$timeout', 'taxRebatesService', function ($scope, $timeout, taxRebatesService)
        {
            $scope.isReadOnlyUser = true;
            $scope.status = undefined;
            $scope.UserRole = undefined;
            $scope.isSuperUser = undefined;
            $scope.isAdminUser = undefined;
            $scope.showSuccessMessage = false;
            $scope.message = '';
            $scope.taxRebates = {};
            $scope.canSave = true;


            // On Load
            $scope.init = function ()
            {
                debugger;
                $scope.getTaxRebates();
            };

            $scope.application.showLoading = true;

            //Private Methods
            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 3000);
            };

            // Behaviours
            $scope.getTaxRebates = function ()
            {
                taxRebatesService.getTaxRebates().success(function (response)
                {
                    debugger;
                    $scope.taxRebates = response;
                    $scope.taxRebates.LoggedInUser = $scope.application.userProfile.Id;
                    $scope.determineAccess();
                });
            };

            $scope.saveTaxRebates = function ()
            {
                taxRebatesService.saveTaxRebates($scope.taxRebates, $scope.taxRebates.LoggedInUser).success(function ()
                {
                    showMessage('Tax Rebates save successfully. Status is Pending Authorisation.');
                    $scope.canSave = false;
                    $scope.canAuth = false;
                });
            };

            $scope.determineAccess = function ()
            {
                debugger;
                $scope.canAuth = (($scope.application.userProfile.Role === 'SuperUser') && $scope.application.userProfile.Id !== $scope.taxRebates.ModifiedUser && $scope.taxRebates.Status !== 'Uncaptured');
                $scope.canSave = (($scope.application.userProfile.Role === 'SuperUser' || $scope.application.currentMenuItem.AccessLevel === 'AdminRights') && $scope.taxRebates.Status === '0');
            };

            $scope.authoriseRebates = function ()
            {
                taxRebatesService.authoriseRebates($scope.taxRebates).success(function ()
                {
                    $scope.taxRebates.Status = 'Authorised';
                    $scope.canAuth = false;
                    showMessage('Tax Rebates authorised successfully.');
                });
            };

            $scope.rejectRebates = function ()
            {
                taxRebatesService.rejectRebates().success(function ()
                {
                    $scope.taxRebates.Status = 'Uncaptured';
                    $scope.canAuth = false;
                    $scope.getTaxRebates();
                    $scope.canSave = true;
                    showMessage('Tax Rebates rejected successfully.');
                });
            }
        }]);
})();
