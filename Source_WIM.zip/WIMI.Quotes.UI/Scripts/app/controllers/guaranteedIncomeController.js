﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('guaranteedIncomeController', ['$scope', function ($scope)
        {
            $scope.guaranteedIncome = {};


            // Behaviours 

            $scope.init = function (profile)
            {
                $scope.guaranteedIncome = profile;

                if (typeof $scope.guaranteedIncome.IncomeType === "undefined")
                    $scope.guaranteedIncome.IncomeType = "Income";

                if (typeof $scope.guaranteedIncome.TaxationMethod === "undefined")
                    $scope.guaranteedIncome.TaxationMethod = "PAYE";

                if ($scope.application.selectedClient.ClientSubType === "Trust")
                    profile.IsDisabled = true;
            };
        }]);
})();
