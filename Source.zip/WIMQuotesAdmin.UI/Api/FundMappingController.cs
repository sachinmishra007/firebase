﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class FundMappingController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IFundMappingLogic _fundMappingLogic;

        public FundMappingController(Domain.Logic.Contracts.IFundMappingLogic fundMappingLogic)
        {
            _fundMappingLogic = fundMappingLogic;
        }

        #endregion

        [Route("api/FundMapping")]
        public List<Entities.FundMapping> Get()
        {
            return _fundMappingLogic.GetFundMappings();
        }


        [HttpPost]
        [Route("api/FundMapping/Stage")]
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void Post([FromBody]Entities.FundMapping limit, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            //if (limit == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
            //    return;

            _fundMappingLogic.StageLimit(limit, user.Identity.Name);
        }


        [Route("api/FundMapping/Pending")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public List<Entities.FundMapping> GetPendingRegulation28Limits()
        {
            return _fundMappingLogic.GetPendingFundMappings();
        }

        [HttpPost]
        [Route("api/FundMapping/UpdateMSRetrieve")]
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void UpdateMSRetriveFundMapping([FromBody]Entities.FundMapping limit, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (limit == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundMappingLogic.UpdateMSRetriveFundMapping(limit, user.Identity.Name);
        }
        

        [HttpPost]
        [Route("api/FundMapping/UpdatePendingStatuses")]
        [AuthorizeRoles(Constants.Roles.SuperUser,Constants.Roles.Admin)]
        public void PendingLimitsUpdateStatus([FromBody]List<Entities.FundMapping> limits, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (limits == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundMappingLogic.PendingFundMappingUpdateStatus(limits, user.Identity.Name);
        }

        [Route("api/FundMapping/GetUnmappedFunds")]
        public List<Entities.Fund> GetUnmappedFunds()
        {
            return _fundMappingLogic.GetUnmappedFunds();
        }

        [Route("api/FundMapping/DeleteFundMapping")]
        public void DeleteFundMapping(string fundCode)
        {
            _fundMappingLogic.DeleteFundMapping(fundCode);
        }
    }
}
