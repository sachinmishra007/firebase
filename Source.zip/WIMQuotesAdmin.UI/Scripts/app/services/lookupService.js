﻿(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('lookupService', function ()
        {
            var lookupService = {};

            lookupService.getLanguages = function ()
            {
                return [
                    { Code: 'English', Name: 'English' },
                    { Code: 'Afrikaans', Name: 'Afrikaans' }
                ];
            };

            lookupService.getRateTypes = function ()
            {
                return [
                    { Code: 'GROWTH', Name: 'Growth' },
                    { Code: 'INCOME', Name: 'Income' }
                ];
            };

            lookupService.getFundTypes = function ()
            {
                return [
                    { Code: 'Individual', Name: 'Individual Funds' },
                    { Code: 'Wrap', Name: 'Wraps' }
                ];
            }
            lookupService.getGuarFeesType = function ()
            {
                return [
                    { Code: 'GUARDG', Name: 'GUARDG' },
                    { Code: 'GUARDI', Name: 'GUARDI' }
                ];
            };

            lookupService.getReportGenerateTypes = function ()
            {
                return [
                    { Code: 'AllQuotes', Name: 'All Quotes' },
                    { Code: 'BrokerHouse', Name: 'Broker House' },
                    { Code: 'BrokerId', Name: 'Broker Id' }
                ];
            };

            lookupService.getPlatforms = function ()
            {
                return [
                    { Code: 'Intranet', Name: 'Intranet' },
                    { Code: 'Extranet', Name: 'Extranet / Absa Invest' }
                ];
            };

            lookupService.getRolesReports = function ()
            {
                return [
                    { Code: 'ROLES', Name: 'User Roles' },
                    { Code: 'SUPER', Name: 'Super User Audit Report' }
                ];
            };
            lookupService.getFundType = function ()
            {
                return [
                    { Code: 'Fund', Name: 'Fund' },
                    { Code: 'Wrap', Name: 'Wrap' }
                ];
            };
            return lookupService;
        });
})(); 
