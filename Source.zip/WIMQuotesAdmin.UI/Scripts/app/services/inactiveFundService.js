﻿
(function () {
    'use strict';

    angular
        .module('adminApp.services')
        .factory('inactiveFundService', ['$http', function ($http) {
            var inactiveFundService = {};

            inactiveFundService.getInactiveFunds = function () {
                return $http({ url: 'api/InactiveFunds' });
            };

            inactiveFundService.getUnmappedFunds = function () {
                  return $http({ url: 'api/InactiveFunds/GetUnmappedFunds' });
            };

            inactiveFundService.deleteInactive = function (fundCode) {
                 return $http.post('api/InactiveFunds/DeleteInactiveFund',fundCode);
            };

            inactiveFundService.addInactiveFund = function (selectedUnmapFund) {
                return $http.post('api/InactiveFunds/AddInactiveFund', selectedUnmapFund );
            };

            return inactiveFundService;
        }]);
})();
