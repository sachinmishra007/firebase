﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('guaranteedGrowthRateService', ['$http', function ($http)
        {
            var guaranteedGrowthRateService = {};

            guaranteedGrowthRateService.CaptureRates = function (rates)
            {
                return $http.post('api/GrowthRates/CaptureRates', rates);
            }

            guaranteedGrowthRateService.AuthoriseRates = function (rates)
            {
                return $http.post('api/GrowthRates/AuthoriseRates', rates);
            }

            guaranteedGrowthRateService.RejectRates = function (value)
            {
                return $http.post('api/GrowthRates/RejectRates', value);
            }

            guaranteedGrowthRateService.GetLatestRates = function (productCode)
            {
                //debugger;
                return $http({ url: 'api/GrowthRates/GetLatestRates?productCode=' + productCode });
            }

            guaranteedGrowthRateService.GetProductTypes = function ()
            {
                return [
                    { Code: 'GROWTH', Name: 'GROWTH' },
                    { Code: 'GUARDGRO', Name: 'GUARDGRO' }
                ];
            }

            guaranteedGrowthRateService.GetGuarantors = function ()
            {
                return [
                    { Code: 'ABSACAP', Name: 'Absa Capital' },
                    { Code: 'ABSABANKLTD', Name: 'Absa Bank Limited' }
                ];
            }

            return guaranteedGrowthRateService;
        }]);
})();

