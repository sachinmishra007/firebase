﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MorningStarWebTool.Entites.Entities;
namespace MorningStarWebTool.Repositories.Contract
{
    public interface IMorningStarDetailsRepository
    {
        object GetMorningStarDetails(string ToolName);
    }
}
