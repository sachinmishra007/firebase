﻿(function ()
{
    'use strict';

    function isValidDate(d)
    {
        if (Object.prototype.toString.call(d) !== "[object Date]")
            return false;

        return !isNaN(d.getTime());
    }

    angular.module('quotesApp')
        .filter('sentenceCase', function ()
        {
            return function (input)
            {
                return (input || '').replace(/^[a-z]|[A-Z]/g, function (v, i)
                {
                    return i === 0 ? v.toUpperCase() : " " + v;
                });
            };
        })

        .filter('formatNumber', ['numberFormat', function (numberFormat)
        {
            return function (input)
            {
                if (typeof input === "undefined" || input === null || input === '')
                {
                    return input;
                }
                return input.toFixed(numberFormat.fraction).replace(numberFormat.separatorRegex, numberFormat.thousandSeparator);
            }
        }])
        .filter('formatDate', function ()
        {
            return function (input)
            {
                var date = new Date(input);

                if (!isValidDate(date))
                    return '';

                var day = (date.getDate() < 10 ? '0' : '') + date.getDate();
                var month = (date.getMonth() + 1 < 10 ? '0' : '') + (date.getMonth() + 1);

                return [date.getFullYear(), month, day].join('/');
            }
        })
        .filter('formatDateTime', function ()
        {
            return function (input)
            {
                var date = new Date(input);

                if (!isValidDate(date))
                    return '';

                var day = (date.getDate() < 10 ? '0' : '') + date.getDate();
                var month = (date.getMonth() + 1 < 10 ? '0' : '') + (date.getMonth() + 1);
                var hours = (date.getHours() < 10 ? '0' : '') + date.getHours();
                var minutes = (date.getMinutes() < 10 ? '0' : '') + date.getMinutes();
                var seconds = (date.getSeconds() < 10 ? '0' : '') + date.getSeconds();

                return [date.getFullYear(), month, day].join('/') + ' ' + [hours, minutes, seconds].join(':');
            }
        })
        .filter('offset', function ()
        {
            return function (input, start)
            {
                start = parseInt(start, 10);
                return input.slice(start);
            };
        });
})();
