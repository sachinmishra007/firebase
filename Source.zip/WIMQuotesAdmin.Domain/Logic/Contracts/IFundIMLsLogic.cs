﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IFundIMLsLogic
    {
        List<Entities.Fund> GetAvailableFunds();
        Entities.FundIML Get(string fundCode);
        List<Entities.FundIML> GetPendingFundIMLs();
        List<Entities.IntendedMaximumLimit> GetUnmappedIMLsForFund(string fundCode);
        void StageIntendedMaximumLimits(Entities.FundIML fundIML, string userId);
        void PendingFundIMLsUpdateStatus(List<Entities.FundIML> fundIMLs, string userId);
    }
}