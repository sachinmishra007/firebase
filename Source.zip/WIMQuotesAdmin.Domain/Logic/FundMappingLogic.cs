﻿using System;
using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class FundMappingLogic : Contracts.IFundMappingLogic
    {
        #region Constructor

        private readonly DataAccess.Repositories.Contracts.IPortfolioAdminRepository _portfolioAdminRepository;

        public FundMappingLogic(DataAccess.Repositories.Contracts.IPortfolioAdminRepository portfolioAdminRepository)
        {
            _portfolioAdminRepository = portfolioAdminRepository;
        }

        #endregion

        public Entities.FundMapping Get(string fundCode)
        {
            return new Entities.FundMapping();
        }

        public List<Entities.FundMapping> GetFundMappings()
        {
            return _portfolioAdminRepository.GetFundMappings();
        }

        public void Save(Entities.FundMapping fundMapping)
        {
            if (fundMapping == null)
                return;

            _portfolioAdminRepository.SaveFundMapping(fundMapping);
        }

        public List<Entities.FundMapping> GetPendingFundMappings()
        {
            return _portfolioAdminRepository.GetPendingFundMappings();
        }

        public void StageLimit(Entities.FundMapping mapping, string userId)
        {
            if (mapping == null || string.IsNullOrWhiteSpace(userId))
                return;

            mapping.Status = Entities.StagingStatus.PendingAuthorise;
            mapping.UserId = userId;
            mapping.ModifiedDateTime = DateTime.Now;

            _portfolioAdminRepository.StagingFundMapping(mapping);
        }

        public void PendingFundMappingUpdateStatus(List<Entities.FundMapping> mappings, string userId)
        {
            if (mappings == null || mappings.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return;

            foreach (var mapping in mappings)
            {
                switch (mapping.Status)
                {
                    case Entities.StagingStatus.Authorise:
                        PendingMappingAuthorise(mapping.FundCode, userId);
                        break;
                    case Entities.StagingStatus.Reject:
                        PendingMappingReject(mapping.FundCode, userId);
                        break;
                }
            }
        }

        public void DeleteFundMapping(string fundCode)
        {
            _portfolioAdminRepository.DeleteFundMapping(fundCode);
        }

        #region Private Methods

        private void PendingMappingAuthorise(string code, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            var limit = _portfolioAdminRepository.GetPendingFundMapping(code);

            if (limit == null)
                return;

            switch (limit.InstructionType)
            {
                case Entities.InstructionType.Delete:
                    _portfolioAdminRepository.DeleteFundMapping(limit.FundCode);
                    break;
                default:
                    _portfolioAdminRepository.SaveFundMapping(limit);
                    break;
            }

            _portfolioAdminRepository.PendingFundMappingUpdateStatus(code, Entities.StagingStatus.Authorise, userId);
        }

        private void PendingMappingReject(string code, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            _portfolioAdminRepository.PendingFundMappingUpdateStatus(code, Entities.StagingStatus.Reject, userId);
        }

        public List<Entities.Fund> GetUnmappedFunds()
        {
            return _portfolioAdminRepository.GetUnmappedFunds();
        }

        #endregion

        public void UpdateMSRetriveFundMapping(Entities.FundMapping mappings, string userId)
        {
            _portfolioAdminRepository.UpdateMSRetriveFundMapping(mappings);
        }
    }
}
