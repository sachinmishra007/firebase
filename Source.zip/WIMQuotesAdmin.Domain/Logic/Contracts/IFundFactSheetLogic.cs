﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IFundFactSheetLogic
    {
        List<Entities.FundFactSheet> Get(Entities.FundType fundType, string fundCode);
        List<Entities.FundFactSheet> GetPendingFundFactSheets();
        List<Entities.Fund> GetUnmappedFunds();
        List<Entities.Fund> GetUnmappedFundsByType(Entities.FundType fundType);

        void StageFundFactSheet(Entities.FundFactSheet fundFactSheet, string userId);
        void PendingFundFactSheetsUpdateStatus(List<Entities.FundFactSheet> fundFactSheets, string userId);

        Entities.File GetFundFactSheetFile(string fundCode);
        Entities.File GetPendingFundFactSheetFile(string fundCode);
    }
}