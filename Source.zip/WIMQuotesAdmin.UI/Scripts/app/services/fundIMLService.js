﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('fundIMLService', ['$http', function ($http)
        {
            var fundIMLService = {};

            fundIMLService.getAvailableFunds = function ()
            {
                return $http({ url: 'api/FundIML/GetAvailableFunds' });
            };

            fundIMLService.getIMLsForFund = function (fundCode)
            {
                return $http({ url: 'api/FundIML/' + fundCode });
            };

            fundIMLService.getUnmappedIMLsForFund = function (fundCode)
            {
                
                return $http({ url: 'api/FundIML/UnmappedIMLs/' + fundCode });
            };

            fundIMLService.saveFundIMLs = function (fundIML)
            {
                return $http.post('api/FundIML', fundIML);
            };

            fundIMLService.getPendingFundIMLs = function ()
            {
                return $http({ url: 'api/FundIML/Pending' });
            };

            fundIMLService.updatePendingFundIMLsStatus = function (fundIMLs)
            {
                return $http.post('api/FundIML/UpdatePendingFundIMLsStatus', fundIMLs);
            };

            return fundIMLService;
        }]);
})();
