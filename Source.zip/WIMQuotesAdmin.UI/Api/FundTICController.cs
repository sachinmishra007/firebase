﻿
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ActionResults;
using WIMQuotesAdmin.UI.Web.ModelBinders;
using System.IO;
using System.Web;
using System.Data.OleDb;
using System.Data.SqlClient;
using WIMQuotesAdmin.UI.Web.ModelBinders.Application;



namespace WIMQuotesAdmin.UI.Api
{
    public class FundTICController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IFundTICLogic _fundTICLogic;
       
        public FundTICController(Domain.Logic.Contracts.IFundTICLogic fundTICLogic)
        {
            _fundTICLogic = fundTICLogic;
        }

        #endregion
        [ValidateApiAntiForgeryToken]
         [Route("api/FundTIC/SaveToStaging/{fileName}")]

        public void SaveTICToStaging(string fileName, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            fileName = @"C:\Users\exag218\Desktop\TIC\" + fileName + ".xlsx";


          //  _fundTICLogic.StageFundTICSheet(fileName, user.Identity.Name);

        }

        // GET api/FundTER/Pending
        [Route("api/FundTIC/Pending")]
        
        public List<Entities.FundTIC> GetPendingFundTICs()
        {
            return _fundTICLogic.GetPendingFundTICs();
        }

        [HttpPost]
        [ValidateApiAntiForgeryToken]
        [Route("api/FundTIC/UpdatePendingStatuses")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingFundTICUpdateStatus([ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {

            _fundTICLogic.SaveFundTIC(user.Identity.Name);
        }

        [HttpPost]
        [ValidateApiAntiForgeryToken]
        [Route("api/FundTIC/UpdateRejectStatuses")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void RejectFundTICUpdateStatus([ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {

            _fundTICLogic.RejectFundTIC(user.Identity.Name);
        }


        [HttpPost]
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        [Route("api/FundTIC/UploadFile")]
        public HttpResponseMessage UploadFundSecurityFeeFile(
            [ModelBinder(typeof(FundTICModelBinder))]Entities.FundTIC fundTICFile,
            [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {

            if (fundTICFile == null ||
                fundTICFile.FileData == null || fundTICFile.FileData.Length == 0)
                throw new HttpResponseException(HttpStatusCode.BadRequest);

            if (user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            _fundTICLogic.StageFundTICSheet(fundTICFile, user.Identity.Name);

            return Request.CreateResponse(HttpStatusCode.OK);
        }
    }
}
