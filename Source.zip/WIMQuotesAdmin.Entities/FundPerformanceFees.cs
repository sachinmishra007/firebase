﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Entities
{
    public class FundPerformanceFees
    {
        public FundPerformanceFees()
        {
            PerformanceFees = new List<PerformanceFees>();
        }
        public string FundCode { get; set; }
        public List<Entities.PerformanceFees> PerformanceFees { get; set; }
    }
}
