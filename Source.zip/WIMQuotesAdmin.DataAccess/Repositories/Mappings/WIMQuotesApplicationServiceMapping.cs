﻿namespace WIMQuotesAdmin.DataAccess.Repositories.Mappings
{
    public static class WIMQuotesApplicationServiceMapping
    {
        public static WIMQuotesApplicationService.Note ToNote(Entities.Note note)
        {
            return new WIMQuotesApplicationService.Note
            {
                Id = note.Id,
                ProductCode = note.ProductCode,
                Language = ToLanguage(note.Language),
                Header = note.HeaderRevised,
                Content = note.DescriptionRevised,
                Sequence = note.Sequence,
                NoteType = note.NoteType
            };
        }

        public static WIMQuotesApplicationService.Language ToLanguage(Entities.Language language)
        {
            switch (language)
            {
                case Entities.Language.Afrikaans:
                    return WIMQuotesApplicationService.Language.Afrikaans;
                default:
                    return WIMQuotesApplicationService.Language.English;
            }
        }

        public static Entities.Language FromLanguage(WIMQuotesApplicationService.Language language)
        {
            switch (language)
            {
                case WIMQuotesApplicationService.Language.Afrikaans:
                    return Entities.Language.Afrikaans;
                default:
                    return Entities.Language.English;
            }
        }


        public static WIMQuotesApplicationService.GuarFeesType ToGuarfee(Entities.GuarFeesType guarFeesType)
        {
            switch (guarFeesType)
            {
                case Entities.GuarFeesType.GUARDG:
                    return WIMQuotesApplicationService.GuarFeesType.GUARDG;
                default:
                    return WIMQuotesApplicationService.GuarFeesType.GUARDI;
            }
        }


        public static WIMQuotesApplicationService.GuarFees ToGuarFeesEntity(Entities.GuarFees guarfees)
        {
            return new WIMQuotesApplicationService.GuarFees
            {
                type = guarfees.Type,
                MinAmnt = guarfees.MinAmnt,
                startdate = guarfees.startdate,
                absalifefee = guarfees.Revisedabsalifefee,
                aimsfee = guarfees.Revisedaimsfee,
                TaxLossFee = guarfees.RevisedTaxLossFee,
                Authorizer = guarfees.Modifiedby,
                Authorized = guarfees.Authorized

            };
        }

        public static WIMQuotesApplicationService.Validation ToValidation(Entities.Validation validation)
        {
            return new WIMQuotesApplicationService.Validation
            {
                Id = validation.Id,
                FieldName = validation.FieldName,
                Message = validation.MessageRevised
            };
        }

        public static WIMQuotesApplicationService.TaxTables ToTaxTables(Entities.TaxTables taxTable)
        {
            return new WIMQuotesApplicationService.TaxTables
            {
                Id = taxTable.Id,
                MinimumAmount = taxTable.MinimumAmount,
                MaximumAmount = taxTable.MaximumAmount,
                RateAmount = taxTable.RateAmount,
                RatePercent = taxTable.RatePercent
                
            };
        }
    }
}
