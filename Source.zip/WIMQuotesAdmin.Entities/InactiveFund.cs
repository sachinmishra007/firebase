﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Entities
{
    public class InactiveFund
    {
        
        public int InactiveFundId { get; set; }
        
        public string FundCode { get; set; }
        
        public string FundName { get; set; }
        
        public bool IsWrap { get; set; }
        
        public DateTime CreatedDateTime { get; set; }
        
        public string CreatedBy { get; set; }
        
        public DateTime ModifiedDateTime { get; set; }
        
        public string ModifiedBy { get; set; }
        
        public bool IsDeleted { get; set; }
        
       
    }
}
