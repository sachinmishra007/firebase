﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('wrapService', ['$http', function ($http)
        {
            var wrapService = {};

            wrapService.getAvailableWraps = function ()
            {
                return $http({ url: 'api/Wrap' });
            };

            wrapService.getFundsForWrap = function (wrapCode)
            {
                return $http({ url: 'api/Wrap/' + wrapCode });
            };

            return wrapService;
        }]);
})();
