﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.OleDb;
using WIMQuotesAdmin.Domain.Logic.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class FundSecurityFeesLogic : IFundSecurityFeesLogic
    {
        #region Constructor
        private readonly DataAccess.Repositories.Contracts.IFundSecurityFeesRepository _fundSecurityFeesRepository;

        public FundSecurityFeesLogic(DataAccess.Repositories.Contracts.IFundSecurityFeesRepository fundSecurityFeesRepository)
        {
            _fundSecurityFeesRepository = fundSecurityFeesRepository;
        }
        #endregion

        //  public void StageFundSecuiryFees(string fileName, string userID) //fundSecurityFeesFile
        public void StageFundSecuiryFees(Entities.FundSecurityFeesFile file, string userID)
        {

            file.FileName = System.IO.Path.Combine(ConfigurationManager.AppSettings["FilePathUploadSF"].ToString(), file.FileName);

            if (Common.Helpers.FileHelper.CreateFile(file.FileData, file.FileName))
            {
                String excelConnString = String.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0\"", file.FileName);

                //Create Connection to Excel work book 
                using (OleDbConnection excelConnection = new OleDbConnection(excelConnString))
                {
                    //Create OleDbCommand to fetch data from Excel 
                    using (OleDbCommand cmd = new OleDbCommand(ConfigurationManager.AppSettings["FundSecurityFeesQuery"].ToString(), excelConnection))
                    {
                        excelConnection.Open();

                        OleDbDataReader reader = cmd.ExecuteReader();

                        _fundSecurityFeesRepository.StageFundSecurityFees(reader, userID);


                    }

                }
                //Delete file 
                Common.Helpers.FileHelper.Delete(file.FileName);
            }
        }

        public List<Entities.FundSecurityFees> GetPendingFundSecurityFees()
        {
            return _fundSecurityFeesRepository.GetPendingFundSecurityFees();
        }

        public void SaveFundSecurityFees(string userID)
        {
            _fundSecurityFeesRepository.SaveAuthorisedFundSecurityFees();
            _fundSecurityFeesRepository.AutoriseRejectFundSecurityFees(Entities.StagingStatus.Authorise, userID);
        }

        public void RejectFundSecurityFees(string userID)
        {
            _fundSecurityFeesRepository.AutoriseRejectFundSecurityFees(Entities.StagingStatus.Reject, userID);
        }


    }
}
