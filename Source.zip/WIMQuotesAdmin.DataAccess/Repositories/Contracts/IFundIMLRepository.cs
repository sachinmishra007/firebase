﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IFundIMLRepository
    {
        Entities.FundIML GetFundIML(string fundCode);
        Entities.FundIML GetPendingFundIML(string fundCode);
        List<Entities.FundIML> GetPendingFundIMLs();
        List<Entities.IntendedMaximumLimit> GetIntendedMaximumLimits();

        void SaveFundIMLToStaging(Entities.FundIML fundIML);
        void UpdateFundIMLStagingStatus(string fundCode, Entities.StagingStatus status, string userId);
        void SaveAuthorisedFundIML(Entities.FundIML fundIML);
    }
}