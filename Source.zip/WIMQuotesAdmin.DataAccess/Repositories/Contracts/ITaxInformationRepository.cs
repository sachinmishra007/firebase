﻿using System.Collections.Generic;


namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface ITaxInformationRepository
    {
        List<Entities.TaxInformation> GetTaxInformation();

        List<Entities.TaxTables> GetTaxTables();
        void SaveTaxBracketsStaging(Entities.TaxTables taxTable, string userId );

        void AuthoriseTaxBrackets(Entities.TaxTables taxTable);

        List<Entities.TaxTables> RejectTaxBrackets();

        Entities.TaxRebates GetTaxRebates();

        void SaveTaxRebatesStaging(Entities.TaxRebates rebates, string userId);
        void AuthoriseRebatesStaging(Entities.TaxRebates rebates, string userId);
        void RejectRebatesStaging();
        List<Entities.TaxTables> GetPendingTaxTables();
        void UpdateTaxTablesStagingStatus(Entities.TaxTables taxTable, Entities.StagingStatus status, string userId);
        Entities.TaxTables GetPendingTaxTableById(int id);
    }
}
