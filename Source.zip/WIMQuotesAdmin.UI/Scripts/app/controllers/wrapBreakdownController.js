﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('wrapBreakdownController', ['$scope', 'wrapService', function ($scope, wrapService)
        {
            $scope.wrapsList = [];
            $scope.wrapFundsList = [];


            // Private Methods

            var retrieveWrapsList = function ()
            {
                $scope.application.showLoading = true;

                wrapService.getAvailableWraps().success(function (response)
                {
                    $scope.wrapsList = response;
                    $scope.application.showLoading = false;
                });
            };

            var retrieveFundsForWrap = function (wrap)
            {
                if (typeof wrap === "undefined" || wrap === null || wrap.Code === '')
                {
                    $scope.wrapFundsList = [];
                    return;
                }

                wrapService.getFundsForWrap(wrap.Code).success(function (response)
                {
                    $scope.wrapFundsList = response;
                });
            };


            // On Load

            retrieveWrapsList();


            // Behaviours

            $scope.selectedWrapChanged = function (wrap)
            {
                retrieveFundsForWrap(wrap);
            };

        }]);
})();