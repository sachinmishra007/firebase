﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.Entities;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface ITaxInformationLogic
    {
        List<Entities.TaxInformation> GetTaxInformation();
        List<Entities.TaxTables> GetTaxTables();
        void SaveTaxBracketsStaging(Entities.TaxTables taxTables,string userId);
        void UpdatePendingStatus(List<Entities.TaxTables> taxTables, string userId);
        List<Entities.TaxTables> RejectTaxTables();
        Entities.TaxRebates GetTaxRebates();
        void SaveTaxRebatesStaging(Entities.TaxRebates rebates, string userId);
        void AuthoriseTaxRebates(TaxRebates rebates, string userId);
        void RejectRebates();
        List<Entities.TaxTables> GetPendingTaxTables();
    }
}
