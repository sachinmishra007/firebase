﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IAssetClassesLogic
    {
        List<Entities.AssetClass> Get(string fundCode);
        List<Entities.Fund> GetAvailableFunds();
        List<Entities.AssetClass> GetUnmappedAssetClassesTypes(string fundCode);

        //void SaveFundAssetsStaging(string fundCode, List<Entities.AssetClass> assetClasses, string userId);
        //void SaveFundAssetsStaging(Entities.FundAssets fundAssets, string userId);
        void SaveFundAssetsStaging(Entities.AssetClass assetClass, string fundCode,string userId);
        List<Entities.FundAssets> GetPendingFundAssets();

        void PendingFundAssetsUpdateStatus(List<Entities.FundAssets> fundAssets, string userId);

        Entities.FundAssets GetFundAssets(string fundCode);
    }
}