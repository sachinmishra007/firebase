﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Entities
{
    public class CDSBreakdownReport
    {
        public DateTime DateCreated { get; set; }
        public string BrokerRegion { get; set; }
        public string BrokerHouse { get; set; }        
        public string BrokerCode { get; set; }        
        public string UserId { get; set; }        
        public string ProductName { get; set; }        
        public decimal? LumpSum { get; set; }        
        public int QuoteNumber { get; set; }        
        public string ClientNumber { get; set; }        
        public string ClientName { get; set; }
        public string BrokerName { get; set; }
        public string StaffName { get; set; }
    }
}
