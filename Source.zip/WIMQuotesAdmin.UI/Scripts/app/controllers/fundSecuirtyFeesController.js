﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('fundSecuirtyFeesController', ['$scope', '$timeout', 'FileUploader', 'fundSecurityFeesService', function ($scope, $timeout,
            FileUploader, fundSecurityFeesService)
        {
            var fileSizeLimit = 3000000; //2mb

            $scope.pendingFundSecurityFeesList = [];
            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
            $scope.isViewVisible = false;

            $scope.fundNameFilter = '';
            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];

            $scope.isUploadPendingVisible = $scope.application.userProfile.Role === 'AdminUser';
            // Private Methods

            var getPendingFundSecurities = function ()
            {
                $scope.application.showLoading = true;

                fundSecurityFeesService.getPendingFundTICs().success(function (response)
                {
                    $scope.pendingFundSecurityFeesList = response;

                    $scope.isViewVisible = response.length === 0;

                    $scope.isPendingVisible = !$scope.isPendingVisible ? true : $scope.isPendingVisible;
                    $scope.application.showLoading = false;
                });
            }

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 3000);
            }


            var filteredFundTICCount = function ()
            {

                var count = 0;

                for (var i = 0; i < $scope.pendingFundSecurityFeesList.length; i++)
                {
                    if ($scope.filterFundTIC($scope.pendingFundSecurityFeesList[i]))
                        count++;
                }

                return count;
            };

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 3000);
            }

            $scope.uploader = new FileUploader({
                url: 'api/FundSecurityFees/UploadFile'
            });


            $scope.uploader.filters.push({
                name: 'filterExcelOnly',
                fn: function (item)
                {
                    var valid = true;
                    debugger;
                    

                    if (item.type !== "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    {
                        if (item.size > fileSizeLimit) {
                            valid = false;
                        }
                        valid = false;
                    }

                    return valid;
                }
            });



            // On Load


            if ($scope.isPendingVisible || $scope.isUploadPendingVisible)
            {
                getPendingFundSecurities();
            }


            var filteredFundTICCount = function ()
            {

                var count = 0;

                for (var i = 0; i < $scope.pendingFundSecurityFeesList.length; i++)
                {
                    if ($scope.filterFundTIC($scope.pendingFundSecurityFeesList[i]))
                        count++;
                }

                return count;
            };

            $scope.filterFundTIC = function (item)
            {

                var i = $scope.fundNameFilter;
                return (item.FundName.toLowerCase().indexOf($scope.fundNameFilter.toLowerCase()) !== -1 ||
                    item.FundCode.toLowerCase().indexOf($scope.fundNameFilter.toLowerCase()) !== -1);
            };



            // Behaviours
            $scope.saveFundSecurityFees = function ()
            {

                $scope.application.showLoading = true;
                $scope.uploader.uploadAll();
            };

            $scope.uploader.onCompleteAll = function ()
            {
                $scope.$addMode = false;


                $scope.application.showLoading = false;

                showMessage('File Uploaded successfully. Pending authorisation.');
                getPendingFundSecurities();
            };





            $scope.updatePendingStatuses = function ()
            {

                $scope.application.showLoading = true;
                fundSecurityFeesService.updatePendingStatuses().success(function (response)
                {
                    $scope.application.showLoading = false;
                    $scope.isPendingVisible = false;
                    $scope.isViewVisible = true;
                });
                showMessage('Fund Secuity Fees Authorized successfully.');
            };

            $scope.updateRejectStatuses = function ()
            {

                $scope.application.showLoading = true;
                fundSecurityFeesService.updateRejectStatuses().success(function (response)
                {
                    $scope.application.showLoading = false;
                    $scope.isPendingVisible = false;
                    $scope.isViewVisible = true;
                });
                showMessage('Fund Secuity Fees Rejected successfully.');

            };

            $scope.downloadReportOutput = function ()
            {

                $scope.downloadUrl = "Report/SecuityFeesExcelOutput?rnd=" + new Date().getTime();
            };

            $scope.anyPendingFundTICSelected = function ()
            {

                if ($scope.pendingFundSecurityFeesList[0].UserId === $scope.application.userProfile.Id)
                {
                    return true;
                }

            };


            // Pagination

            $scope.firstPage = function ()
            {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function ()
            {
                if ($scope.currentPage > 0)
                {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function ()
            {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function ()
            {
                return Math.ceil(filteredFundTICCount() / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function ()
            {
                if ($scope.currentPage < $scope.pageCount())
                {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function ()
            {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function ()
            {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n)
            {
                $scope.currentPage = n;
            };

            $scope.range = function ()
            {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0)
                {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize)
                {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++)
                {
                    range.push(i);
                }

                return range;
            };

        }]);
})();