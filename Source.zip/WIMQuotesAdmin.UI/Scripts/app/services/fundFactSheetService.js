﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('fundFactSheetService', ['$http', function ($http)
        {
            var fundFactSheetService = {};

            fundFactSheetService.getFundFactSheets = function (fundType, fundCode)
            {
                return $http({ url: 'api/FundFactSheet/?fundType=' + fundType + '&fundCode=' + fundCode });
            };

            fundFactSheetService.getUnmappedFunds = function ()
            {
                return $http({ url: 'api/FundFactSheet/GetUnmappedFunds' });
            };

            fundFactSheetService.getUnmappedFundsByType = function (fundType)
            {
                return $http({ url: 'api/FundFactSheet/UnmappedFunds/' + fundType })
            };

            fundFactSheetService.stageDeleteFundFactSheet = function (fundFactSheet)
            {
                return $http.post('api/FundFactSheet', fundFactSheet);
            };

            fundFactSheetService.getPendingFundFactSheets = function ()
            {
                return $http({ url: 'api/FundFactSheet/Pending' });
            };

            fundFactSheetService.updatePendingStatuses = function (fundFactSheetList)
            {
                return $http.post('api/FundFactSheet/UpdatePendingStatuses', fundFactSheetList);
            };

            return fundFactSheetService;
        }]);
})();
