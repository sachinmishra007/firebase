﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IFundZeroFeeLogic
    {
        List<Entities.FundZeroFee> GetFundZeroFee();

        List<Entities.FundZeroFee> GetPendingFundZeroFees();

        List<Entities.Fund> GetFund(string fundType);

        void StageFundZeroFee(Entities.FundZeroFee fundZeroFee, string userId);

        void PendingFundZeroFeesUpdateStatus(List<Entities.FundZeroFee> fundZeroFee, string UserId);

        void AddNewFund(Entities.FundZeroFee fundZeroFee, string UserID);
    }
}
