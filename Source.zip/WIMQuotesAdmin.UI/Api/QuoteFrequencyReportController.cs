﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;
using WIMQuotesAdmin.Common.Extensions;

namespace WIMQuotesAdmin.UI.Api
{
    public class QuoteFrequencyReportController : ApiController
    {

        #region Constructor
        private readonly Domain.Logic.Contracts.IQuoteFrequencyLogic _quoteFrequencyLogic;

        public QuoteFrequencyReportController(Domain.Logic.Contracts.IQuoteFrequencyLogic quoteFrequencyLogic)
        {
            _quoteFrequencyLogic = quoteFrequencyLogic;
        }
        #endregion

        // GET api/QuoteFrequency
        public List<Entities.QuoteFrequencyReport> Get([FromUri]Entities.QuoteFrequencyReportDetail reportDetail)
        {
            if (reportDetail == null || (reportDetail.ReportType == Entities.ReportType.BrokerId && string.IsNullOrWhiteSpace(reportDetail.BrokerCode)))
                return null;
            
            return _quoteFrequencyLogic.GetQuoteFrequencyReport(reportDetail);
        }

        [HttpGet]
        [Route("api/QuoteFrequencyReport/SearchBrokers/{searchTerm}")]
        public List<Entities.Broker> SearchBrokers(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
                return null;

            return _quoteFrequencyLogic.GetBrokers(searchTerm);
        }

        [HttpGet]
        [Route("api/QuoteFrequencyReport/SearchBrokerHouse/{searchTerm}")]
        public List<Entities.Broker> SearchBrokerHouse(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
                return null;

            return _quoteFrequencyLogic.GetBrokerHouse(searchTerm);
        }

        [HttpGet]
        [Route("api/QuoteFrequencyReport/DownloadExcelReport")]
        public HttpResponseMessage DownloadExcelReport(string reportDetail)
        {
            //if (reportDetail == null || (reportDetail.ReportType == Entities.ReportType.BrokerId && string.IsNullOrWhiteSpace(reportDetail.BrokerCode)))
            //    return null;

            var result = _quoteFrequencyLogic.GetQuoteFrequencyReport(new Entities.QuoteFrequencyReportDetail
            {
                BrokerCode = reportDetail,
                StartDate = DateTime.Now.AddDays(-7),
                EndDate = DateTime.Now
            });
            var serialisedResult = result.ToXmlSerialisedBytes();

            var response = new HttpResponseMessage();
            response.Content = new ByteArrayContent(serialisedResult);
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            response.Content.Headers.ContentDisposition.FileName = "Sam.xls";
            response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/ms-excel");
            response.Content.Headers.ContentLength = serialisedResult.Length;

            return response;
        }
    }
}