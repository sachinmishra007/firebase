﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('productDocumentController', ['$scope', '$timeout', 'lookupService', 'productDocumentService',
            function ($scope, $timeout, lookupService, productDocumentService)
        {
            $scope.productsList = [];
            $scope.languagesList = lookupService.getLanguages();
            $scope.platforms = lookupService.getPlatforms();


            // Private Methods

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showErrorMessage = true;

                $timeout(function ()
                {
                    $scope.showErrorMessage = false;
                }, 5000);
            }

          
            // Behaviours

            $scope.getProducts = function (platform)
            {
                if (typeof platform === "undefined" || platform === null || platform === "")
                    return;

                $scope.application.showLoading = true;

                productDocumentService.getProducts().success(function (response)
                {
                    $scope.productsList = response;
                    $scope.application.showLoading = false;
                });
            };

            $scope.getProductDocument = function (product, language, documentType, platform)
            {
                productDocumentService.checkDocumentExists(product.Code, language, documentType, platform).success(function (response)
                {
                    if (response)
                    {
                        $scope.downloadUrl = productDocumentService.getProductDocumentUrl(product.Code, language, documentType, platform);
                    }
                    else
                    {
                        showMessage("Selected document for " + product.Name + " could not be found");
                    }
                });
            };

        }]);
})();
