﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class Regulation28LimitLogic : Contracts.IRegulation28LimitLogic
    {
        #region Constructor

        private readonly DataAccess.Repositories.Contracts.IRegulation28LimitsRepository _regulation28LimitRepository;

        public Regulation28LimitLogic(DataAccess.Repositories.Contracts.IRegulation28LimitsRepository regulation28LimitRepository)
        {
            _regulation28LimitRepository = regulation28LimitRepository;
        }

        #endregion

        public List<Entities.Regulation28Limits> Get()
        {
            var limits = _regulation28LimitRepository.GetRegulation28Limits();
            var pendingLimits = GetPendingLimits();

            if (pendingLimits == null || pendingLimits.Count == 0)
                return limits;

            foreach (var pendingLimit in pendingLimits)
            {
                var limit = limits.FirstOrDefault(f => f.Code == pendingLimit.Code);

                if (limit == null)
                    continue;

                limit.Status = pendingLimit.Status;
                limit.UserId = pendingLimit.UserId;
                limit.ModifiedDateTime = pendingLimit.ModifiedDateTime;
            }

            return limits;
        }

        public List<Entities.Regulation28Limits> GetPendingLimits()
        {
            return _regulation28LimitRepository.GetPendingRegulation28Limits();
        }

        public void StageLimit(Entities.Regulation28Limits limit, string userId)
        {
            if (limit == null || string.IsNullOrWhiteSpace(userId))
                return;

            limit.Status = Entities.StagingStatus.PendingAuthorise;
            limit.UserId = userId;
            limit.ModifiedDateTime = DateTime.Now;

            _regulation28LimitRepository.StagingRegulation28Limits(limit);
        }

        public void PendingLimitUpdateStatus(List<Entities.Regulation28Limits> limits, string userId)
        {
            if (limits == null || limits.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return;

            foreach (var limit in limits)
            {
                switch (limit.Status)
                {
                    case Entities.StagingStatus.Authorise:
                        PendingLimitAuthorise(limit.Code, userId);
                        break;
                    case Entities.StagingStatus.Reject:
                        PendingLimitReject(limit.Code, userId);
                        break;
                }
            }
        }

        #region Private Methods

        private void PendingLimitAuthorise(string code, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            var limit = _regulation28LimitRepository.GetPendingRegulation28Limit(code);

            if (limit == null)
                return;

            switch (limit.InstructionType)
            {
                case Entities.InstructionType.Delete:
                    //_regulation28LimitRepository.DeleteAuthorisedLimit(limit.Code);
                    break;
                default:
                    _regulation28LimitRepository.SaveAuthorisedLimit(limit);
                    break;
            }

            _regulation28LimitRepository.PendingRegulation28LimitsUpdateStatus(code, Entities.StagingStatus.Authorise, userId);
        }

        private void PendingLimitReject(string code, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            _regulation28LimitRepository.PendingRegulation28LimitsUpdateStatus(code, Entities.StagingStatus.Reject, userId);
        }

        #endregion
    }
}
