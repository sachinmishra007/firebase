﻿
(function () {
    'use strict';

    angular.module('adminApp.controllers')
        .controller('fundMinimumController', ['$scope', '$timeout', 'fundMinimumService', 'lookupService',
            function ($scope, $timeout, fundMinimumService, lookupService) {

                $scope.fundMinimumList = [];
                $scope.pendingFundMinimumList = [];
                $scope.productList = [];
                $scope.addNewFundMinimum = {};
                $scope.fundList = [];
                $scope.transactionTypeList = [];
                $scope.filterFundCode = '';
                $scope.currentPage = 0;
                $scope.itemsPerPage = 10;
                $scope.range = [];
                $scope.header = "Maintain Fund Minimum";
                $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' ||
                $scope.application.currentMenuItem.AccessLevel === 'AdminRights';

                $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
                $scope.isViewVisible = false;
                $scope.$addMode = false;
                $scope.$hideMode = false;
                $scope.fundType = lookupService.getFundType();



                // Private Methods


                var FundCount = function () {
                    var count = 0;

                    for (var i = 0; i < $scope.fundMinimumList.length; i++) {
                        if ($scope.filterFundMinimum($scope.fundMinimumList[i]))
                            count++;

                    }

                    return count;
                };

                var getFundMinimumList = function () {

                    $scope.application.showLoading = true;
                    fundMinimumService.getFundMinimumAmounts().success(function (response) {

                        $scope.fundMinimumList = response;
                        $scope.application.showLoading = false;
                    });
                };

                var showMessage = function (message) {
                    $scope.notificationMessage = message;
                    $scope.showSuccessMessage = true;

                    $timeout(function () {
                        $scope.showSuccessMessage = false;
                    }, 5000);
                }

                var clearAddFund = function () {
                    $scope.selectedProduct = undefined;
                    $scope.selectedFund = undefined;
                    $scope.selectedFundMinimumAmount = undefined;
                    $scope.selectedTransactionType = undefined;

                };

                var removePendingFundMinimum = function (fundId) {
                    for (var i = 0; i < $scope.pendingFundMinimumList.length; i++) {
                        if ($scope.pendingFundMinimumList[i].FundCode === fundId)
                            $scope.pendingFundMinimumList.splice(i, 1);
                    }
                }

                var retrieveProductList = function () {
                    $scope.showLoading = true;
                    fundMinimumService.getProducts().success(function (response) {
                        $scope.productList = response;
                        $scope.application.showLoading = false;
                    });
                };

                //var retrieveFundList = function (selectedProduct) {

                //    if (typeof selectedProduct == "undefined" || selectedProduct == null || selectedProduct == "")
                //        return;
                //    $scope.application.showLoading = true;

                //    fundMinimumService.getFundList(selectedProduct).success(function (response) {
                //        $scope.fundList = response;
                //        $scope.application.showLoading = false;
                //    });
                //};


                //// On Load 

                retrieveProductList();

                getFundMinimumList();



                if ($scope.isPendingVisible) {

                    $scope.application.showLoading = true;
                    fundMinimumService.getPendingFundMinimum().success(function (response) {
                        debugger;
                        $scope.pendingFundMinimumList = response;
                        $scope.isViewVisible = response.length === 0;
                        $scope.application.showLoading = false;
                    });
                }
                else {
                    $scope.isViewVisible = true;
                    $scope.application.showLoading = false;
                }


                ////// Behaviours
                $scope.filterFundMinimum = function (item) {
                    return (item.FundCode.toLowerCase().indexOf($scope.filterFundCode.toLowerCase()) !== -1);
                };


                $scope.editFundMinimum = function (fundMinimum) {
                    fundMinimum.OriginalValue = fundMinimum.FundMinimumAmount;
                    fundMinimum.$editMode = true;
                };

                $scope.cancelEditFundMinimum = function (fundMinimum) {
                    fundMinimum.FundMinimumAmount = fundMinimum.OriginalValue;
                    fundMinimum.$editMode = false;
                };

                $scope.saveFundMinimum = function (fundMinimum) {
                    fundMinimumService.saveFundMinimum(fundMinimum).success(function () {
                        fundMinimum.Status = 'PendingAuthorise';
                        fundMinimum.$editMode = false;

                        showMessage('Fund Minimum Amount saved successfully. Pending authorisation.');
                    });
                };

                $scope.deleteFundMinimum = function (fundMinimum) {
                    fundMinimum.InstructionType = 'Delete';

                    fundMinimumService.saveFundMinimum(fundMinimum).success(function () {
                        fundMinimum.Status = 'PendingAuthorise';
                        fundMinimum.$editMode = false;

                        showMessage('Fund Minimum set for deletion. Pending authorisation.');
                    });
                };

                $scope.setPendingFundMinimumStatus = function (fundMinimum, status) {
                    fundMinimum.Status = fundMinimum.Status !== status ? status : "PendingAuthorise";
                };

                $scope.anyPendingFundMinimumSelected = function () {
                    for (var i = 0; i < $scope.pendingFundMinimumList.length; i++) {
                        if ($scope.pendingFundMinimumList[i].Status !== "PendingAuthorise")
                            return true;
                    }

                    return false;
                };

                $scope.updatePendingStatuses = function () {
                    $scope.application.showLoading = true;
                    var pendingFunds = [];
                    debugger;
                    for (var i = 0; i < $scope.pendingFundMinimumList.length; i++) {
                        if ($scope.pendingFundMinimumList[i].Status !== "PendingAuthorise") {
                            pendingFunds.push($scope.pendingFundMinimumList[i]);
                        }
                    }

                    fundMinimumService.updatePendingStatuses(pendingFunds).success(function () {
                        for (var i = 0; i < pendingFunds.length; i++) {
                            removePendingFundMinimum(pendingFunds[i].FundCode);
                        }

                        showMessage("Selected fund minimum amount updated successfully");

                        if ($scope.pendingFundMinimumList.length === 0) {
                            $scope.isViewVisible = true;
                            $scope.fundMinimumList = [];
                            getFundMinimumList();
                        }

                        $scope.application.showLoading = false;
                    });
                };

                $scope.retrieveFundList = function (selectedProduct) {
                    if (typeof selectedProduct == "undefined" || selectedProduct == null || selectedProduct == "")
                        return;
                    $scope.application.showLoading = true;
                    fundMinimumService.getFundList(selectedProduct).success(function (response) {
                        $scope.fundList = response;
                        $scope.application.showLoading = false;
                    });
                };

                $scope.retrieveTransactionTypeList = function (selectedFund) {
                    debugger;
                    fundMinimumService.getTransactionTypeList($scope.selectedProduct.Code, selectedFund).success(function (response) {
                        $scope.transactionTypeList = response;
                        $scope.application.showLoading = false;
                    });
                };
                $scope.application.showLoading = true;

                fundMinimumService.getProducts().success(function (response) {
                    $scope.productList = response;
                    $scope.application.showLoading = false;
                });

                $scope.addNewFundMinimum = function (product, fund, minimumFundAmount, transactionType) {
                    var fundMinimum = {
                        FundCode: fund.FundCode,
                        FundName: fund.FundName,
                        ProductId: product.Code,
                        ProductName: product.Name,
                        FundMinimumAmount: minimumFundAmount === undefined ? 0 : minimumFundAmount,
                        InstructionType: 'Add',
                        TransactionDesc: transactionType.TransactionDesc,
                        TransactionTypeId: transactionType.TransactionTypeId
                    }

                    fundMinimumService.addNewFundMinimum(fundMinimum).success(function () {

                        showMessage("Selected Minimum Fund Amount added successfully");
                        clearAddFund();
                        $scope.application.showLoading = false;
                    });
                };

                $scope.addFundMinimumCancel = function () {
                    $scope.selectedProduct = undefined;
                    $scope.selectedFund = undefined;
                    $scope.selectedFundMinimumAmount = undefined;
                    $scope.selectedTransactionType = undefined;
                    $scope.$addMode = false;
                }


                $scope.openAddFundMinimum = function () {
                    $scope.header = "Add Fund Minimum";
                    $scope.$addMode = true;
                };

                $scope.cancelFunds = function () {
                    $scope.header = "Maintain Fund Zero Fee";
                    clearAddFund();
                    $scope.$addMode = false;
                }

                $scope.getFundWrapFundList = function (fundType) {
                    if (typeof fundType == "undefined" || fundType == null || fundType == "")
                        return;
                    $scope.application.showLoading = true;

                    fundMinimumService.getFundWrapTypeList(fundType).success(function (response) {
                        $scope.fundWrapTypeList = response;
                        $scope.application.showLoading = false;
                    });
                };


                // Pagination
                $scope.firstPage = function () {
                    $scope.currentPage = 0;
                };

                $scope.prevPage = function () {
                    if ($scope.currentPage > 0) {
                        $scope.currentPage--;
                    }
                };

                $scope.prevPageDisabled = function () {
                    return $scope.currentPage === 0 ? "disabled" : "";
                };

                $scope.pageCount = function () {
                    return Math.ceil(FundCount() / $scope.itemsPerPage) - 1;
                };

                $scope.nextPage = function () {
                    if ($scope.currentPage < $scope.pageCount()) {
                        $scope.currentPage++;
                    }
                };

                $scope.lastPage = function () {
                    $scope.currentPage = $scope.pageCount();
                };

                $scope.nextPageDisabled = function () {
                    return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
                };

                $scope.setPage = function (n) {
                    $scope.currentPage = n;
                };

                $scope.range = function () {
                    var range = [];
                    var rangeSize = 5;
                    var pageCount = $scope.pageCount();
                    var start = $scope.currentPage;

                    if ((start + pageCount) - rangeSize < 0) {
                        rangeSize = pageCount + 1;
                    }

                    if (start > pageCount - rangeSize) {
                        start = pageCount - rangeSize + 1;
                    }

                    for (var i = start; i < start + rangeSize; i++) {
                        range.push(i);
                    }

                    return range;
                };


            }]);
})();