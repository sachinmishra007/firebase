﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.Entities;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IRegulation28LimitsLogic
    {
        List<Entities.Regulation28Limits> GetRegulation28Limits();
        void StagingRegulation28Limits(Entities.Regulation28Limits limit, string userId);
        void PendingRegulation28LimitsUpdateStatus(List<Entities.Regulation28Limits> limits, string userId);
    }
}
