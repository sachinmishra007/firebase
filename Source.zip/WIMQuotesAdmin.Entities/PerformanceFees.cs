﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Entities
{
    public class PerformanceFees
    {
       
        public int TimePeriod { get; set; }
        public double ClosePrice { get; set; }
        public double Percentage { get; set; }
        public DateTime DateModified { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public InstructionType InstructionType { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public StagingStatus Status { get; set; }
        public string UserId { get; set; }
    }
}
