﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IFundMinimumRepository
    {
        List<Entities.FundMinimum> GetFundMinimumAmounts();
        List<Entities.FundMinimum> GetPendingFundMinimumAmounts();
        void SaveFundMinimumToStaging(Entities.FundMinimum fundMinimum);
        void PendingFundMinimumUpdateStatus(List<Entities.FundMinimum> fundMinimum, string userId);
        void SaveAuthorisedFundMinimum(Entities.FundMinimum fundMinimum);
        void DeleteAuthorisedFundMinimum(Entities.FundMinimum fundMinimum);
        void UpdateFundMinimumStagingStatus(Entities.FundMinimum fundMinimum);
        List<Entities.Product> GetProducts();
        List<Entities.FundMinimum> GetFunds(string productId);
        List<Entities.FundMinimum> GetTransactionType(string productId, string fundId);
        void AddNewFundMinimum(Entities.FundMinimum fundMinimum, string userId);

    }
}
