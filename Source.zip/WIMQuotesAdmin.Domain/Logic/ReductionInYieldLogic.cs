﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class ReductionInYieldLogic : Contracts.IReductionInYieldLogic
    {
        #region Constructor

        private readonly IReductionInYieldRepository _reductionInYieldRepository;

        public ReductionInYieldLogic(IReductionInYieldRepository reductionInYieldRepository)
        {
            _reductionInYieldRepository = reductionInYieldRepository;
        }

        #endregion

        public List<Entities.ReductionInYield> Get()
        {
            var yields = _reductionInYieldRepository.GetReductionInYields();
            var pendingYields = GetPendingYields();

            if (pendingYields == null || pendingYields.Count == 0)
                return yields;

            foreach (var pendingYield in pendingYields)
            {
                var yield = yields.FirstOrDefault(f => f.ProductCode == pendingYield.ProductCode);

                if (yield == null)
                    continue;

                yield.AssumedGrossReturn = pendingYield.AssumedGrossReturn;
                yield.Term = pendingYield.Term;
                yield.ProductCode = pendingYield.ProductCode;
                yield.ProductName = pendingYield.ProductName;
                yield.Status = pendingYield.Status;
                yield.UserId = pendingYield.UserId;
                yield.ModifiedDateTime = pendingYield.ModifiedDateTime;
            }

            return yields;
        }

        public List<Entities.ReductionInYield> GetPendingYields()
        {
            return _reductionInYieldRepository.GetPendingReductionInYields();
        }

        public void StageLimit(Entities.ReductionInYield yield, string userId)
        {
            if (yield == null || string.IsNullOrWhiteSpace(userId))
                return;

            yield.Status = Entities.StagingStatus.PendingAuthorise;
            yield.UserId = userId;
            yield.ModifiedDateTime = DateTime.Now;

            _reductionInYieldRepository.StagingReductionInYields(yield);
        }

        public void PendingLimitUpdateStatus(List<Entities.ReductionInYield> limits, string userId)
        {
            if (limits == null || limits.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return;

            foreach (var limit in limits)
            {
                switch (limit.Status)
                {
                    case Entities.StagingStatus.Authorise:
                        PendingYieldAuthorise(limit.ProductCode, userId);
                        break;
                    case Entities.StagingStatus.Reject:
                        PendingLimitReject(limit.ProductCode, userId);
                        break;
                }
            }
        }

        #region Private Methods

        private void PendingYieldAuthorise(string code, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            var limit = _reductionInYieldRepository.GetPendingReductionInYield(code);

            if (limit == null)
                return;

            switch (limit.InstructionType)
            {
                case Entities.InstructionType.Delete:
                    //_reductionInYieldRepository.DeleteAuthorisedLimit(limit.Code);
                    break;
                default:
                    _reductionInYieldRepository.SaveAuthorisedLimit(limit);
                    break;
            }

            _reductionInYieldRepository.PendingReductionInYieldUpdateStatus(code, Entities.StagingStatus.Authorise, userId);
        }

        private void PendingLimitReject(string code, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            _reductionInYieldRepository.PendingReductionInYieldUpdateStatus(code, Entities.StagingStatus.Reject, userId);
        }

        #endregion
    }
    
}
