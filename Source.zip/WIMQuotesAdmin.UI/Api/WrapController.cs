﻿using System.Collections.Generic;
using System.Web.Http;

using WIMQuotesAdmin.UI.Web.ActionFilters;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class WrapController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IWrapLogic _wrapLogic;

        public WrapController(Domain.Logic.Contracts.IWrapLogic wrapLogic)
        {
            _wrapLogic = wrapLogic;
        }

        #endregion

        // GET api/Wrap
        public List<Entities.Fund> Get()
        {
            return _wrapLogic.GetAvailableWraps();
        }

        // GET api/Wrap/013
        [Route("api/Wrap/{wrapCode}")]
        public List<Entities.Fund> Get(string wrapCode)
        {
            return _wrapLogic.GetFundsForWrap(wrapCode);
        }
    }
}
