﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorningStarWebTool.Entites.Entities
{
    public class MorningStarDetails
    {
        public object AuthUrlTemplate { get; set; }
        public string InstanceId { get; set; }
        public string Environment { get; set; }
        public string CustomStyles { get; set; }
        public string ConfigurationNamespace { get; set; }
        public string Result { get; set; }

    }
}
