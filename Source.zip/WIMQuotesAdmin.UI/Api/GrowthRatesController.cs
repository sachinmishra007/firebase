﻿using System.Web.Http;

using WIMQuotesAdmin.Domain.Logic.Contracts;
using WIMQuotesAdmin.UI.Web.ActionFilters;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class GrowthratesController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IGrowthRatesLogic _growthRateController;

        public GrowthratesController(IGrowthRatesLogic growthRateController)
        {
            _growthRateController = growthRateController;
        }

        #endregion

        [HttpPost]
        [Route("api/GrowthRates/CaptureRates")]
        public Entities.GrowthRates SaveRates([FromBody]Entities.GrowthRates rates)
        {
            return _growthRateController.CaptureRates(rates);
        }

        [HttpPost]
        [Route("api/GrowthRates/AuthoriseRates")]
        public void AuthoriseRates([FromBody]Entities.GrowthRates rates)
        {
            _growthRateController.AutoriseRates(rates);
        }

        [HttpPost]
        [Route("api/GrowthRates/RejectRates")]
        public void RejectRates([FromBody] string value)
        {
            _growthRateController.RejectRates(value);
        }

        // GET: api/GrowthRates/GetLatestRates
        [Route("api/GrowthRates/GetLatestRates")]
        public Entities.GrowthRates GetLatestRates(string productCode)
        {
            return _growthRateController.GetLatestRates(productCode);
        }
    }
}
