﻿
(function () {
    'use strict';

    angular.module('adminApp.controllers')
        .controller('fundFactSheetController', ['$scope', '$timeout', 'FileUploader', 'fundFactSheetService', 'lookupService', 'wrapService',
        function ($scope, $timeout, FileUploader, fundFactSheetService, lookupService, wrapService) {
            var fileSizeLimit = 2000000; //2mb

            $scope.unmappedFundsList = [];
            $scope.fundFactSheetsList = [];
            $scope.wrapsList = [];
            $scope.pendingFundFactSheets = [];
            $scope.selectedFundFactSheet = undefined;

            $scope.fundTypes = lookupService.getFundTypes();
            //$scope.unmapTypes = lookupService.getFundTypes();
            $scope.selectedFundType = $scope.fundTypes[0];
            //$scope.unmapFundType = $scope.unmapTypes[0];

            $scope.fundNameFilter = '';
            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];

            $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' ||
                $scope.application.currentMenuItem.AccessLevel === 'AdminRights';

            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
            $scope.isViewVisible = false;
            $scope.$addMode = false;
            $scope.$wrapType = '';
            //$scope.$isWrapType = false;


            // Private Methods

            var removePendingFundFactSheet = function (fundCode) {
                for (var i = 0; i < $scope.pendingFundFactSheets.length; i++) {
                    if ($scope.pendingFundFactSheets[i].FundCode === fundCode)
                        $scope.pendingFundFactSheets.splice(i, 1);
                }
            }

            var filteredFundFactSheetsCount = function () {
                var count = 0;

                for (var i = 0; i < $scope.fundFactSheetsList.length; i++) {
                    if ($scope.filterFundFactSheets($scope.fundFactSheetsList[i]))
                        count++;
                }

                return count;
            };

            var retrieveFundFactSheetsList = function () {

                $scope.application.showLoading = true;

                var fundType = $scope.selectedFundType.Code;
                var fundCode = angular.isDefined($scope.selectedWrap) ? $scope.selectedWrap.Code : '';

                fundFactSheetService.getFundFactSheets(fundType, fundCode).success(function (response) {
                    $scope.fundFactSheetsList = response;
                    $scope.application.showLoading = false;
                    $scope.$isWrapType = fundType === "Wrap";
                });
            }

            var retrieveUnmappedFundsList = function () {
                fundFactSheetService.getUnmappedFunds().success(function (response) {
                    $scope.unmappedFundsList = response;
                });
            };

            //

            var retrieveUnmappedFundByType = function (unmapFundType) {
                $scope.application.showLoading = true;

                var unmapType = unmapFundType;  //var unmapType= $scope.unmapFundType.Code;

                fundFactSheetService.getUnmappedFundsByType(unmapType).success(function (response) {
                    $scope.unmappedFundsList = response;
                    $scope.application.showLoading = false;
                });
            };

            //

            var retrieveWrapsList = function () {
                wrapService.getAvailableWraps().success(function (response) {
                    $scope.wrapsList = response;
                });
            };

            var showMessage = function (message) {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function () {
                    $scope.showSuccessMessage = false;
                }, 3000);
            }


            // On Load

            retrieveFundFactSheetsList();
            //     retrieveUnmappedFundsList();
            retrieveWrapsList();
            // retrieveUnmappedFundListforWraps();

            if ($scope.isPendingVisible) {
                fundFactSheetService.getPendingFundFactSheets().success(function (response) {
                    $scope.pendingFundFactSheets = response;
                    $scope.isViewVisible = response.length === 0;
                });
            }
            else {
                $scope.isViewVisible = true;
            }
            debugger;
            $scope.uploader = new FileUploader({
              
                url: 'api/FundFactSheet/UploadFile'
            });

            $scope.uploader.filters.push({
                name: 'filterPdfOnly',
                fn: function (item) {
                    var valid = true;

                    if (item.size > fileSizeLimit) {
                        valid = false;
                    }

                    if (item.type !== "application/pdf") {
                        valid = false;
                    }

                    return valid;
                }
            });


            // Behaviours

            $scope.filterFundFactSheets = function (item) {
                return (item.FundName.toLowerCase().indexOf($scope.fundNameFilter.toLowerCase()) !== -1 ||
                    item.FundCode.toLowerCase().indexOf($scope.fundNameFilter.toLowerCase()) !== -1);
            };

            $scope.editFundFactSheet = function (fundFactSheet) {
                debugger;
                $scope.selectedFundFactSheet = fundFactSheet;
                $scope.unmappedFundType = fundFactSheet.Type === "Wrap" ? 'Wrap' : 'Individual';

                $scope.$addMode = true;
            };

            $scope.deleteFundFactSheet = function (fundFactSheet) {

                fundFactSheet.InstructionType = 'Delete';

                fundFactSheetService.stageDeleteFundFactSheet(fundFactSheet).success(function () {
                    fundFactSheet.Status = 'PendingAuthorise';
                    showMessage('Fund Fact Sheet set for deletion. Pending authorisation.');
                });
            };

            $scope.openAddFundFactSheet = function () {
                $scope.$addMode = true;
                $scope.$wrapType = '';
            };

            $scope.addFundFactSheetCancel = function () {
                $scope.uploader.clearQueue();
                $scope.selectedFundFactSheet = undefined;
                $scope.selectedFund = undefined;
                $scope.$addMode = false;
            }

            $scope.addNewFundFactSheet = function (fund, totalExpenseRatio) {
                var fundFactSheet = {
                    FundCode: fund.Code,
                    FundName: fund.Name,
                    TotalExpenseRatio: totalExpenseRatio,
                    InstructionType: 'Add'
                }

                fundFactSheetService.saveFundFactSheet(fundFactSheet).success(function () {

                    retrieveFundFactSheetsList();
                    $scope.$addMode = false;

                    showMessage('Fund Fact Sheet added successfully. Pending authorisation.');
                });
            };

            $scope.updatePendingStatuses = function () {
                $scope.application.showLoading = true;

                var pendingFunds = [];

                for (var i = 0; i < $scope.pendingFundFactSheets.length; i++) {
                    if ($scope.pendingFundFactSheets[i].Status !== "PendingAuthorise")
                        pendingFunds.push($scope.pendingFundFactSheets[i]);
                }

                fundFactSheetService.updatePendingStatuses(pendingFunds).success(function () {
                    for (var i = 0; i < pendingFunds.length; i++) {
                        removePendingFundFactSheet(pendingFunds[i].FundCode);
                    }

                    showMessage("Selected Fund Fact Sheets were updated successfully");

                    if ($scope.pendingFundFactSheets.length === 0) {
                        $scope.isViewVisible = true;
                        $scope.fundFactSheetsList = [];

                        retrieveFundFactSheetsList();
                        retrieveUnmappedFundsList();
                    }

                    $scope.application.showLoading = false;
                });
            };

            $scope.setPendingFundFactSheetStatus = function (fundFactSheet, status) {
                fundFactSheet.Status = fundFactSheet.Status !== status ? status : "PendingAuthorise";
            };

            $scope.anyPendingFundFactSheetSelected = function () {
                for (var i = 0; i < $scope.pendingFundFactSheets.length; i++) {
                    if ($scope.pendingFundFactSheets[i].Status !== "PendingAuthorise")
                        return true;
                }

                return false;
            };


            $scope.downloadFundFactSheet = function (fundCode) {
                debugger;

                var test = new Date().getTime();
                $scope.downloadUrl = 'api/FundFactSheet/' + fundCode + '?' + new Date().getTime();

            };

            $scope.downloadPendingFundFactSheet = function (fundCode) {
                $scope.downloadUrl = 'api/FundFactSheet/Pending/' + fundCode + '?' + new Date().getTime();
            };

            $scope.saveFundFactSheet = function () {
                debugger;
                $scope.application.showLoading = true;
                $scope.uploader.uploadAll();
            };

            $scope.selectedFundTypeChanged = function () {
                $scope.selectedWrap = undefined;
                $scope.fundNameFilter = '';
                retrieveFundFactSheetsList();
            };

            $scope.selectedUnmappedFundTypeChanged = function (unmapFundType) {

                $scope.selectedWrap = undefined;
                $scope.fundNameFilter = '';

                retrieveUnmappedFundByType(unmapFundType)
                $scope.$wrapType = unmapFundType === "Wrap" ? 'Wrap' : '';
                $scope.unmappedFundType = unmapFundType;
            };

            $scope.selectedWrapChanged = function () {
                retrieveFundFactSheetsList();
            };

            $scope.uploader.onCompleteAll = function () {
                $scope.$addMode = false;
                $scope.selectedFund = undefined;

                if (angular.isDefined($scope.selectedFundFactSheet)) {
                    $scope.selectedFundFactSheet.Status = "PendingAuthorise";
                    $scope.selectedFundFactSheet = undefined;
                }

                $scope.application.showLoading = false;

                showMessage('Fund Fact Sheet saved successfully. Pending authorisation.');
            };

            $scope.uploader.onBeforeUploadItem = function (item) {
                if (angular.isDefined($scope.selectedFundFactSheet)) {
                    item.formData.push({ fundCode: $scope.selectedFundFactSheet.FundCode });
                    item.formData.push({ fundName: $scope.selectedFundFactSheet.FundName });
                    item.formData.push({ type: $scope.unmappedFundType });
                    item.formData.push({ instructionType: 'Update' });
                }
                else {
                    item.formData.push({ fundCode: $scope.selectedFund.Code });
                    item.formData.push({ fundName: $scope.selectedFund.Name });
                    item.formData.push({ type: $scope.unmappedFundType });
                    item.formData.push({ instructionType: 'Add' });
                }
            };


            // Pagination

            $scope.firstPage = function () {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function () {
                if ($scope.currentPage > 0) {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function () {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function () {
                return Math.ceil(filteredFundFactSheetsCount() / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function () {
                if ($scope.currentPage < $scope.pageCount()) {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function () {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function () {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n) {
                $scope.currentPage = n;
            };

            $scope.range = function () {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0) {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize) {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++) {
                    range.push(i);
                }

                return range;
            };

        }]);
})();