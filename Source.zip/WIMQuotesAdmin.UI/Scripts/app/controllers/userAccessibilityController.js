﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('userAccessibilityController', ['$scope', 'userManagementService', function ($scope, userManagementService)
        {
            $scope.userRoles = undefined;
            $scope.accessLevels = undefined;
            $scope.menuItems = undefined;
            $scope.disableAllAccessOptions = false;

            $scope.AccessLevel = null;


            // Private Methods

            var arraySetAllValues = function (arrayItems, propertyToSet, value)
            {
                for (var i = 0; i < arrayItems.length; i++)
                {
                    arrayItems[i][propertyToSet] = value;
                }
            };


            // Behaviours

            $scope.setUserRole = function (userRole, clearSelected)
            {
                if (clearSelected || false)
                    $scope.setAccessLevelAll(null);

                switch (userRole)
                {
                    case "SuperUser":
                        $scope.disableAllAccessOptions = true;
                        $scope.AccessLevel = null;
                        $scope.setAccessLevelAll("AdminRights");
                        $scope.disabledAccessLevel = null;
                        break;
                    case "AdminUser":
                        $scope.disableAllAccessOptions = false;
                        $scope.disabledAccessLevel = null;
                        break;
                    case "ReadOnlyUser":
                        $scope.disableAllAccessOptions = false;
                        $scope.disabledAccessLevel = "AdminRights";
                        break;
                    default:
                        $scope.disableAllAccessOptions = true;
                        $scope.user.Role = null;
                        $scope.setAccessLevelAll(null);
                        break;
                }
            };

            $scope.setAccessLevel = function (item, menuItem, accessLevel)
            {
                item.AccessLevel = item.AccessLevel !== accessLevel ? accessLevel : null;
            };

            $scope.setAccessLevelSection = function (menuItem, accessLevel)
            {
                menuItem.AccessLevel = menuItem.AccessLevel !== accessLevel ? accessLevel : null;
                arraySetAllValues(menuItem.Items, "AccessLevel", menuItem.AccessLevel);
            };

            $scope.setAccessLevelAll = function (accessLevel)
            {
                $scope.AccessLevel = $scope.AccessLevel !== accessLevel ? accessLevel : null;

                for (var i = 0; i < $scope.menuItems.length; i++)
                {
                    $scope.menuItems[i].AccessLevel = $scope.AccessLevel;
                    arraySetAllValues($scope.menuItems[i].Items, "AccessLevel", $scope.AccessLevel);
                }
            };

            $scope.saveUser = function ()
            {
                $scope.application.showLoading = true;

                $scope.user.IsActive = true;

                userManagementService.saveUser($scope.user).success(function ()
                {
                    $scope.application.showLoading = false;
                    $scope.saveMenuItems();
                });
            };

            $scope.saveMenuItems = function ()
            {
                $scope.application.showLoading = true;

                var userAccess = {
                    UserId: $scope.user.Id,
                    MenuItems: $scope.menuItems
                }

                userManagementService.saveUserAccess(userAccess).success(function ()
                {
                    $scope.application.showLoading = false;
                    $scope.$emit('UserAccessSaved');
                });
            };

            $scope.cancelUser = function ()
            {
                $scope.$emit('UserCancelled');
            };
            

            // Events

            $scope.$on('UserSelected', function (e, user)
            {
                $scope.menuItems = undefined;

                if (typeof user === "undefined" || user === null)
                    return;

                $scope.application.showLoading = true;

                userManagementService.getUserAccess(user.Id).success(function (response)
                {
                    $scope.menuItems = response.MenuItems;
                    $scope.setUserRole(user.Role);

                    $scope.application.showLoading = false;
                });
            });


            // On Load

            userManagementService.getUserRoles().success(function (response)
            {
                $scope.userRoles = response;
            });

            userManagementService.getUserAccessLevels().success(function (response)
            {
                $scope.accessLevels = response;
            });

        }]);
})();
