﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IFundTICLogic
    {

        //void StageFundTICSheet(string fileName, string userID);

        void StageFundTICSheet(Entities.FundTIC fundTIC, string userID);

        List<Entities.FundTIC> GetPendingFundTICs();

        void SaveFundTIC(string userID);
        void RejectFundTIC(string userID); 

    }
}