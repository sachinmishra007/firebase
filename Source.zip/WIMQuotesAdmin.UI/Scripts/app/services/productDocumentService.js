﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('productDocumentService', ['$http', function ($http)
        {
            var productDocumentService = {};

            productDocumentService.getProducts = function ()
            {
                return $http({ url: 'api/ProductDocument/Products' });
            };

            productDocumentService.getProductDocumentUrl = function (productCode, language, documentType, platform)
            {
                return 'api/ProductDocument/Document?productCode=' + productCode + '&language=' + language + '&documentType=' + documentType + '&platform=' + platform + '&rnd=' + new Date().getTime();
            };

            productDocumentService.checkDocumentExists = function (productCode, language, documentType, platform)
            {
                return $http({ url: 'api/ProductDocument/DocumentExists?productCode=' + productCode + '&language=' + language + '&documentType=' + documentType + '&platform=' + platform });
            };

            return productDocumentService;
        }]);
})();

