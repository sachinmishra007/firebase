﻿using System;
using System.Web.Mvc;

using WIMI.Quotes.UI.Web.ModelBinders;

namespace WIMI.Quotes.UI
{
    public static class ModelBinderConfig
    {
        public static void RegisterModelBinders(ModelBinderDictionary modelBinders)
        {
            modelBinders.Add(typeof(Guid), new GuidModelBinder());
        }
    }
}