﻿
(function (window)
{
    'use strict';

    window.testData = {
        hookupHttpBackend: function (httpBackend)
        {
            // Lookup

            httpBackend.when('GET', /api\/Lookup\/getCurrencies/, undefined, undefined, [])
              .respond(function (method, url, data, headers, params)
              {
                  return [200, testData.getCustomLookupItems('Currency')];
              });

            httpBackend.when('GET', /api\/Client\/Contributions\/\?clientNumber=(.+)&productCode=?(.+)/, undefined, undefined, ['clientNumber', 'productCode'])
              .respond(function (method, url, data, headers, params)
              {
                  return [200, testData.getClient(params.clientNumber, params.productCode)];
              });

            httpBackend.whenGET(/api\/QuoteItem\/Group\/(.+)/, undefined, undefined, ['quoteItemId'])
            .respond(function (method, url, data, headers, params)
            {
                return [200, testData.getQuoteItems('77726711-db8c-4b3b-890b-ee439a43ea6d')];
            });
            httpBackend.whenGET(/api\/Lookup\/(.+)/, undefined, undefined, ['code'])
                    .respond(function (method, url, data, headers, params)
                    {
                        return [200, testData.getCustomLookupItems('TAXMONTH')];
                    });

            // Ng Includes
            httpBackend.when('GET', /Views\/Partials\/QuoteDetails\/Funds.html/, undefined, undefined, [])
                .respond(function (method, url, data, headers, params)
                {
                    return [200, {}];
                });

            httpBackend.when('GET', /Views\/Partials\/QuoteDetails\/Regulation28.html/, undefined, undefined, [])
               .respond(function (method, url, data, headers, params)
               {
                   return [200, {}];
               });


        },
        getCustomLookupItems: function (code)
        {
            switch (code)
            {
                case 'Currency':
                    return [{
                        Code: 'ZA',
                        Description: 'South Africa',
                        IsSelected: false
                    },
                    {
                        Code: 'AF',
                        Description: 'Afghanistan',
                        IsSelected: false
                    }];
                case 'TAXFREESAV':
                    return '03';

            }

            return null;
        },

        getClient: function (clientNumber, productCode)
        {
            return [{
                RemainingNettLife: 25000,
                RemainingNettTaxYear: 30000
            }];
        },

        getQuoteItems: function (quoteItemId)
        {
            return [{
             isReadOnly: true,
             selectedAdvisor: '00011774',
            selectedClient: 'AI83587',
            quoteItems : 'response'
            }];
        }

    };

})(window);

