﻿namespace WIMQuotesAdmin.Entities
{
    public enum StagingStatus
    {
        Uncaptured = 0,
        PendingAuthorise = 1,
        Authorise = 2,
        Reject = 3
    }
}
