﻿using System;
using System.Collections.Generic;
using System.Linq;

using WIMQuotesAdmin.DataAccess.PortfolioAdminService;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class FundIMLRepository : Contracts.IFundIMLRepository
    {
        public Entities.FundIML GetFundIML(string fundCode)
        {
            using (var context = new PortfolioPerformanceService.PortfolioPerformanceServiceClient())
            {
                return new Entities.FundIML
                {
                    FundCode = fundCode,
                    IntendedMaximumLimits = context.GetFundIMLs(fundCode).Select(i => new Entities.IntendedMaximumLimit
                    {
                        Id = i.Id,
                        Code = i.Code,
                        Name = i.Name,
                        Value = (decimal)i.UpperLimit
                    }).ToList()
                };
            }
        }

        public Entities.FundIML GetPendingFundIML(string fundCode)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundIMLs = context.FundIMLStagings
                    .Where(f => f.FundCode == fundCode && 
                                f.Status == (int)Entities.StagingStatus.PendingAuthorise).ToList();
                
                var mappedFundIML = Mappings.WIMQuotesAdminStagingMapping.FromFundIMLStaging(contextFundIMLs);
                return mappedFundIML.Count == 0 ? null : mappedFundIML.FirstOrDefault();
            }
        }

        public List<Entities.FundIML> GetPendingFundIMLs()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundIMLs = context.FundIMLStagings.Where(f => f.Status == (int)Entities.StagingStatus.PendingAuthorise).ToList();
                return Mappings.WIMQuotesAdminStagingMapping.FromFundIMLStaging(contextFundIMLs);
            }
        }

        public List<Entities.IntendedMaximumLimit> GetIntendedMaximumLimits()
        {
            using (var context = new PortfolioPerformanceService.PortfolioPerformanceServiceClient())
            {
                return context.GetRegulation28Limits().Select(a => new Entities.IntendedMaximumLimit
                {
                    Id = a.TypeId,
                    Code = a.Code,
                    Name = a.Name,
                    Value = (decimal)a.Value
                }).ToList();
            }
        }

        public void SaveFundIMLToStaging(Entities.FundIML fundIML)
        {
            if (fundIML == null || fundIML.IntendedMaximumLimits == null || fundIML.IntendedMaximumLimits.Count == 0 || 
                string.IsNullOrWhiteSpace(fundIML.UserId))
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundIMLs = Mappings.WIMQuotesAdminStagingMapping.ToFundIMLStaging(fundIML);

                if (contextFundIMLs == null)
                    return;

                context.FundIMLStagings.AddRange(contextFundIMLs);
                context.SaveChanges();
            }
        }

        public void UpdateFundIMLStagingStatus(string fundCode, Entities.StagingStatus status, string userId)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundIMLs = context.FundIMLStagings
                    .Where(f => f.FundCode == fundCode && 
                                f.Status == (int)Entities.StagingStatus.PendingAuthorise);

                foreach (var contextFundIML in contextFundIMLs)
                {
                    contextFundIML.Status = (int)status;
                    contextFundIML.ModifiedUserId = userId;
                    contextFundIML.ModifiedDateTime = DateTime.Now;
                }

                context.SaveChanges();
            }
        }

        public void SaveAuthorisedFundIML(Entities.FundIML fundIML)
        {
            if (fundIML == null)
                return;

            using (var context = new PortfolioAdminServiceClient())
            {
                context.SaveIML(Mappings.PortfolioAdminServiceMapping.ToFundIML(fundIML));
            }
        }
    }
}

