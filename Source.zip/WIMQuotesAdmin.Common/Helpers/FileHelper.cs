﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace WIMQuotesAdmin.Common.Helpers
{
    public static class FileHelper
    {

        public static bool Save(Byte[] Data, string path)
        {
            BinaryWriter Writer = null;
            try
            {
                // Create a new stream to write to the file
                Writer = new BinaryWriter(File.OpenWrite(path));

                // Writer raw data                
                Writer.Write(Data);
                Writer.Flush();
                Writer.Close();
            }
            catch
            {
                //...
                return false;
            }

            return true;
        }


        public static bool CreateFile(Byte[] Data, string fileName)
        {
            bool result = false;

            try
            {
                //  string path = ConfigurationManager.AppSettings["FilePathUpload"].ToString();// @"C:\Users\EXAG218\Documents";

                //  path = System.IO.Path.Combine(path, fileName);

                string path = fileName;

                if (!System.IO.File.Exists(path))
                {
                    using (System.IO.FileStream fs = System.IO.File.Create(path))
                    {

                        foreach (var item in Data)
                        {
                            fs.WriteByte(item);
                        }
                        return result = fs != null;
                    }

                }
            }
            catch (Exception)
            {

                throw;
            }
            return result;
        }


        public static bool Delete(string fileName)
        {

            //string path = ConfigurationManager.AppSettings["FilePathUpload"].ToString();

            //path = System.IO.Path.Combine(path, fileName);
            try
            {
                System.IO.File.Delete(fileName);
            }
            catch
            {

                return false;
            }

            return true;
        }
    }
}


