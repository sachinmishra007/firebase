﻿
(function () {
    'use strict';


    angular.module('quotesApp.controllers')
        .controller('fundsController', ['$scope', '$rootScope', 'lookupService', 'fundService', 'commonUtils', function ($scope, $rootScope, lookupService, fundService, commonUtils) {
            $scope.fundRangeList = [];
            $scope.fundsList = [];
            $scope.selectedFund = {};
            $scope.pspProductList = lookupService.getPSPProduct();
            $scope.disableAddButton = false;
            $scope.phaseFromFundCode = "ABMM";

            // Private  Members

            var sumArray = function (array, propertyName) {
                var total = 0.00;

                if (!commonUtils.isUndefinedOrEmpty(array)) {
                    for (var i = 0; i < array.length; i++) {
                        var amount = parseFloat(array[i][propertyName]);
                        total += isNaN(amount) ? 0 : amount;
                    }
                }
                return total;
            };

            var recalculateAmounts = function () {
                for (var i = 0; i < $scope.profile.Funds.length; i++) {
                    $scope.calculateAmount($scope.profile.Funds[i]);
                }
            }

            var checkPspProduct = function () {
                var isPSP = false;
                for (var i = 0; i < $scope.pspProductList.length; i++) {
                    if ($scope.pspProductList[i].Code === $scope.quoteItem.Product.Code) {
                        isPSP = true;
                        break;
                    }
                }
                return isPSP;
            }

            var checkPspfund = function (fundList) {
                var fundsList = [];

                for (var i = 0; i < fundList.length; i++) {
                    if (fundList[i].IsSharedPortfolio) {
                        fundsList.push(fundList[i]);
                    }

                }
                return fundsList;
            }

            var checkAddFundForPsp = function () {
                for (var i = 0; i < $scope.profile.Funds.length; i++) {
                    if ($scope.profile.Funds[i].IsSharedPortfolio) {
                        $scope.disableAddButton = true;
                        break;

                    }

                }

            }


            // On Load

            if (commonUtils.isUndefinedOrEmpty($scope.profile))
                $scope.profile = {};

            if (commonUtils.isUndefinedOrEmpty($scope.profile.Funds))
                $scope.profile.Funds = [];

            $scope.showUseLumpSumFunds = $scope.profile.ShowUseLumpSumFunds;
            $scope.showExistingLumpSumFunds = $scope.profile.ShowExistingLumpSumFunds;
            $scope.labelFundPercentage = $scope.profile.LabelFundPercentage;
            $scope.labelFundAmount = $scope.profile.LabelFundAmount;

            if ($scope.profile.Type !== 'Income') {
                $scope.fundRangeList = lookupService
                      .getFundRanges($scope.quoteItem.Product.Code, $scope.profile.Type)
                      .success(function (response) {
                          $scope.fundRangeList = response;
                          $scope.selectedFundRange = $scope.fundRangeList[0];

                          $scope.getFunds($scope.quoteItem.Product.Code, $scope.selectedFundRange.Code, $scope.application.selectedAdvisor.Code);

                      });
            }
            else {
                $scope.fundsList = $scope.quoteItem.lumpSumProfile.Funds;
                $scope.hasCustomFundSelection = true;
            }


            // Behaviours 

            $scope.calculateTotalAmount = function () {
                return sumArray($scope.profile.Funds, 'Amount');
            };

            $scope.calculateTotalPercentage = function () {
                return sumArray($scope.profile.Funds, 'Percentage');
            };

            $scope.getFunds = function (productCode, fundRangeCode, advisorCode) {

                // $scope.application.showLoading = true;
                $scope.fundsList = [];
                var newPspFundList = undefined;

                if (fundRangeCode === 'PSP') {
                    if (!commonUtils.isUndefinedOrEmpty($scope.quoteItem.clientPolicyFundList) && checkPspProduct()) {
                        newPspFundList = checkPspfund($scope.quoteItem.clientPolicyFundList);

                    }
                }

                //  if (newPspFundList.length > 0)
                if (!commonUtils.isUndefinedOrEmpty(newPspFundList) && newPspFundList.length > 0) {
                    $scope.fundsList = newPspFundList;
                }
                else {
                    fundService
                            .getFundsList(productCode, fundRangeCode, advisorCode, CheckIfPhaseInFundSelected())
                            .success(function (response) {
                                $scope.fundsList = response;
                                $scope.application.showLoading = false;
                            });
                }


            };

            $scope.removeRow = function (index) {
                var fundCode;

                if ($scope.maxPSP() > 0 && $scope.quoteItem.Product.Code === 'LIVANN') {
                    $rootScope.$broadcast('profile.IncomeFrequencyChanged', { IsAdd: false, IsRemove: true });
                }

                if ($scope.profile.Type === 'LumpSum') {
                    for (var i = 0; i < $scope.profile.Funds.length; i++) {
                        if (i === index) {
                            fundCode = $scope.profile.Funds[i].Code;
                            break;
                        }
                    }
                    $scope.profile.Funds.splice(index, 1);
                    $rootScope.$broadcast('profile.LumpSum_RowRemoved', { FundCode: fundCode });

                }
                else {
                    $scope.profile.Funds.splice(index, 1);
                }
            };

            $scope.addFund = function (selectedFund) {
                if (typeof selectedFund === "undefined" || selectedFund === null ||
                    typeof selectedFund.Code === "undefined" || selectedFund.Code === "")
                    return;

                var isUnique = true;

                for (var i = 0; i < $scope.profile.Funds.length; i++) {
                    if ($scope.profile.Funds[i].Code === selectedFund.Code)
                        isUnique = false;
                }

                if (isUnique) {
                    var newFund = angular.copy(selectedFund);
                    newFund.Amount = 0.00;
                    newFund.Percentage = 0.00;

                    $scope.profile.Funds.push(newFund);
                }

                if ($scope.maxPSP() > 0 && $scope.quoteItem.Product.Code === 'LIVANN') {
                    $rootScope.$broadcast('profile.IncomeFrequencyChanged', { IsAdd: true, IsRemove: false });
                }
            };

            $scope.calculatePercentage = function (fund) {
                var totalAmount = parseFloat($scope.profile.Amount);

                if (isNaN(totalAmount))
                    fund.Percentage = 0.00;
                else
                    fund.Percentage = (fund.Amount / totalAmount * 100.00).toFixed(2);
            };

            $scope.calculateAmount = function (fund) {
                var totalAmount = parseFloat($scope.profile.Amount);
                fund.Amount = ((isNaN(totalAmount) ? 0 : totalAmount) * (fund.Percentage / 100.00)).toFixed(2);
            };

            $scope.copyLumpSumFunds = function () {
                var newFunds = angular.copy($scope.quoteItem.lumpSumProfile.Funds);
                $scope.profile.Funds.splice(0, $scope.profile.Funds.length);

                for (var i = 0; i < newFunds.length; i++) {
                    newFunds[i].Amount = 0.00;
                    $scope.profile.Funds.push(newFunds[i]);
                }

                recalculateAmounts();
            };

            $scope.copyExistingFunds = function () {
                var newFunds = angular.copy($scope.quoteItem.additionProfile.Funds);
                var hasPhaseIn = ($scope.quoteItem.phaseInProfile || {}).IsActive;
                console.log(hasPhaseIn);
                for (var i = $scope.profile.Funds.length - 1; i >= 0; i--) {
                    if (!hasPhaseIn || $scope.profile.Funds[i].Code !== $scope.phaseFromFundCode)
                        $scope.profile.Funds.splice(i, 1);
                }

                for (var i = 0; i < newFunds.length; i++) {
                    if (!hasPhaseIn || newFunds[i].Code !== $scope.phaseFromFundCode) {
                        newFunds[i].Amount = 0.00;
                        $scope.profile.Funds.push(newFunds[i]);
                    }
                }

                recalculateAmounts();
            };

            $scope.disableProfileForPsp = function () {
                if ($scope.profile.Type === 'Income')
                    return false;

                return $scope.maxPSP() > 0;
            };

            $scope.disableAddFundButton = function () {
                $scope.disableAddButton = false;

                if ($scope.selectedFundRange.Code === 'PSP') {
                    checkAddFundForPsp();
                }

            }


            // Events

            var amountChanged = $scope.$on('profile.AmountChanged', function () {
                recalculateAmounts();
            });


            var removeRowIncome = $rootScope.$on('profile.LumpSum_RowRemoved', function (event, eventArg) {
                if ($scope.profile.Type !== 'Income')
                    return;

                for (var i = 0; i < $scope.profile.Funds.length; i++) {
                    if (eventArg.FundCode === $scope.profile.Funds[i].Code) {
                        $scope.profile.Funds.splice(i, 1);
                        break;
                    }
                }
            });

            // On Unload

            $scope.$on("$destroy", function () {
                amountChanged();
                removeRowIncome();
            });

            $scope.changeInPhaseInFund = function (fund) {
                if (fund.IsPhaseRemove != "undefined" && fund.IsPhaseRemove != null) {
                    //if (fund.IsPhaseRemove && fund.IsBringZeroAdminFeeFund) {
                        $scope.application.showLoading = true;
                        fundService
                            .getFundsList($scope.quoteItem.Product.Code, $scope.selectedFundRange.Code, $scope.quoteItem.Advisor.Code, fund.IsBringZeroAdminFeeFund)
                            .success(function (response) {
                                $scope.fundsList = response;
                                $scope.application.showLoading = false;
                            });
                    //}
                }
            }

            function CheckIfPhaseInFundSelected() {
                if ($scope.quoteItem.lumpSumProfile.Funds != "undefined" && $scope.quoteItem.lumpSumProfile.Funds != null) {
                    for (var i = 0; i < $scope.quoteItem.lumpSumProfile.Funds.length; i++) {
                        if ($scope.quoteItem.lumpSumProfile.Funds[i].IsBringZeroAdminFeeFund != "undefined" &&
                          $scope.quoteItem.lumpSumProfile.Funds[i].IsBringZeroAdminFeeFund != null) {
                            if ($scope.quoteItem.lumpSumProfile.Funds[i].IsBringZeroAdminFeeFund) {
                                return $scope.quoteItem.lumpSumProfile.Funds[i].IsBringZeroAdminFeeFund;
                            }
                        }
                    }
                }
                return false
            }


        }]);
})();
