﻿using System;
using System.Configuration;
using System.Web.Optimization;

namespace MorningStarWebTool
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            RegisterCommonBundles(bundles);
            RegisterCustomBundles(bundles);
            RegisterCustomTriggersEvent(bundles);
            RegisterCustomCDNBundles(bundles);            
            BundleTable.EnableOptimizations = true;
        }

        private static void RegisterCommonBundles(BundleCollection bundles)
        {
            // Scripts 

            var ckEditorBundle = new ScriptBundle("~/Scripts/common/ckeditor/bundle").
                Include("~/Scripts/common/ckeditor/ckeditor.js");
            ckEditorBundle.Transforms.Clear(); // Skips Transformation and will not minify bundle
            bundles.Add(ckEditorBundle);

            var chartsBundle = new ScriptBundle("~/Scripts/common/charts/bundle").Include(
                "~/Scripts/common/charts/chart.min.js",
                "~/Scripts/common/angular-chart.min.js");
            chartsBundle.Transforms.Clear(); // Skips Transformation and will not minify bundle
            bundles.Add(chartsBundle);

            bundles.Add(new ScriptBundle("~/Scripts/common/bundle").Include(
                "~/Scripts/common/jquery.min.js",
                "~/Scripts/common/chosen.jquery.min.js",
                "~/Scripts/common/angular.min.js",
                "~/Scripts/common/jquery-{version}.js",
                "~/Scripts/common/jquery-ui.js",
                "~/Scripts/common/FileSaver.js",
                "~/Scripts/common/bootstrap.min.js",
                "~/Scripts/common/angular-sanitize-1.4.2.min.js",
                "~/Scripts/common/angular-file-upload.min.js",
                "~/Scripts/common/angular.directives.js",
                "~/Scripts/common/scrollreveal.min.js",
                "~/Scripts/common/dirPagination.js"));


            // CSS

            bundles.Add(new StyleBundle("~/Content/styles/common/bundle").Include(
                "~/Content/styles/common/bootstrap.css",
                "~/Content/styles/common/jquery-ui.css",
                "~/Content/styles/common/chosen.css.map",
                "~/Content/styles/common/chosen.css"));

            bundles.Add(new StyleBundle("~/Content/styles/site/bundle").Include(
                "~/Content/styles/site/master.css",
                "~/Content/styles/site/input.css",
                "~/Content/styles/site/site.css"));
        }

        private static void RegisterCustomBundles(BundleCollection bundles)
        {
            // Scripts 

            bundles.Add(new ScriptBundle("~/Scripts/app/bundle")
                .Include("~/Scripts/app/app.js",
                "~/Scripts/app/filters.js")
                .IncludeDirectory("~/Scripts/app/services/", "*.js", true)
                .IncludeDirectory("~/Scripts/app/controllers/", "*.js", true));

            bundles.Add(new ScriptBundle("~/Scripts/custom/bundle").Include("~/Scripts/app/custom/custom.js"));
        }


        private static void RegisterCustomCDNBundles(BundleCollection bundles)
        {
            // Scripts 
            bundles.UseCdn = true;

            var _cdnPolyFill = ConfigurationManager.AppSettings["CDNPolyFill"].ToString();
            var _cdnMorningStar = ConfigurationManager.AppSettings["CDNMorningStarComponent"].ToString();
            var _cdnJquery = ConfigurationManager.AppSettings["CDNJQueryMin"].ToString();
            var _cdnHandlers = ConfigurationManager.AppSettings["CDNHandleBars"].ToString();
            var _cdnHandlebarsRuntime = ConfigurationManager.AppSettings["CDNHandlebarsRuntime"].ToString();

            var _defaultUrlToLoad = "~/Scripts/common/jquery.min.js";

            bundles.Add(new ScriptBundle("~/CDNCustomScript/CDNPolyFill/bundle", _cdnPolyFill).Include(_defaultUrlToLoad));
            bundles.Add(new ScriptBundle("~/CDNCustomScript/CDNMorningStar/bundle", _cdnMorningStar).Include(_defaultUrlToLoad));
            bundles.Add(new ScriptBundle("~/CDNCustomScript/CDNJQuery/bundle", _cdnJquery).Include(_defaultUrlToLoad));
            bundles.Add(new ScriptBundle("~/CDNCustomScript/CDNHandler/bundle", _cdnHandlers).Include(_defaultUrlToLoad));
            bundles.Add(new ScriptBundle("~/CDNCustomScript/CDNHandlerRuntime/bundle", _cdnHandlebarsRuntime).Include(_defaultUrlToLoad));
        }


        private static void RegisterCustomTriggersEvent(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/Scripts/morningStarComponentFundScreenerTriger/bundle")
              .Include("~/Scripts/morningStarComponentTrigger/MorningStarFundScreenerTrigger.js"));

            bundles.Add(new ScriptBundle("~/Scripts/morningStarComponentECLoaderXrayTriger/bundle")
              .Include("~/Scripts/morningStarComponentTrigger/MorningStarEcLoaderXrayTrigger.js"));

            bundles.Add(new ScriptBundle("~/Scripts/morningStarComponentFundReportTriger/bundle")
              .Include("~/Scripts/morningStarComponentTrigger/MorningStarFundReportTrigger.js"));
        }
    }
}