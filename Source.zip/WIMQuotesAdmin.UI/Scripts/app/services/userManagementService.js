﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('userManagementService', ['$http', function ($http)
        {
            var userManagementService = {};

            userManagementService.getUserProfile = function ()
            {
                return $http({ url: 'api/User' });
            };

            userManagementService.getUserRoles = function ()
            {
                return $http({ url: 'api/User/Roles' });
            };

            userManagementService.getUserAccessLevels = function ()
            {
                return $http({ url: 'api/User/AccessLevels' });
            };

            userManagementService.getUserAccess = function (userId)
            {
                return $http({ url: 'api/User/Access/' + userId });
            };

            userManagementService.searchNewUsers = function (searchTerm)
            {
                return $http({
                    url: 'api/User/SearchNewUsers/' + searchTerm
                });
            };

            userManagementService.searchExistingUsers = function (searchTerm)
            {
                return $http({
                    url: 'api/User/SearchExistingUsers/' + searchTerm
                });
            };

            userManagementService.saveUser = function (user)
            {
                return $http.post('api/User/', user);
            };

            userManagementService.saveUserAccess = function (userAccess)
            {
                return $http.post('api/User/SaveUserAccess', userAccess);
            };

            userManagementService.deleteUser = function (user)
            {
                return $http.post('api/User/Delete', user);
            };

            return userManagementService;
        }]);
})();

