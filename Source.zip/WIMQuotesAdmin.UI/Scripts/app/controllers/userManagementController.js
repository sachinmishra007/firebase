﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('userManagementController', ['$scope', '$timeout', 'userManagementService', function ($scope, $timeout, userManagementService)
        {
            $scope.usersList = [];
            $scope.user = undefined;
           
            $scope.popUpMessage = {
                isVisible: false,
                header: undefined,
                message: undefined,
                onContinue: undefined,
                show: function (header, message, onContinue)
                {
                    $scope.popUpMessage.isVisible = true,
                    $scope.popUpMessage.header = header,
                    $scope.popUpMessage.message = message;
                    $scope.popUpMessage.onContinue = onContinue;
                }
            };


            // Private Methods

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 5000);
            };

            var cancelUser = function()
            {
                $scope.user = undefined;
                $scope.usersList = [];
            };


            // Behaviours

            $scope.searchNewUsers = function (searchTerm)
            {
                return userManagementService.searchNewUsers(searchTerm).success(function (response)
                {
                    $scope.usersList = response;
                });
            };

            $scope.searchExistingUsers = function (searchTerm)
            {
                return userManagementService.searchExistingUsers(searchTerm).success(function (response)
                {
                    $scope.usersList = response;
                });
            };

            $scope.userSelected = function (user)
            {
                $scope.user = user;
                $scope.$broadcast('UserSelected', user);
            };

            $scope.deleteUser = function (user)
            {
                $scope.popUpMessage.show('Delete Existing User', 'Are you sure you want to delete user ' + user.Name + ' (' + user.Id + ')' + '?', function ()
                {
                    $scope.popUpMessage.isVisible = false;
                    $scope.application.showLoading = true;

                    userManagementService.deleteUser(user).success(function ()
                    {
                        showMessage($scope.user.Name + " (" + $scope.user.Id + ") deleted successfully");
                        $scope.application.showLoading = false;
                        cancelUser();
                    });
                });
            };


            // Events

            $scope.$on('UserAccessSaved', function ()
            {
                showMessage($scope.user.Name + " (" + $scope.user.Id + ") saved successfully");
                cancelUser();
            });

            $scope.$on('UserCancelled', function ()
            {
                cancelUser();
            });

        }]);
})();
