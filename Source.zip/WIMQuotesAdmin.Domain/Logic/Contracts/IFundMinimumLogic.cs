﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IFundMinimumLogic
    {
        List<Entities.FundMinimum> GetFundMinimumAmounts();
        List<Entities.FundMinimum> GetPendingFundMinimumAmounts();
        void StageFundMinimum(Entities.FundMinimum fundMinimum, string userId);
        void PendingFundMinimumUpdateStatus(List<Entities.FundMinimum> fundMinimum, string userId);
        List<Entities.Product> GetProducts();
        List<Entities.FundMinimum> GetFunds(string productId);
        List<Entities.FundMinimum> GetTransactionType(string productId, string fundId);
        void AddNewFundMinimum(Entities.FundMinimum fundMinimum, string UserID);
    }
}
