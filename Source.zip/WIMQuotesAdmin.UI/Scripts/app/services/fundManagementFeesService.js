﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('fundManagementFeesService', ['$http', function ($http)
        {
            var fundManagementFeesService = {};

            fundManagementFeesService.getFundManagementFees = function (fundType, fundCode)
            {
                return $http({ url: 'api/FundManagementFees/?fundType=' + fundType + '&fundCode=' + fundCode });
            };

            fundManagementFeesService.saveFundManagementFees = function (fundManageFees)
            {
                return $http.post('api/FundManagementFees', fundManageFees);
            };

            fundManagementFeesService.getUnmappedFunds = function ()
            {
                return $http({ url: 'api/FundManagementFees/GetUnmappedFunds' });
            };

            fundManagementFeesService.getPendingFundManagementFees = function ()
            {
                return $http({ url: 'api/FundManagementFees/Pending' });
            };

            fundManagementFeesService.updatePendingStatuses = function (fundManageFeeList)
            {
                return $http.post('api/FundManagementFees/UpdatePendingStatuses', fundManageFeeList);
            };

            return fundManagementFeesService;
        }]);
})();
