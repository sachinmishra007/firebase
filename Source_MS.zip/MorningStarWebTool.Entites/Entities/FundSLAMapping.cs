﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorningStarWebTool.Entites.Entities
{
    public class FundSLAMapping
    {
        public string FundId { get; set; }
        public string MSISIN { get; set; }
        public string FundShareClassId { get; set; }
        public string FundName { get; set; }
        public string FundCode { get; set; }
    }
}
