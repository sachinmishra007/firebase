﻿(function () {

    "use strict";

    angular.module('morningStar.services')
        .factory('MorningStarService', function ($http, ApplicationSetting) {
            var MorningStarService = {};
            var URL = ApplicationSetting.WebApiUrl.URL;

            MorningStarService.GetMornigStarFundMapping = function () {
                return $http({
                    method: 'GET',
                    cache: false,
                    url: URL + 'api/SlaFund/FundSLAMappings'
                })
            };

            MorningStarService.GetClientDetails = function (ClientParam, BrokerCode) {
                return $http({
                    method: 'GET',
                    cache: false,
                    url: URL + 'api/SlaFund/ClientDetails/?ClientParam=' + ClientParam + '&BrokerCode=' + BrokerCode
                })
            };

            MorningStarService.GetClientPolicyDetails = function (ClientNumber) {
                return $http({
                    method: 'GET',
                    cache: false,
                    url: URL + 'api/SlaFund/ClientPolicyDetails/?ClientNumber=' + ClientNumber,
                })
            };


            MorningStarService.GetClientFundPolicyDetails = function (ClientNumber, PolicyNumber) {
                return $http({
                    method: 'GET',
                    cache: false,
                    url: URL + 'api/SlaFund/ClientPolicyFundDetails/?ClientNumber=' + ClientNumber + "&PolicyNumber=" + PolicyNumber,
                })
            };


            MorningStarService.GetBrokerCodeFromSession = function () {
                return $http({
                    method: 'GET',
                    cache: false,
                    url: URL + 'Entry/GetBrokerCodeFormSession/'
                })
            };


            //MornningStarService.GetClientPrimaryDetails = function (_clientInfo) {
            //    console.log(_clientInfo);
            //    return $http({
            //        method: 'POST',
            //        dataType: 'JSON',
            //        cache: false,
            //        headers: { 'Content-Type': 'application/json' },
            //        url: '/MorningStarWebTool/api/SlaFund/ClientPrimaryInformation/',
            //        data: JSON.stringify(_clientInfo)
            //    })
            //};

            return MorningStarService;
        });

})();