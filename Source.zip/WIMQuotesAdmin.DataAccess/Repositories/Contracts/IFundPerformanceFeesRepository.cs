﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IFundPerformanceFeesRepository
    {
        Entities.FundPerformanceFees GetFundPerformaneFees(string fundCode);
        void SaveFundPerformanceFeesStaging(Entities.PerformanceFees performanceFees, string fundCode, string userId);
        List<Entities.Fund> GetUnmappedFunds();
        List<Entities.TimePeriod> GetMorningStarTimePeriod();
        List<Entities.FundPerformanceFees> GetPendingFundPerformanceFees();
        void UpdateFundAssetsStagingStatus(string fundCode, Entities.StagingStatus status, string userId, int timePeriod);
        void SaveAuthorisedFundAsset(Entities.FundPerformanceFees fundPerformanceFees);
        void DeleteAuthorisedFundAsset(Entities.FundPerformanceFees fundPerformanceFees);
        Entities.FundPerformanceFees GetPendingFundPerformanceFees(string fundCode);
        List<Entities.Fund> GetAvailablePerformanceFeeFunds();
        
    }
}
