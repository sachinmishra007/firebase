﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IProductNotesLogic
    {
        List<Entities.Note> GetProductNotes(string productCode, Entities.Language language);
        List<Entities.Product> GetNotesProducts();
        void StageProductNote(Entities.Note note, string userId);
        List<Entities.Note> GetPendingProductNotes();
        void PendingNotesUpdateStatus(List<Entities.Note> notes, string userId);
    }
}