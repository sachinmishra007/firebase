﻿using System.Collections.Generic;

using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class MenuLogic : Contracts.IMenuLogic
    {
        #region Constructor

        private readonly IQuoteAdminRepository _quoteAdminRepository;

        public MenuLogic(IQuoteAdminRepository quoteAdminRepository)
        {
            _quoteAdminRepository = quoteAdminRepository;
        }

        #endregion

        public List<Entities.MenuItem> Get(string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return new List<Entities.MenuItem>();

            return _quoteAdminRepository.GetMenuItems(userId);
        }
    }
}
