﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IRegulation28LimitsRepository
    {
        List<Entities.Regulation28Limits> GetRegulation28Limits();
        void StagingRegulation28Limits(Entities.Regulation28Limits limits);
        Entities.Regulation28Limits GetPendingRegulation28Limit(string code);
        void PendingRegulation28LimitsUpdateStatus(string code, Entities.StagingStatus status, string userId);
        void SaveAuthorisedLimit(Entities.Regulation28Limits limit);
        List<Entities.Regulation28Limits> GetPendingRegulation28Limits();
    }
}