﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class CDSBreakdownRepository : ICDSBreakdownRepository
    {
        public List<Entities.CDSBreakdownReport> GetCDSBreakdownReport(DateTime startDate, DateTime endDate, string brokerCode)
        {
            if (startDate == null || endDate == null)
                return null;

            using(var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                var report = context.GetCDSBreakdownReport(startDate, endDate, brokerCode);

                return report.Select(r => new Entities.CDSBreakdownReport
                {
                    DateCreated = r.DateCreated,
                    BrokerRegion = r.BrokerRegion,
                    BrokerHouse = r.BrokerHouse,
                    BrokerCode = r.BrokerCode,
                    UserId = r.UserId,
                    ProductName = r.ProductName,
                    QuoteNumber = r.QuoteNumber,
                    LumpSum = r.LumpSum,
                    ClientNumber = r.ClientNumber,
                    ClientName = r.ClientName,
                    BrokerName = r.BrokerName,
                    StaffName = r.StaffName
                }).ToList();
            }
        }
    }
}
