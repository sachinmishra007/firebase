﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.Domain.Logic.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class AdminActivityReportLogic : IAdminActivityReportLogic
    {

        private readonly WIMQuotesAdmin.DataAccess.Repositories.Contracts.IAdminActivityReportRepository _adminActivityReportRepository;

        public AdminActivityReportLogic(WIMQuotesAdmin.DataAccess.Repositories.Contracts.IAdminActivityReportRepository adminActivityReportRepository)
        {
            _adminActivityReportRepository = adminActivityReportRepository;
        }

        public List<Entities.AdminActivityReport> GetAdminActivityReport(Entities.AdminActivityReportDetail details)
        {
            return _adminActivityReportRepository.GetAdminActivityReport(details);
        }
    }
}
