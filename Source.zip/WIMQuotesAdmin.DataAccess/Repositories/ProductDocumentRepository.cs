﻿using System.Collections.Generic;
using System.Linq;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class ProductDocumentRepository : Contracts.IProductDocumentRepository
    {
        public List<Entities.Product> GetProducts()
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var products = context.GetProductBrochureApplicableProducts();

                if (products == null || products.Count == 0)
                    return null;

                return products.Select(p => new Entities.Product
                {
                    Code = p.Code,
                    Name = p.Name
                }).ToList();
            }
        }

        public Entities.File GetProductDocument(string productCode, Entities.Language language, Entities.DocumentType documentType)
        {
            using (var context = new PortfolioPerformanceService.PortfolioPerformanceServiceClient())
            {
                var productDocument = context.GetProductDocument(productCode, Mappings.PortfolioPerformanceServiceMapping.ToLanguage(language),
                    Mappings.PortfolioPerformanceServiceMapping.ToDocumentType(documentType));

                if (productDocument == null || productDocument.Data == null || productDocument.Data.Length == 0)
                    return null;

                return new Entities.File
                {
                    Name = productDocument.Name,
                    FullQualifiedName = productDocument.Name,
                    Data = productDocument.Data
                };
            }
        }
    }
}

