﻿namespace WIMQuotesAdmin.Entities
{
   public class TaxInformation
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
