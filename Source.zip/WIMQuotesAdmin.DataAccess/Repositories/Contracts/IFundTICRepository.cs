﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IFundTICRepository
    {
       // void StageFundTICSheet(List<Entities.FundTIC> fundTIC);

       void StageFundTICSheet(OleDbDataReader reader,string userID);

       List<Entities.FundTIC> GetPendingFundTICs();

       void AutoriseRejectFundTIC(Entities.StagingStatus status, string userID);
       void SaveAuthorisedFundTIC();

       
    }
}
