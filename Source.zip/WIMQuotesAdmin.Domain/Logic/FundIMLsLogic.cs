﻿using System;
using System.Collections.Generic;
using System.Linq;
using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class FundIMLsLogic : Contracts.IFundIMLsLogic
    {
        #region Constructor

        private readonly DataAccess.Repositories.Contracts.IFundIMLRepository _fundIMLRepository;
        private readonly DataAccess.Repositories.Contracts.IPortfolioAdminRepository _portfolioAdminRepository;

        private readonly DataAccess.Repositories.Contracts.IPortfolioPerformanceRepository
            _portfolioPerformanceRepository;

        public FundIMLsLogic(DataAccess.Repositories.Contracts.IFundIMLRepository fundIMLRepository,
            DataAccess.Repositories.Contracts.IPortfolioAdminRepository portfolioAdminRepository, IPortfolioPerformanceRepository portfolioPerformanceRepository)
        {
            _fundIMLRepository = fundIMLRepository;
            _portfolioAdminRepository = portfolioAdminRepository;
            _portfolioPerformanceRepository = portfolioPerformanceRepository;
        }

        #endregion

        public List<Entities.Fund> GetAvailableFunds()
        {
            return _portfolioAdminRepository.GetAssetClassesAvailableFunds();
        }

        public Entities.FundIML Get(string fundCode)
        {
            var fundIML = _fundIMLRepository.GetFundIML(fundCode);
            var pendingFundIML = GetPendingFundIML(fundCode);

            if (pendingFundIML == null)
                return fundIML;

            fundIML.Status = pendingFundIML.Status;
            fundIML.UserId = pendingFundIML.UserId;
            fundIML.ModifiedDateTime = pendingFundIML.ModifiedDateTime;

            return fundIML;
        }

        public List<Entities.FundIML> GetPendingFundIMLs()
        {
            return _fundIMLRepository.GetPendingFundIMLs();
        }

        public List<Entities.IntendedMaximumLimit> GetUnmappedIMLsForFund(string fundCode)
        {
            var fundIML = Get(fundCode) ?? new Entities.FundIML();
            var availableIMLs = _fundIMLRepository.GetIntendedMaximumLimits();

            var unmappedIMLs = availableIMLs.Where(i => fundIML.IntendedMaximumLimits.All(a => a.Code != i.Code)).ToList();
            unmappedIMLs.ForEach(i => i.Value = 0);

            return unmappedIMLs;
        }

        public void StageIntendedMaximumLimits(Entities.FundIML fundIML, string userId)
        {
            if (fundIML == null || string.IsNullOrWhiteSpace(userId))
                return;

            fundIML.Status = Entities.StagingStatus.PendingAuthorise;
            fundIML.UserId = userId;
            fundIML.ModifiedDateTime = DateTime.Now;

            _fundIMLRepository.SaveFundIMLToStaging(fundIML);
        }

        public void PendingFundIMLsUpdateStatus(List<Entities.FundIML> fundIMLs, string userId)
        {
            if (fundIMLs == null || fundIMLs.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return;

            foreach (var fundIML in fundIMLs)
            {
                switch (fundIML.Status)
                {
                    case Entities.StagingStatus.Authorise:
                    {
                        PendingFundIMLAuthorise(fundIML.FundCode, userId);
                        _fundIMLRepository.SaveAuthorisedFundIML(fundIML);
                        break;
                    }
                    case Entities.StagingStatus.Reject:
                        PendingFundIMLReject(fundIML.FundCode, userId);
                        break;
                }
            }
        }

        #region Private Methods

        private Entities.FundIML GetPendingFundIML(string fundCode)
        {
            return _fundIMLRepository.GetPendingFundIML(fundCode);
        }

        private void PendingFundIMLAuthorise(string fundCode, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            var fundIML = _fundIMLRepository.GetPendingFundIML(fundCode);

            if (fundIML == null)
                return;

            _fundIMLRepository.SaveAuthorisedFundIML(fundIML);
            _fundIMLRepository.UpdateFundIMLStagingStatus(fundCode, Entities.StagingStatus.Authorise, userId);
        }

        private void PendingFundIMLReject(string fundCode, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            _fundIMLRepository.UpdateFundIMLStagingStatus(fundCode, Entities.StagingStatus.Reject, userId);
        }

        #endregion
    }
}
