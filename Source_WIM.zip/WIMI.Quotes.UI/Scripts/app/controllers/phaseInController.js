﻿
(function () {
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('phaseInController', ['$scope', '$rootScope', 'phaseInService', 'commonUtils',
    function ($scope, $rootScope, phaseInService, commonUtils) {
        $scope.profile = {};

        var offsetMs = 1000 * 60 * 60 * 24 * 93; // Offset by 2 months;

        $scope.startDate = new Date();
        $scope.endDate = new Date();

        $scope.endDate.setTime($scope.startDate.getTime() + offsetMs);
        $scope.selectedPhaseInProduct = {};
        $rootScope.phaseInSelectedCode = {};

        // Behaviours 

        $scope.init = function (profile) {
            $scope.profile = profile;
            $scope.profile.ShowUseLumpSumFunds = false;
            $scope.profile.ShowExistingLumpSumFunds = false;
            $scope.quoteItem.phaseInProfile = $scope.profile;

            //DEV-20935
            $scope.quoteItem.phaseInAvailableFunds = phaseInService.getPhaseInFundDetails();
            console.log($scope.quoteItem);

            if (commonUtils.isUndefinedOrEmpty($scope.profile.PhaseInLumpSumAmount))
                $scope.profile.PhaseInLumpSumAmount = 0.00

            if (commonUtils.isUndefinedOrEmpty($scope.profile.Amount))
                $scope.profile.Amount = 0.00

            if (typeof $scope.profile.Funds === "undefined")
                $scope.profile.Funds = [];

            $scope.profile.LabelFundPercentage = "Monthly Phase-in Allocation Percentage";
            $scope.profile.LabelFundAmount = "Monthly Phase-in Allocation Amount";

            phaseInService.getFirstDate().success(function (response) {
                $scope.profile.PhaseInCommencementDate = response;
            });
        };

        $scope.amountChanged = function () {
            $scope.$broadcast('profile.AmountChanged', null);
        };

        //$scope.validatePhaseInLumpsumAmt = function ()
        //{
        //    var total = 0.00;

        //    //if (!commonUtils.isUndefinedOrEmpty($scope.quoteItem.lumpSumProfile) &&
        //    //    !commonUtils.isUndefinedOrEmpty($scope.quoteItem.lumpSumProfile.Funds) && $scope.quoteItem.lumpSumProfile.Funds.length > 0)
        //    //{

        //    //    for (var i = 0; i < $scope.quoteItem.lumpSumProfile.Funds.length; i++)
        //    //    {
        //    //        if (!$scope.quoteItem.lumpSumProfile.Funds[i].IsSharedPortfolio)
        //    //        {
        //    //            var amount = parseFloat($scope.quoteItem.lumpSumProfile.Funds[i].Amount);
        //    //            total += isNaN(amount) ? 0 : amount;
        //    //        }
        //    //    }
        //    //}

        //    //else
        //    //{
        //    //    if (!commonUtils.isUndefinedOrEmpty($scope.quoteItem.lumpSumProfile) && !commonUtils.isUndefinedOrEmpty($scope.quoteItem.lumpSumProfile.Amount))
        //    //    {
        //    //        total = $scope.quoteItem.lumpSumProfile.Amount;

        //    //    }

        //    //}

        //    return total;
        //}


        $scope.validatePhaseInMonthAmt = function () {
            var total = 0;
            var amount = $scope.profile.Amount === 0 ? 0.00 : $scope.profile.PhaseInLumpSumAmount / $scope.profile.Amount;
            total = parseInt(amount, 10)
            return total;
        }

        $scope.validatePhaseInMinmumAmt = function () {
            var total = 0;

            var amount = $scope.profile.Amount === 0 ? 0.00 : $scope.profile.PhaseInLumpSumAmount / 12;
            amount = amount.toFixed(2);
            total = parseFloat(amount, 10);
            return total;
        }

        //DEV - 20935
        $scope.selectedPhaseInFund = function (fundCode) {
            var isEnabled = true;
            if ($scope.quoteItem.lumpSumProfile.Funds != "undefined" || $scope.quoteItem.lumpSumProfile.Funds != null) {
                if ($scope.quoteItem.lumpSumProfile.Funds.length >= 0) {

                    if (isEnabled) {
                        for (var i = 0; i < $scope.quoteItem.Profiles.length; i++) {
                            if (typeof $scope.quoteItem.Profiles[i].Funds === "undefined" || $scope.quoteItem.Profiles[i].Funds === null ||
                                $scope.quoteItem.Profiles[i].Funds === 0)
                                continue;

                            if ($scope.quoteItem.Profiles[i].Type === "LumpSum") {
                                var isUnique = true;

                                for (var j = 0; j < $scope.quoteItem.Profiles[i].Funds.length; j++) {
                                    if ($scope.quoteItem.Profiles[i].Funds[j].Code === fundCode.Code)
                                        isUnique = false;
                                }

                                if (isUnique) {

                                    //make default selection for the  phase In Selected Phase in Fund as False 
                                    for (var phaseInRestbit = 0; phaseInRestbit < $scope.quoteItem.phaseInAvailableFunds.length; phaseInRestbit++) {
                                        $scope.quoteItem.phaseInAvailableFunds[phaseInRestbit].IsSelectedPhaseInFund = false;
                                    }

                                    //make Selected Phase in Fund as True
                                    for (var phaseInSelbit = 0; phaseInSelbit < $scope.quoteItem.phaseInAvailableFunds.length; phaseInSelbit++) {
                                        if ($scope.quoteItem.phaseInAvailableFunds[phaseInSelbit].Code === fundCode.Code) {
                                            $scope.quoteItem.phaseInAvailableFunds[phaseInSelbit].IsSelectedPhaseInFund = true;
                                            break;
                                        }
                                    }

                                    //delete the Phase in fund from the grid ake selction of single fund at time
                                    for (var delAllPhaseInFund = 0; delAllPhaseInFund < $scope.quoteItem.phaseInAvailableFunds.length; delAllPhaseInFund++) {
                                        for (var lumpSumSelFund = 0; lumpSumSelFund < $scope.quoteItem.lumpSumProfile.Funds.length; lumpSumSelFund++) {
                                            if ($scope.quoteItem.lumpSumProfile.Funds[lumpSumSelFund].Code === $scope.quoteItem.phaseInAvailableFunds[delAllPhaseInFund].Code) {
                                                $scope.quoteItem.lumpSumProfile.Funds.splice(lumpSumSelFund, 1);
                                            }
                                        }
                                    }

                                    //Add the new fund in lumpsum grid in lumpsum profile 
                                    for (var selectedPhaseInFunds = 0; selectedPhaseInFunds < $scope.quoteItem.phaseInAvailableFunds.length; selectedPhaseInFunds++) {
                                        if ($scope.quoteItem.phaseInAvailableFunds[selectedPhaseInFunds].IsSelectedPhaseInFund) {
                                            $scope.quoteItem.lumpSumProfile.Funds.push(fundCode);
                                        }
                                    }

                                }
                            }
                        }
                    }

                    else {
                        for (var i = 0; i < $scope.quoteItem.Profiles.length; i++) {
                            if ($scope.quoteItem.Profiles[i].Type === "LumpSum") {
                                if (typeof $scope.quoteItem.Profiles[i].Funds !== "undefined" || $scope.quoteItem.Profiles[i].Funds !== null ||
                                                $scope.quoteItem.Profiles[i].Funds > 0) {

                                    for (var j = 0; j < $scope.quoteItem.Profiles[i].Funds.length; j++) {
                                        for (var k = 0; k < $scope.quoteItem.phaseInAvailableFunds.length; k++) {
                                            if ($scope.quoteItem.Profiles[i].Funds[j].Code === $scope.quoteItem.phaseInAvailableFunds[k].Code)
                                                $scope.quoteItem.Profiles[i].Funds.splice(j, 1)
                                        }
                                    }
                                }

                            }
                        }
                    }
                }
            }
        };



        $scope.validatePhaseInLumpsumAmt = function () {
            var total = 0.00;

            if (!commonUtils.isUndefinedOrEmpty($scope.quoteItem.lumpSumProfile) &&
                !commonUtils.isUndefinedOrEmpty($scope.quoteItem.lumpSumProfile.Funds) && $scope.quoteItem.lumpSumProfile.Funds.length > 0) {
                for (var i = 0; i < $scope.quoteItem.lumpSumProfile.Funds.length; i++) {
                    if ($scope.quoteItem.lumpSumProfile.Funds[i].Code === 'ABMM') {
                        total = $scope.quoteItem.lumpSumProfile.Funds[i].Amount;
                    }
                }
            }
            return total;
        }


    }]);
})();
