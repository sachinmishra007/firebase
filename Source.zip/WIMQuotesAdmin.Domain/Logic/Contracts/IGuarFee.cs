﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IGuarFee
    {

        List<Entities.GuarFees> GetGuarFees(Entities.GuarFeesType guarFeesType);
        List<Entities.GuarFees> GetPendingGuarFees();
        void StageGuarFees(Entities.GuarFees guarfees, string userId);


        void PendingGuarFeesUpdateStatus(List<Entities.GuarFees> guarfees, string userId);
        
        //

        // void GuarFeesStagingStatus(string type, DateTime startdate, float MinAmt, Entities.StagingStatus status, string userId);

        //  void SaveAuthorisedGuarFees(Entities.GuarFees guarFee);

        //void SaveGuarFeesStaging(Entities.GuarFees guarFees);














        //List<Entities.GuarFees> AuthoriseGuarFees();
        //List<Entities.GuarFees> RejectGuarFees();
        //  void AuthoriseguarFees(Entities.GuarFees guarFees);

        //void StageProductNote(Entities.Note note, string userId);
        // List<Entities.GuarFees> GetPendingGetGuarFees();
    }
}
