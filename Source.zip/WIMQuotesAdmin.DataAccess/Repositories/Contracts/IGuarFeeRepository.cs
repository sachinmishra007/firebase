﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IGuarFeeRepository
    {
        List<Entities.GuarFees> GetGuarFees(Entities.GuarFeesType guarFeesType);
        void SaveGuarFeesStaging(Entities.GuarFees guarfee);

        List<Entities.GuarFees> GetPendingGuarFees();

        void GuarFeesStagingStatus(string type, DateTime startdate, double MinAmt, Entities.StagingStatus status, string userId);

        void SaveAuthorisedGuarFees(Entities.GuarFees guarFee);

        Entities.GuarFees GetGuarFee(string type, DateTime startdate, double minAmt);
        //List<Entities.GuarFees> AuthoriseGuarFees();
        //List<Entities.GuarFees> RejectGuarFees();
        // void AuthoriseGuarFees(Entities.GuarFees guarfee);

        //void StageProductNote(Entities.Note note, string userId);
        // List<Entities.GuarFees> GetPendingGetGuarFees();
    }
}
