﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('fundTICService', ['$http', function ($http)
        {
            var fundTICService = {};

            fundTICService.uploadFileToUrl = function (file, uploadUrl)
            {
                debugger;
                var fileName = file.name;
                
                 fileName = fileName.replace('.xlsx', '');
                return $http.post('api/FundTIC/SaveToStaging/' + fileName);
            };

            fundTICService.getPendingFundTICs = function () {
                return $http({ url: 'api/FundTIC/Pending' });
            };

            fundTICService.updatePendingStatuses = function () {
                return $http.post('api/FundTIC/UpdatePendingStatuses');
            };

            fundTICService.updateRejectStatuses = function () {
                debugger;
                return $http.post('api/FundTIC/UpdateRejectStatuses');
            };

            return fundTICService;
        }]);
})();
