﻿namespace WIMQuotesAdmin.Entities
{
    public enum InstructionType
    {
        Update,
        Add,
        Delete
    }
}
