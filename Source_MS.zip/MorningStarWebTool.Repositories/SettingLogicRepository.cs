﻿using MorningStarWebTool.Repositories.Contract;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorningStarWebTool.Repositories
{
    public class SettingLogicRepository : ISettingLogicRepository
    {
        public T GetApplicationSetting<T>(string _appSettingKey)
        {
            var value = ConfigurationManager.AppSettings[_appSettingKey];
            return (T)TypeDescriptor.GetConverter(typeof(T)).ConvertFromInvariantString(value);
        }
    }
}
