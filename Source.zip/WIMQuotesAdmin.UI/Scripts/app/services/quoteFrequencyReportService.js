﻿
(function ()
{
    'use strict';

    angular.module('adminApp.services')
        .factory('quoteFrequencyReportService', ['$http', function ($http)
        {
            var quoteFrequencyReportService = {};
            
            quoteFrequencyReportService.getQuoteReports = function (dtoReportDetails)
            {
                return $http({ method: 'GET', url: 'api/QuoteFrequencyReport/Get', params: dtoReportDetails });
            };

            quoteFrequencyReportService.searchBrokers = function (searchTerm)
            {
                return $http({url: 'api/QuoteFrequencyReport/SearchBrokers/' + searchTerm});
            };

            quoteFrequencyReportService.searchBrokerHouse = function (searchTerm)
            {
                return $http({ url: 'api/QuoteFrequencyReport/SearchBrokerHouse/' + searchTerm });
            };

            return quoteFrequencyReportService;
        }]);
})();

    