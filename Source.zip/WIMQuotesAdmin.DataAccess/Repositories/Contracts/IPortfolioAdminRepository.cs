﻿using System.Collections.Generic;

using WIMQuotesAdmin.Entities;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IPortfolioAdminRepository
    {
        List<Entities.FundMapping> GetFundMappings();

        void SaveFundMapping(Entities.FundMapping fundMapping);
        List<Entities.Fund> GetAssetClassesAvailableFunds();
        void StagingFundMapping(Entities.FundMapping mapping);
        List<Entities.FundMapping> GetPendingFundMappings(); 
        Entities.FundMapping GetPendingFundMapping(string code);

        void PendingFundMappingUpdateStatus(string code, Entities.StagingStatus status, string userId);
        void SaveAuthorisedFundMapping(Entities.FundMapping mapping);
        List<Entities.Fund> GetUnmappedFunds();
        void DeleteFundMapping(string fundCode);
        void UpdateMSRetriveFundMapping(Entities.FundMapping fundMapping);
    }
}
