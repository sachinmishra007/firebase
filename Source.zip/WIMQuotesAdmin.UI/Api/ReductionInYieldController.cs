﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class ReductionInYieldController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IReductionInYieldLogic _reductionInYieldLogic;

        public ReductionInYieldController(Domain.Logic.Contracts.IReductionInYieldLogic reductionInYieldLogic)
        {
            _reductionInYieldLogic = reductionInYieldLogic;
        }

        #endregion

        // GET api/ReductionInYield/GetReductionInYields
        [Route("api/ReductionInYield/GetReductionInYields")]
        public List<Entities.ReductionInYield> GetReductionInYields()
        {
            return _reductionInYieldLogic.Get();
        }

        // POST api/ReductionInYield
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void Post([FromBody]Entities.ReductionInYield limit, [ModelBinder]IPrincipal user)
        {
            if (limit == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _reductionInYieldLogic.StageLimit(limit, user.Identity.Name);
        }

        // GET api/Regulation28Limits/Pending
        [Route("api/ReductionInYield/Pending")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public List<Entities.ReductionInYield> GetPendingRegulation28Limits()
        {
            return _reductionInYieldLogic.GetPendingYields();
        }

        // POST api/Regulation28Limits/UpdatePendingStatuses
        [HttpPost]
        [Route("api/ReductionInYield/UpdatePendingStatuses")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingLimitsUpdateStatus([FromBody]List<Entities.ReductionInYield> limits, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (limits == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _reductionInYieldLogic.PendingLimitUpdateStatus(limits, user.Identity.Name);
        }
    }
}
