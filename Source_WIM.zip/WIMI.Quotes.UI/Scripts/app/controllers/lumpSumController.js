﻿
(function () {
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('lumpSumController', ['$scope', '$rootScope', 'lookupService', 'clientService', 'commonUtils',
            function ($scope, $rootScope, lookupService, clientService, commonUtils) {
                $scope.profile = {};
                $scope.currencies = lookupService.getCurrencies();
                $scope.clientContributions = {};

                $scope.selectedCurrency = {};
                $scope.totalAmount = 0.00;
                $scope.totalPercentage = 0.00;


                // Private Members

                var disabledPhaseIn = function () {
                    for (var i = 0; i < $scope.quoteItem.Profiles.length; i++) {
                        if ($scope.quoteItem.Profiles[i].Type === 'PhaseIn') {
                            $scope.quoteItem.Profiles[i].IsDisabled = true;
                            $scope.quoteItem.Profiles[i].$disableMessage = "Existing Phase In on portfolio/policy. An additional Phase In is not allowed";
                            deletePhaseInFund();

                            //hide Income and DebitOrder section
                            if ($scope.quoteItem.Profiles[i].IsActive)
                                $scope.quoteItem.Profiles[i].IsActive = false;
                        }
                    }
                };

                var deletePhaseInFund = function () {
                    for (var i = 0; i < $scope.quoteItem.Profiles.length; i++) {
                        if ($scope.quoteItem.Profiles[i].Type === "LumpSum") {
                            if (typeof $scope.quoteItem.Profiles[i].Funds !== "undefined" || $scope.quoteItem.Profiles[i].Funds !== null ||
                                            $scope.quoteItem.Profiles[i].Funds > 0) {

                                for (var j = 0; j < $scope.quoteItem.Profiles[i].Funds.length; j++) {
                                    if ($scope.quoteItem.Profiles[i].Funds[j].Code === 'ABMM')
                                        $scope.quoteItem.Profiles[i].Funds.splice(j, 1)

                                }
                            }

                        }
                    }
                };

                var calculateTotalAmount = function () {
                    $scope.totalAmount = commonUtils.sumArray($scope.quoteItem.clientPolicyFundList || [], 'Amount');
                };

                var calculateTotalPercentage = function () {
                    $scope.totalPercentage = commonUtils.sumArray($scope.quoteItem.clientPolicyFundList || [], 'Percentage');
                };


                // Behaviours 

                $scope.init = function (profile) {

                    $scope.profile = profile;
                    $scope.profile.ShowUseLumpSumFunds = false;

                    $scope.profile.ShowExistingLumpSumFunds = true;

                    if (typeof $scope.profile.Funds === "undefined")
                        $scope.profile.Funds = [];

                    $scope.selectedCurrency = $scope.quoteItem.Currency;
                    $scope.quoteItem.lumpSumProfile = $scope.profile;

                    clientService.getClientContribution($scope.application.selectedClient.ClientNumber, $scope.quoteItem.Product.Code).success(function (response) {
                        $scope.clientContributions = response;
                        $scope.remainingContributionTotal = $scope.clientContributions.RemainingNettTaxYear - $scope.profile.Amount;
                    });

                    clientService.getClientPolicies($scope.application.selectedClient.ClientNumber, $scope.quoteItem.Product.Code).success(function (response) {
                        $scope.clientPolicyList = response;

                        for (var i = 0; i < $scope.clientPolicyList.length; i++) {
                            if ($scope.clientPolicyList[i].PolicyNumber === $scope.profile.PolicyNumber) {
                                $scope.selectedPolicy = $scope.clientPolicyList[i];
                            }
                        }
                    });

                    calculateTotalAmount();
                    calculateTotalPercentage();
                };

                $scope.getClientPolicyFund = function (clientNumber, policy) {
                    $scope.profile.PolicyNumber = policy.PolicyNumber;
                    $scope.profile.BDANumber = policy.BDANumber;
                    $scope.profile.PolicyMarketValue = policy.LatestMarketValue;

                    clientService.getClientPolicyFund(clientNumber, policy.PolicyNumber).success(function (response) {
                        $scope.quoteItem.clientPolicyFundList = response || [];
                        $scope.quoteItem.additionProfile.Funds = $scope.quoteItem.clientPolicyFundList || [];

                        calculateTotalAmount();
                        calculateTotalPercentage();
                    });

                    for (var i = 0; i < $scope.quoteItem.Profiles.length; i++) {
                        if ($scope.quoteItem.Profiles[i].Type === 'Addition') {
                            clientService.getClientPolicyPhaseInDetails(clientNumber, policy.PolicyNumber).success(function (response) {
                                if (!commonUtils.isUndefinedOrEmpty(response) && response.length > 0) {
                                    $scope.quoteItem.clientPolicyPhaseIn = response;
                                    disabledPhaseIn();
                                }
                            });
                        }
                    }
                    $rootScope.$broadcast('lumpSum.GetClientPolicyFund', policy);
                };

                $scope.setCurrency = function (currency) {
                    $scope.selectedCurrency = currency;
                    $scope.quoteItem.Currency = $scope.selectedCurrency;
                };

                $scope.amountChanged = function () {
                    $scope.quoteItem.lumpSumProfile.Amount = $scope.profile.Amount;
                    $scope.remainingContributionTotal = $scope.clientContributions.RemainingNettTaxYear - $scope.profile.Amount;

                    $scope.$broadcast('profile.AmountChanged', null);
                    $rootScope.$broadcast('lumpSum.AmountChanged', null);
                };


                
            }]);
})();
