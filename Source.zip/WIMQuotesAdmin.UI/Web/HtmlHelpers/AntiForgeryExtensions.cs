﻿using System;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace WIMQuotesAdmin.UI.Web.HtmlHelpers
{
    public static class AntiForgeryExtensions
    {
        /// <summary>
        /// Creates hidden field with an Anti Forgery Token to embed into Request Headers i.e. 
        /// for an Ajax Api Request.
        /// </summary>
        public static MvcHtmlString AntiForgeryHeaderTokenField(this HtmlHelper html)
        {
            return html.Hidden("__RequestVerificationToken", AntiForgeryHeaderToken(html));
        }

        /// <summary>
        /// Generates Anti Forgery Token to embed into Request Headers i.e. for an Ajax Api Request.
        /// </summary>
        public static string AntiForgeryHeaderToken(this HtmlHelper html)
        {
            string cookieToken, formToken;
            AntiForgery.GetTokens(null, out cookieToken, out formToken);

            return String.Format("{0}:{1}", cookieToken, formToken);
        }
    }
}