﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IFundSecurityFeesLogic
    {
    //    void StageFundSecuiryFees(string fileName, string userID);
        void StageFundSecuiryFees(Entities.FundSecurityFeesFile  fundSecurityFeesFile, string userID);

        
        List<Entities.FundSecurityFees> GetPendingFundSecurityFees();

        void SaveFundSecurityFees(string userID);

        void RejectFundSecurityFees(string userID);  
    }
}
