﻿using WIMQuotesAdmin.Common.Extensions;

namespace WIMQuotesAdmin.DataAccess.Repositories.Mappings
{
    public static class WIMQuotesAdminMapping
    {
        public static Entities.MenuItem ToMenuItem(DataModel.UserAccessMenuItem menuItem)
        {
            return new Entities.MenuItem
            {
                Id = menuItem.Id,
                Name = menuItem.Name,
                AccessLevel = menuItem.AccessLevelId.HasValue ? menuItem.AccessLevelId.Value.ToEnum<Entities.AccessLevel>() : 
                    (Entities.AccessLevel?)null,
                ActionUrl = menuItem.ActionUrl,
                ViewFileUrl = menuItem.ViewFileName
            };
        }

        public static Entities.User ToUser(DataModel.SystemUser user)
        {
            return new Entities.User
            {
                Id = user.UserId,
                Name = user.UserName,
                Role = user.RoleId.HasValue ? user.RoleId.Value.ToEnum<Entities.UserRole>() : (Entities.UserRole?)null
            };
        }
    }
}
