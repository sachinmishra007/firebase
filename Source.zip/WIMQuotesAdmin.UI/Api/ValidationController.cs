﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    public class ValidationController : ApiController
    {
        private readonly WIMQuotesAdmin.Domain.Logic.Contracts.IValidationLogic _validationLogic;

        public ValidationController(WIMQuotesAdmin.Domain.Logic.Contracts.IValidationLogic validationLogic)
        {
            _validationLogic = validationLogic;
        }

        public List<Entities.Validation> Get()
        {
            return _validationLogic.GetUIValidations();
        }

        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void Post([FromBody]Entities.Validation validation, [ModelBinder]IPrincipal user)
        {
            if (validation == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;
            _validationLogic.SaveValidationToStaging(validation, user.Identity.Name);
        }

        [Route("api/Validation/Pending")]
        public List<Entities.Validation> GetPendingValidation()
        {
            return _validationLogic.GetPendingValidation();
        }

        [HttpPost]
        [Route("api/Validation/UpdatePendingStatuses")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingValidationUpdateStatus([FromBody]List<Entities.Validation> validations, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (validations == null || validations.Count == 0 || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;
            _validationLogic.PendingValidationUpdateStatus(validations, user.Identity.Name);
        }
    }
}