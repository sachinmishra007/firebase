﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('userAccessControlController', ['$scope', '$timeout', 'userAccessReportService', 'lookupService',
            function ($scope, $timeout, userAccessReportService, lookupService)
        {
            $scope.accessReportList = [];
            $scope.userRolesList = [];
            $scope.selectedReport = undefined;
            $scope.reportSelect = lookupService.getRolesReports();

            var roleCounts = [];

            var minDateOffSet = 1000 * 60 * 60 * 24 * 365 * 5; // Offset by 5 Years;
            $scope.maxDate = new Date();
            $scope.minDate = new Date();
            $scope.minDate.setTime($scope.maxDate.getTime() - minDateOffSet);

            var startDateOffset = 1000 * 60 * 60 * 24 * 31; // Offset by 31 Days;
            var startDate = new Date();
            startDate.setTime(startDate.getTime() - startDateOffset);

            $scope.labels = ['Super User', 'Admin User', 'Read Only User'];
            $scope.series = ['Series A'];
            
            $scope.reportSearchDetails = {
                StartDate: startDate,
                EndDate: new Date()
            }

            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];


            // Behaviours

            $scope.getAdminActivityReports = function ()
            {
                $scope.application.showLoading = true;

                userAccessReportService.getUserAccessControlReportData($scope.reportSearchDetails).success(function (response)
                {
                    $scope.accessReportList = response;
                    $scope.currentPage = 0;
                    $scope.application.showLoading = false;
                });
            };

            $scope.getUserRolesReports = function ()
            {
                $scope.application.showLoading = true;

                userAccessReportService.getUserRolesReportData($scope.reportSearchDetails).success(function (response)
                {
                    $scope.userRolesList = response;
                    $scope.currentPage = 0;
                    $scope.application.showLoading = false;
                });
            };

            $scope.downloadUserRolesOutput = function ()
            {
                debugger;
                $scope.downloadUrl = "Report/UserRolesReportOutput?rnd=" + new Date().getTime();
            };

            $scope.downloadSuperUserAuditOutput = function ()
            {
                $scope.downloadUrl = "Report/UserAccessControlReportOutput?startDate=" + $scope.reportSearchDetails.StartDate.toDateString() + "&endDate=" + $scope.reportSearchDetails.EndDate.toDateString() + "&rnd=" + new Date().getTime();
            };


            // On Load

            userAccessReportService.getUserRoleCount().success(function (response)
            {
                roleCounts = response;
                $scope.data = [[roleCounts[0], roleCounts[1], roleCounts[2]]];
            });


            // Pagination

            $scope.firstPage = function ()
            {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function ()
            {
                if ($scope.currentPage > 0)
                {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function ()
            {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function ()
            {
                var list = ($scope.selectedReport || {}).Code === 'ROLES' ? $scope.userRolesList : $scope.accessReportList;
                return Math.ceil((list || []).length / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function ()
            {
                if ($scope.currentPage < $scope.pageCount())
                {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function ()
            {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function ()
            {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n)
            {
                $scope.currentPage = n;
            };

            $scope.range = function ()
            {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0)
                {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize)
                {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++)
                {
                    range.push(i);
                }

                return range;
            };

        }]);
})();
