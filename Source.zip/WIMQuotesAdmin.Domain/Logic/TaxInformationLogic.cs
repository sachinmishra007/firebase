﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.Entities;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class TaxInformationLogic : Contracts.ITaxInformationLogic
    {
        private readonly DataAccess.Repositories.Contracts.ITaxInformationRepository _taxInformationRepository;

        public TaxInformationLogic(DataAccess.Repositories.TaxInformationRepository taxInformationRepository)
        {
            _taxInformationRepository = taxInformationRepository;
        }

        public void UpdatePendingStatus(List<Entities.TaxTables>taxTables,string userId)
        {

            foreach (var tax in taxTables)
            {
                switch (tax.Status)
                {
                    case StagingStatus.Authorise:
                        PendingTaxAuthorise(tax, userId);
                        break;
                    case StagingStatus.Reject:
                        PendingTaxReject(tax, userId);
                        break;
                }

            }
        }

        public List<Entities.TaxInformation> GetTaxInformation()
        {
          return _taxInformationRepository.GetTaxInformation();
            
        }

        public TaxRebates GetTaxRebates()
        {
            return _taxInformationRepository.GetTaxRebates();
        }

        public List<TaxTables> GetTaxTables()
        {
            var taxTables = _taxInformationRepository.GetTaxTables();
            var pedingTaxes = _taxInformationRepository.GetPendingTaxTables();
            if(pedingTaxes == null || pedingTaxes.Count == 0)
            return taxTables;

            foreach (var pTax in pedingTaxes)
            {
                var tax = taxTables.FirstOrDefault(v => v.Id == pTax.Id);
                if (tax == null)
                    continue;

                tax.Status = pTax.Status;
                tax.UserId = pTax.UserId;
                //valid = pTax.RevisionDate;
            }

            return taxTables;
            
        }

        public List<Entities.TaxTables> RejectTaxTables()
        {
           return _taxInformationRepository.RejectTaxBrackets();
        }

        public void SaveTaxBracketsStaging(Entities.TaxTables taxTables,string userId)
        {
            _taxInformationRepository.SaveTaxBracketsStaging(taxTables,userId);
        }

        public void SaveTaxRebatesStaging(Entities.TaxRebates rebates, string userId)
        {
            _taxInformationRepository.SaveTaxRebatesStaging(rebates, userId);
        }

        public void AuthoriseTaxRebates(TaxRebates rebates, string userId)
        {
            _taxInformationRepository.AuthoriseRebatesStaging(rebates, userId);
        }

        public void RejectRebates()
        {
            _taxInformationRepository.RejectRebatesStaging();
        }


        public List<TaxTables> GetPendingTaxTables()
        {
            return _taxInformationRepository.GetPendingTaxTables();
        }

        #region Private Methods

        private void PendingTaxAuthorise(Entities.TaxTables taxtable, string userId)
        {
            if (taxtable == null || string.IsNullOrWhiteSpace(userId))
                return;

            var tax = _taxInformationRepository.GetPendingTaxTableById(taxtable.Id);
            if (tax == null)
                return;

            _taxInformationRepository.AuthoriseTaxBrackets(tax);
            _taxInformationRepository.UpdateTaxTablesStagingStatus(taxtable, Entities.StagingStatus.Authorise, userId);

        }

        private void PendingTaxReject(Entities.TaxTables taxtable, string userId)
        {
            if (taxtable == null || string.IsNullOrWhiteSpace(userId))
                return;
            _taxInformationRepository.UpdateTaxTablesStagingStatus(taxtable, Entities.StagingStatus.Reject, userId);

        }
        #endregion
    }
}
