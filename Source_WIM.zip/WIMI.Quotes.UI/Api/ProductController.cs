﻿using System.Collections.Generic;
using System.Web.Http;

using WIMI.Quotes.Common;
using WIMI.Quotes.UI.Web.ActionFilters;

namespace WIMI.Quotes.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class ProductController : ApiController
    {
        #region Contructors & DI

        private readonly Model.Domain.Contracts.IProductsLogic _productsLogic;

        public ProductController(Model.Domain.Contracts.IProductsLogic productsLogic)
        {
            _productsLogic = productsLogic;
        }

        #endregion

        // GET: api/Product
        [AuthorizeApiMustBeUser(Constants.Roles.Advisor, "brokerCode")]
        public IEnumerable<Entities.Product> Get(string brokerCode, string clientType, string clientSubType)
        {
            return _productsLogic.GetProductsList(brokerCode, clientType, clientSubType);
        }
    }
}
