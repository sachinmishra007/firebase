﻿using System;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMQuotesAdmin.Entities
{
    public class FundTER
    {
        public string FundCode { get; set; }
        public string FundName { get; set; }
        public double TotalExpenseRatio { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public StagingStatus Status { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public InstructionType InstructionType { get; set; }
        
        public string UserId { get; set; }
        public DateTime ModifiedDateTime { get; set; }
    }
}
