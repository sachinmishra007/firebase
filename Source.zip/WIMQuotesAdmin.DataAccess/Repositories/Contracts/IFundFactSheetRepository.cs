﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IFundFactSheetRepository
    {
        List<Entities.FundFactSheet> GetFundFactSheets(Entities.FundType fundType, string fundCode);
        List<Entities.FundFactSheet> GetPendingFundFactSheets();
        Entities.FundFactSheet GetPendingFundFactSheet(string fundCode);
        List<Entities.Fund> GetUnmappedFunds();
        List<Entities.Fund> GetUnmappedFundsByType(Entities.FundType fundType);

        void SaveFundFactSheetToStaging(Entities.FundFactSheet fundFactSheet);
        void SaveAuthorisedFundFactSheet(Entities.FundFactSheet fundFactSheet);
        void DeleteAuthorisedFundFactSheet(string fundCode);
        void UpdateFundFactSheetStagingStatus(string fundCode, Entities.StagingStatus status, string userId);

        Entities.File GetFundFactSheetFile(string fundCode);
    }
}