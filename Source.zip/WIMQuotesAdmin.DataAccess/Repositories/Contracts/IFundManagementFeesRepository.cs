﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IFundManagementFeesRepository
    {
        List<Entities.FundManagementFees> GetFundManagementFees(Entities.FundType fundType, string fundCode);
        void SaveFundManagementFeesToStaging(Entities.FundManagementFees fundManagementFees);
        List<Entities.Fund> GetUnmappedFunds();
        Entities.FundManagementFees GetPendingFundManagementFees(string fundCode);
        List<Entities.FundManagementFees> GetPendingFundManagementFees();

        void SaveAuthorisedFundManagementFees(Entities.FundManagementFees fundManagementFees);
        //Reject
        void UpdateFundManagementFeesStagingStatus(string fundCode, Entities.StagingStatus status, string userId);
        void DeleteAuthorisedFundManagementFees(string fundCode);
    }
}
