﻿(function ()
{
    'use strict';

    angular.module('common.directives')
        .directive('ngDropdownsDatepicker', ['$parse', function ($parse)
        {
            var isLeapYear = function (year)
            {
                return ((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0);
            };

            return {
                template: '<div>' +
                        '<select ng-chosen="{ width: \'100px\' }" class="datepicker-year"></select>' +
                        '<select ng-chosen="{ width: \'140px\' }" class="datepicker-month"></select>' +
                        '<select ng-chosen="{ width: \'80px\' }" class="datepicker-day"></select></div>',
                restrict: 'A',
                require: 'ngModel',
                replace: true,
                link: function (scope, element, attrs, ngModelCtrl)
                {
                    var now = new Date();
                    var offsetMs = now.getTime() - 1000 * 60 * 60 * 24 * 365 * 100; // Offset by 100 Years;
                    now.setTime(offsetMs);

                    var settings = {
                        months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                        days: [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
                        maxDate: new Date(),
                        minDate: now,
                        descendingYears: true
                    };

                    var options = $parse(attrs.ngDropdownsDatepicker)(scope) || {};
                    $.extend(settings, options);

                    settings.maxDate.setHours(0, 0, 0, 0);
                    settings.minDate.setHours(0, 0, 0, 0);
                    
                    var yearsDropDown = element.find('select.datepicker-year');
                    var monthsDropDown = element.find('select.datepicker-month') ;
                    var daysDropDown = element.find('select.datepicker-day');


                    // Private Methods

                    var yearOptionsHtml = function ()
                    {
                        var yearDropDowns = "";
                        var startYear = settings.descendingYears ? settings.maxDate.getFullYear() : settings.minDate.getFullYear();
                        var endYear = settings.descendingYears ? settings.minDate.getFullYear() : settings.maxDate.getFullYear();

                        for (var i = startYear; (settings.descendingYears ? i >= endYear : i <= endYear); (settings.descendingYears ? i-- : i++))
                        {
                            yearDropDowns += '<option value="' + i + '">' + i + '</option>';
                        }

                        return yearDropDowns;
                    };

                    var monthsOptionsHtml = function ()
                    {
                        var monthDropDowns = "";

                        for (var i = 0; i < settings.months.length; i++)
                        {
                            monthDropDowns += '<option value="' + (i + 1) + '">' + settings.months[i] + '</option>';
                        }

                        return monthDropDowns;
                    };

                    var getSelectedDate = function ()
                    {
                        var month = (monthsDropDown.val() < 10 ? '0' : '') + monthsDropDown.val();
                        var day = (daysDropDown.val() < 10 ? '0' : '') + daysDropDown.val();
                        var dateString = yearsDropDown.val() + '-' + month + '-' + day + 'T00:00:00.000Z';

                        return new Date(dateString);
                    };

                    var daysOptionsHtml = function ()
                    {
                        var dayDropDowns = "";

                        for (var i = 1; i <= 31; i++)
                        {
                            dayDropDowns += '<option value="' + i + '">' + i + '</option>';
                        }

                        return dayDropDowns;
                    };

                    var setDropDownYear = function ()
                    {
                        var selectedYear = yearsDropDown.val();
                        var minYear = settings.minDate.getFullYear();

                        yearsDropDown.find('option').filter(function ()
                        {
                            return $(this).attr("value") < minYear;
                        }).prop('disabled', true);

                        if (selectedYear < minYear)
                        {
                            yearsDropDown.val(minYear);
                        }

                        yearsDropDown.trigger('chosen:updated');
                    };

                    var setDropDownMonth = function ()
                    {
                        monthsDropDown.find('option').prop('disabled', false);

                        var selectedDate = getSelectedDate();
                        var selectedMonth = monthsDropDown.val();

                        var maxMonth = 12;
                        var minMonth = 1;

                        if (selectedDate.getFullYear() === settings.minDate.getFullYear())
                        {
                            minMonth = settings.minDate.getMonth() + 1;
                        }

                        if (selectedDate.getFullYear() === settings.maxDate.getFullYear())
                        {
                            maxMonth = settings.maxDate.getMonth() + 1;
                        }

                        monthsDropDown.find('option').filter(function ()
                        {
                            return $(this).attr("value") < minMonth || $(this).attr("value") > maxMonth;
                        }).prop('disabled', true);

                        if (selectedDate.getFullYear() === settings.minDate.getFullYear() &&
                            selectedMonth < minMonth)
                        {
                            monthsDropDown.val(minMonth);
                        }

                        if (selectedDate.getFullYear() === settings.maxDate.getFullYear() &&
                            selectedMonth > maxMonth)
                        {
                            monthsDropDown.val(maxMonth);
                        }

                        monthsDropDown.trigger('chosen:updated');
                    };

                    var setDropdownDays = function ()
                    {
                        daysDropDown.find('option').prop('disabled', false);

                        var maxDay;
                        var minDay = 1;

                        var selectedDate = getSelectedDate();
                        var selectedDay = daysDropDown.val();
                        
                        if (selectedDate.getMonth() === settings.minDate.getMonth() &&
                            selectedDate.getFullYear() === settings.minDate.getFullYear())
                        {
                            minDay = settings.minDate.getDate();
                        }

                        if (monthsDropDown.val() === '2')
                        {
                            maxDay = isLeapYear(yearsDropDown.val()) ? 29 : 28;
                        }
                        else
                        {
                            maxDay = settings.days[monthsDropDown.val() - 1];
                        }

                        if (selectedDate.getMonth() === settings.maxDate.getMonth() &&
                            selectedDate.getFullYear() === settings.maxDate.getFullYear() &&
                            maxDay > settings.maxDate.getDate())
                        {
                            maxDay = settings.maxDate.getDate();
                        }

                        daysDropDown.find('option').filter(function ()
                        {
                            return $(this).attr("value") < minDay || $(this).attr("value") > maxDay;
                        }).prop('disabled', true);

                        if (selectedDay < minDay)
                        {
                            daysDropDown.val(minDay);
                        }

                        if (selectedDay > maxDay)
                        {
                            daysDropDown.val(maxDay);
                        }

                        daysDropDown.trigger('chosen:updated');
                    };


                    // On Load

                    yearsDropDown.append(yearOptionsHtml());
                    monthsDropDown.append(monthsOptionsHtml());
                    daysDropDown.append(daysOptionsHtml());

                    setDropDownYear();
                    setDropdownDays();
                    setDropDownMonth();


                    // Events / Hook Ins

                    ngModelCtrl.$render = function ()
                    {
                        if (typeof ngModelCtrl.$viewValue === "undefined" || ngModelCtrl.$viewValue === null)
                            return;

                        var date = new Date(ngModelCtrl.$viewValue);
                        yearsDropDown.val(date.getFullYear()).trigger('chosen:updated');
                        monthsDropDown.val(date.getMonth() + 1).trigger('chosen:updated');

                        setDropDownMonth();
                        setDropdownDays();

                        daysDropDown.val(date.getDate()).trigger('chosen:updated');
                    }

                    element.find('select').bind('change', function ()
                    {
                        setDropDownMonth();
                        setDropdownDays();

                        ngModelCtrl.$setViewValue(getSelectedDate());
                    });
                }
            };
        }]);

})();