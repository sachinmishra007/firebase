﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('fundZeroFeeController', ['$scope', '$timeout', 'fundZeroFeeService', 'lookupService',
            function ($scope, $timeout, fundZeroFeeService, lookupService)
            {

                $scope.fundZeroFeesList = [];
                $scope.pendingFundZeroFeeList = [];
                $scope.fundWrapTypeList = [];
                $scope.addNewFunde = {};

                $scope.filterFundCode = '';
                $scope.currentPage = 0;
                $scope.itemsPerPage = 10;
                $scope.range = [];
                $scope.header = "Maintain Fund Zero Fee";
                $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' ||
                $scope.application.currentMenuItem.AccessLevel === 'AdminRights';

                $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
                $scope.isViewVisible = false;
                $scope.$addMode = false;
                $scope.$hideMode = false;
                $scope.fundType = lookupService.getFundType();



                // Private Methods


                var FundCount = function ()
                {
                    var count = 0;

                    for (var i = 0; i < $scope.fundZeroFeesList.length; i++)
                    {
                        if ($scope.filterFundZeroFeeCode($scope.fundZeroFeesList[i]))
                            count++;

                    }

                    return count;
                };

                var getFundZeroFeeList = function ()
                {
                    $scope.application.showLoading = true;

                    fundZeroFeeService.getFundZeroFee().success(function (response)
                    {
                        $scope.fundZeroFeesList = response;
                        $scope.application.showLoading = false;
                    });
                };



                var showMessage = function (message)
                {
                    $scope.notificationMessage = message;
                    $scope.showSuccessMessage = true;

                    $timeout(function ()
                    {
                        $scope.showSuccessMessage = false;
                    }, 5000);
                }

                var clearAddFund = function ()
                {
                    $scope.selectedFundType = undefined,
                    $scope.selectedFund = undefined,
                    $scope.isAimsInitialFee = undefined,
                    $scope.isAimsOngoingFee = undefined,
                    $scope.isAimsRecurringFee = undefined,
                    $scope.isEACAdminFee = undefined

                };

                var removePendingFundZeroFee = function (fundId)
                {
                    for (var i = 0; i < $scope.pendingFundZeroFeeList.length; i++)
                    {
                        if ($scope.pendingFundZeroFeeList[i].FundId === fundId)
                            $scope.pendingFundZeroFeeList.splice(i, 1);
                    }
                }


                //// On Load

                getFundZeroFeeList();


                if ($scope.isPendingVisible)
                {
                    $scope.application.showLoading = true;
                    fundZeroFeeService.getPendingFundZeroFee().success(function (response)
                    {
                        $scope.pendingFundZeroFeeList = response;
                        $scope.isViewVisible = response.length === 0;
                        $scope.application.showLoading = false;
                    });
                }
                else
                {
                    $scope.isViewVisible = true;
                    $scope.application.showLoading = false;
                }



                //// Behaviours
                $scope.filterFundZeroFeeCode = function (item)
                {
                    return (item.FundId.toLowerCase().indexOf($scope.filterFundCode.toLowerCase()) !== -1);
                };


                $scope.editFundZeroFee = function (fundZeroFee)
                {
                    fundZeroFee.RevisedInitialFee = fundZeroFee.AIMSInitialFee;
                    fundZeroFee.RevisedAIMSOngoingFee = fundZeroFee.AIMSOngoingFee;
                    fundZeroFee.RevisedAIMSRecurringFee = fundZeroFee.AIMSRecurringFee;
                    fundZeroFee.InstructionType = 'Update';
                    fundZeroFee.$editMode = true;
                };

                $scope.cancelFundZeroFee = function (fundZeroFee)
                {
                    fundZeroFee.AIMSInitialFee = fundZeroFee.RevisedInitialFee;
                    fundZeroFee.AIMSOngoingFee = fundZeroFee.RevisedAIMSOngoingFee;
                    fundZeroFee.AIMSRecurringFee = fundZeroFee.RevisedAIMSRecurringFee;
                    fundZeroFee.$editMode = false;
                };

                $scope.saveFundZeroFee = function (fundZeroFee)
                {
                    fundZeroFeeService.saveFundZeroFee(fundZeroFee).success(function ()
                    {
                        fundZeroFee.Status = 'PendingAuthorise';
                        fundZeroFee.$editMode = false;

                        showMessage('Fund Zero Fee saved successfully. Pending authorisation.');
                    });
                };

                $scope.deleteFundZeroFee = function (fundZeroFee)
                {
                    fundZeroFee.InstructionType = 'Delete';

                    fundZeroFeeService.saveFundZeroFee(fundZeroFee).success(function ()
                    {
                        fundZeroFee.Status = 'PendingAuthorise';
                        fundZeroFee.$editMode = false;

                        showMessage('Fund Zero Fees set for deletion. Pending authorisation.');
                    });
                };

                $scope.setPendingFundZeroFeeStatus = function (fundZeroFee, status)
                {
                    fundZeroFee.Status = fundZeroFee.Status !== status ? status : "PendingAuthorise";
                };

                $scope.anyPendingFundZeroFeeSelected = function ()
                {
                    for (var i = 0; i < $scope.pendingFundZeroFeeList.length; i++)
                    {
                        if ($scope.pendingFundZeroFeeList[i].Status !== "PendingAuthorise")
                            return true;
                    }

                    return false;
                };

                $scope.updatePendingStatuses = function ()
                {
                    $scope.application.showLoading = true;

                    var pendingFunds = [];

                    for (var i = 0; i < $scope.pendingFundZeroFeeList.length; i++)
                    {
                        if ($scope.pendingFundZeroFeeList[i].Status !== "PendingAuthorise")
                            pendingFunds.push($scope.pendingFundZeroFeeList[i]);
                    }

                    fundZeroFeeService.updatePendingStatuses(pendingFunds).success(function ()
                    {
                        for (var i = 0; i < pendingFunds.length; i++)
                        {
                            removePendingFundZeroFee(pendingFunds[i].FundId);
                        }

                        showMessage("Selected fund zero fees updated successfully");

                        if ($scope.pendingFundZeroFeeList.length === 0)
                        {
                            $scope.isViewVisible = true;
                            $scope.fundZeroFeesList = [];
                            getFundZeroFeeList();
                        }

                        $scope.application.showLoading = false;
                    });
                };

                $scope.saveNewFund = function (selectedFund, isAimsInitialFee, isAimsOngoingFee, isAimsRecurringFee, isEACAdminFee)
                {

                    debugger;
                    if (selectedFund !== undefined || selectedFund !== null || selectedFund !== "")
                    {
                        $scope.application.showLoading = true;
                        var addNewFunde =
                      {
                          FundId: selectedFund.Code,
                          AIMSInitialFee: isAimsInitialFee,
                          AIMSOngoingFee: isAimsOngoingFee,
                          AIMSRecurringFee: isAimsRecurringFee,
                          EACAdminFee: isEACAdminFee,
                          FAInitialFee: false,
                          FAOngoingFee: false,
                          FARecurringFee: false
                      }

                        fundZeroFeeService.addNewFund(addNewFunde).success(function ()
                        {

                            showMessage("Selected fund added successfully");
                            clearAddFund();
                            $scope.application.showLoading = false;

                        });
                    }
                };

                $scope.openFunds = function ()
                {
                    $scope.header = "Add Fund Zero Fee";
                    $scope.$addMode = true;
                };

                $scope.cancelFunds = function ()
                {
                    $scope.header = "Maintain Fund Zero Fee";
                    clearAddFund();
                    $scope.$addMode = false;
                    getFundZeroFeeList();
                }

                $scope.getFundWrapFundList = function (fundType)
                {
                    if (typeof fundType == "undefined" || fundType == null || fundType == "")
                        return;
                    $scope.application.showLoading = true;

                    fundZeroFeeService.getFundWrapTypeList(fundType).success(function (response)
                    {
                        $scope.fundWrapTypeList = response;
                        $scope.application.showLoading = false;
                    });
                };

                // Pagination
                $scope.firstPage = function ()
                {
                    $scope.currentPage = 0;
                };

                $scope.prevPage = function ()
                {
                    if ($scope.currentPage > 0)
                    {
                        $scope.currentPage--;
                    }
                };

                $scope.prevPageDisabled = function ()
                {
                    return $scope.currentPage === 0 ? "disabled" : "";
                };

                $scope.pageCount = function ()
                {
                    return Math.ceil(FundCount() / $scope.itemsPerPage) - 1;
                };

                $scope.nextPage = function ()
                {
                    if ($scope.currentPage < $scope.pageCount())
                    {
                        $scope.currentPage++;
                    }
                };

                $scope.lastPage = function ()
                {
                    $scope.currentPage = $scope.pageCount();
                };

                $scope.nextPageDisabled = function ()
                {
                    return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
                };

                $scope.setPage = function (n)
                {
                    $scope.currentPage = n;
                };

                $scope.range = function ()
                {
                    var range = [];
                    var rangeSize = 5;
                    var pageCount = $scope.pageCount();
                    var start = $scope.currentPage;

                    if ((start + pageCount) - rangeSize < 0)
                    {
                        rangeSize = pageCount + 1;
                    }

                    if (start > pageCount - rangeSize)
                    {
                        start = pageCount - rangeSize + 1;
                    }

                    for (var i = start; i < start + rangeSize; i++)
                    {
                        range.push(i);
                    }

                    return range;
                };

            }]);
})();