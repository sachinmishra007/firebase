﻿using System;
using System.Collections.Generic;
using System.Linq;

using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class ProductNotesLogic : Contracts.IProductNotesLogic
    {
        #region Constructor

        private readonly IProductRepository _productRepository;

        public ProductNotesLogic(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        #endregion

        #region Public Methods

        public List<Entities.Note> GetProductNotes(string productCode, Entities.Language language)
        {
            var notes =  _productRepository.GetProductNotes(productCode, language);
            var pendingNotes = GetPendingProductNotes();

            foreach (var pendingNote in pendingNotes)
            {
                var note = notes.FirstOrDefault(n => n.Id == pendingNote.Id);

                if (note != null)
                {
                    note.Status = pendingNote.Status;
                }
            }

            return notes;
        }

        public List<Entities.Product> GetNotesProducts()
        {
            return _productRepository.GetNotesProducts();
        }

        public List<Entities.Note> GetPendingProductNotes()
        {
            return _productRepository.GetPendingProductNotes();
        }

        public void StageProductNote(Entities.Note note, string userId)
        {
            if (note == null || string.IsNullOrWhiteSpace(userId))
                return;

            note.Status = Entities.StagingStatus.PendingAuthorise;
            note.RevisedByUserId = userId;
            note.RevisionDate = DateTime.Now;

            _productRepository.SaveProductNoteToStaging(note);
        }

        public void PendingNotesUpdateStatus(List<Entities.Note> notes, string userId)
        {
            if (notes == null || notes.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return;

            foreach (var note in notes)
            {
                switch (note.Status)
                {
                    case Entities.StagingStatus.Authorise:
                        PendingNoteAuthorise(note.Id, userId);
                        break;
                    case Entities.StagingStatus.Reject:
                        PendingNoteReject(note.Id, userId);
                        break;
                }
            }
        }

        #endregion

        #region Private Methods

        private void PendingNoteAuthorise(int noteId, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            _productRepository.UpdateNoteStagingStatus(noteId, Entities.StagingStatus.Authorise, userId);

            var note = _productRepository.GetProductNote(noteId);

            if (note == null)
                return;

            _productRepository.SaveAuthorisedNote(note);
        }

        private void PendingNoteReject(int noteId, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            _productRepository.UpdateNoteStagingStatus(noteId, Entities.StagingStatus.Reject, userId);
        }

        #endregion
    }
}
