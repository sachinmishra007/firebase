﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;
using WIMQuotesAdmin.Common.Extensions;


namespace WIMQuotesAdmin.UI.Api
{
    public class CDSBreakdownReportController : ApiController
    {
        private readonly WIMQuotesAdmin.Domain.Logic.Contracts.ICDSBreakdownLogic _CDSBreakdownLogic;

        public CDSBreakdownReportController(WIMQuotesAdmin.Domain.Logic.Contracts.ICDSBreakdownLogic CDSBreakdownLogic)
        {
            _CDSBreakdownLogic = CDSBreakdownLogic;
        }

        // GET api/CDSBreakdown
        public List<Entities.CDSBreakdownReport>Get([FromUri]Entities.QuoteFrequencyReportDetail reportDetail)
        {
            return _CDSBreakdownLogic.GetCDSBreakdownReport(reportDetail);
        }

    }
}