using System;
using System.Web;
using Microsoft.Web.Infrastructure.DynamicModuleHelper;
using Ninject;
using Ninject.Web.Common;

using WIMQuotesAdmin.UI;
using System.Configuration;

[assembly: WebActivatorEx.PreApplicationStartMethod(typeof(NinjectWebCommon), "Start")]
[assembly: WebActivatorEx.ApplicationShutdownMethod(typeof(NinjectWebCommon), "Stop")]

namespace WIMQuotesAdmin.UI
{
    public static class NinjectWebCommon 
    {
        private static readonly Bootstrapper Bootstrapper = new Bootstrapper();

        /// <summary>
        /// Starts the application
        /// </summary>
        public static void Start() 
        {
            DynamicModuleUtility.RegisterModule(typeof(OnePerRequestHttpModule));
            DynamicModuleUtility.RegisterModule(typeof(NinjectHttpModule));
            Bootstrapper.Initialize(CreateKernel);
        }
        
        /// <summary>
        /// Stops the application.
        /// </summary>
        public static void Stop()
        {
            Bootstrapper.ShutDown();
        }
        
        /// <summary>
        /// Creates the kernel that will manage your application.
        /// </summary>
        /// <returns>The created kernel.</returns>
        private static IKernel CreateKernel()
        {
            var kernel = new StandardKernel();
            try
            {
                kernel.Bind<Func<IKernel>>().ToMethod(ctx => () => new Bootstrapper().Kernel);
                kernel.Bind<IHttpModule>().To<HttpApplicationInitializationHttpModule>();

                RegisterServices(kernel);
                return kernel;
            }
            catch
            {
                kernel.Dispose();
                throw;
            }
        }

        /// <summary>
        /// Load your modules or register your services here!
        /// </summary>
        /// <param name="kernel">The kernel.</param>
        private static void RegisterServices(IKernel kernel)
        {
            // Domain
            kernel.Bind<Domain.Logic.Contracts.IFundMappingLogic>().To<Domain.Logic.FundMappingLogic>();
            kernel.Bind<Domain.Logic.Contracts.IAssetClassesLogic>().To<Domain.Logic.AssetClassesLogic>();
            kernel.Bind<Domain.Logic.Contracts.IFundIMLsLogic>().To<Domain.Logic.FundIMLsLogic>();
            kernel.Bind<Domain.Logic.Contracts.IFundTERLogic>().To<Domain.Logic.FundTERLogic>();
            kernel.Bind<Domain.Logic.Contracts.IFundFactSheetLogic>().To<Domain.Logic.FundFactSheetLogic>();
            kernel.Bind<Domain.Logic.Contracts.IUserLogic>().To<Domain.Logic.UserLogic>();
            kernel.Bind<Domain.Logic.Contracts.IMenuLogic>().To<Domain.Logic.MenuLogic>();
            kernel.Bind<Domain.Logic.Contracts.ITaxInformationLogic>().To<Domain.Logic.TaxInformationLogic>();
            kernel.Bind<Domain.Logic.Contracts.IGrowthRatesLogic>().To<Domain.Logic.GrowthRatesLogic>();
            kernel.Bind<Domain.Logic.Contracts.IIncomeRatesLogic>().To<Domain.Logic.IncomeRatesLogic>();
            kernel.Bind<Domain.Logic.Contracts.IProductNotesLogic>().To<Domain.Logic.ProductNotesLogic>();
            kernel.Bind<Domain.Logic.Contracts.IProductDocumentLogic>().To<Domain.Logic.ProductDocumentLogic>();
            kernel.Bind<Domain.Logic.Contracts.IRegulation28LimitLogic>().To<Domain.Logic.Regulation28LimitLogic>();
            kernel.Bind<Domain.Logic.Contracts.IFundManagementFeesLogic>().To<Domain.Logic.FundManagementFeesLogic>();
            kernel.Bind<Domain.Logic.Contracts.IGuarFee>().To<Domain.Logic.GuarFeeLogic>();
            kernel.Bind<Domain.Logic.Contracts.IWrapLogic>().To<Domain.Logic.WrapLogic>();
            kernel.Bind<Domain.Logic.Contracts.IFundPerformanceFeesLogic>().To<Domain.Logic.FundPerformanceFeesLogic>();
            kernel.Bind<Domain.Logic.Contracts.IReductionInYieldLogic>().To<Domain.Logic.ReductionInYieldLogic>();
            kernel.Bind<Domain.Logic.Contracts.IQuoteFrequencyLogic>().To<Domain.Logic.QuoteFrequencyLogic>();
            kernel.Bind<Domain.Logic.Contracts.IAdminActivityReportLogic>().To<Domain.Logic.AdminActivityReportLogic>();
            kernel.Bind<Domain.Logic.Contracts.IValidationLogic>().To<Domain.Logic.ValidationLogic>();
            kernel.Bind<Domain.Logic.Contracts.IUserAccessControlReportLogic>().To<Domain.Logic.UserAccessControlReportLogic>();
            kernel.Bind<Domain.Logic.Contracts.ICDSBreakdownLogic>().To<Domain.Logic.CDSBreakdownLogic>();
            kernel.Bind<Domain.Logic.Contracts.IFundZeroFeeLogic>().To<Domain.Logic.FundZeroFeeLogic>();
            kernel.Bind<Domain.Logic.Contracts.IFundMinimumLogic>().To<Domain.Logic.FundMinimumLogic>();
            kernel.Bind<Domain.Logic.Contracts.IFundTICLogic>().To<Domain.Logic.FundTICLogic>();
            kernel.Bind<Domain.Logic.Contracts.IFundSecurityFeesLogic>().To<Domain.Logic.FundSecurityFeesLogic>();
            kernel.Bind<Domain.Logic.Contracts.IinactiveFundLogic>().To<Domain.Logic.InactiveFundLogic>();


            // Repositories
            kernel.Bind<DataAccess.Repositories.Contracts.IPortfolioAdminRepository>().To<DataAccess.Repositories.PortfolioAdminRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IPortfolioPerformanceRepository>().To<DataAccess.Repositories.PortfolioPerformanceRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IAuthenticationRepository>().To<DataAccess.Repositories.AuthenticationRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IQuoteAdminRepository>().To<DataAccess.Repositories.QuotesAdminRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.ITaxInformationRepository>().To<DataAccess.Repositories.TaxInformationRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IProductRepository>().To<DataAccess.Repositories.ProductRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IFundIMLRepository>().To<DataAccess.Repositories.FundIMLRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IFundTERRepository>().To<DataAccess.Repositories.FundTERRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IFundFactSheetRepository>().To<DataAccess.Repositories.FundFactSheetRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IRegulation28LimitsRepository>().To<DataAccess.Repositories.Regulation28LimitRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IFundManagementFeesRepository>().To<DataAccess.Repositories.FundManagementRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IGuarFeeRepository>().To<DataAccess.Repositories.GuarFeeRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IFundPerformanceFeesRepository>().To<DataAccess.Repositories.FundPerformanceFeesRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IReductionInYieldRepository>().To<DataAccess.Repositories.ReductionInYieldRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IQuoteFrequencyRepository>().To<DataAccess.Repositories.QuoteFrequencyRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IAdminActivityReportRepository>().To<DataAccess.Repositories.AdminActivityReportRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IProductDocumentRepository>().To<DataAccess.Repositories.ProductDocumentRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IValidationRepository>().To<DataAccess.Repositories.ValidationRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IUserAccessControlReportRepository>().To<DataAccess.Repositories.UserAccessControlReportRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.ICDSBreakdownRepository>().To<DataAccess.Repositories.CDSBreakdownRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IFundZeroFeeRepository>().To<DataAccess.Repositories.FundZeroFeeRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IFundMinimumRepository>().To<DataAccess.Repositories.FundMinimumRepository>();

            kernel.Bind<DataAccess.Repositories.Contracts.IFundTICRepository>().To<DataAccess.Repositories.FundTICRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IFundSecurityFeesRepository>().To<DataAccess.Repositories.FundSecurityFeesRepository>();
            kernel.Bind<DataAccess.Repositories.Contracts.IinactiveFundRepository>().To<DataAccess.Repositories.InactiveFundRepository>();
        }
    }
}
