﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface ICDSBreakdownRepository
    {
        List<Entities.CDSBreakdownReport> GetCDSBreakdownReport(DateTime startDate, DateTime endDate, string brokerCode);
    }
}
