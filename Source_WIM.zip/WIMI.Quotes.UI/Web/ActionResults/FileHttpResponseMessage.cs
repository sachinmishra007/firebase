﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace WIMI.Quotes.UI.Web.ActionResults
{
    public class FileHttpResponseMessage : HttpResponseMessage
    {
        public FileHttpResponseMessage(byte[] fileData, string fileName, string contentType)
        {
            if (fileData == null)
                throw new ArgumentNullException("fileData");

            StatusCode = HttpStatusCode.OK;

            Content = new ByteArrayContent(fileData);

            if (!String.IsNullOrWhiteSpace(contentType))
            {
                Content.Headers.ContentType = new MediaTypeHeaderValue(contentType);
            }

            Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
            {
                FileName = !String.IsNullOrWhiteSpace(fileName) ? fileName : "File"
            };
        }
    }
}