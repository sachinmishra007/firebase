﻿using System.Web;
using System.Web.Mvc;

namespace WIMI.Quotes.UI.Web.HtmlHelpers
{
    public static class UserExtensions
    {
        /// <summary>
        /// Returns the role for current user
        /// </summary>
        public static string CurrentUserRole(this HtmlHelper html)
        {
            var loginLogic = DependencyResolver.Current.GetService<Model.Domain.Contracts.IUserLogic>();
            return loginLogic.GetUserRole(HttpContext.Current.User.Identity.Name);
        }

        /// <summary>
        /// Returns the role for current user
        /// </summary>
        public static string CurrentUser(this HtmlHelper html)
        {
            return HttpContext.Current.User.Identity.Name;
        }
    }
}