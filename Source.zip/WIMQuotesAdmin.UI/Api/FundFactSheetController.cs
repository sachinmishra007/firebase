﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ActionResults;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    public class FundFactSheetController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IFundFactSheetLogic _fundFactSheetLogic;

        public FundFactSheetController(Domain.Logic.Contracts.IFundFactSheetLogic fundFactSheetLogic)
        {
            _fundFactSheetLogic = fundFactSheetLogic;
        }

        #endregion

        // GET api/FundFactSheet
        [ValidateApiAntiForgeryToken]
        public List<Entities.FundFactSheet> Get(Entities.FundType fundType, string fundCode)
        {
            return _fundFactSheetLogic.Get(fundType, fundCode);
        }

        // POST api/FundFactSheet
        [ValidateApiAntiForgeryToken]
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void Post([FromBody]Entities.FundFactSheet fundFactSheet, [ModelBinder]IPrincipal user)
        {
            if (fundFactSheet == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundFactSheetLogic.StageFundFactSheet(fundFactSheet, user.Identity.Name);
        }

        // GET: api/FundFactSheet/GetUnmappedFunds
        [ValidateApiAntiForgeryToken]
        [Route("api/FundFactSheet/GetUnmappedFunds")]
        public IEnumerable<Entities.Fund> GetUnmappedFunds()
        {
            return _fundFactSheetLogic.GetUnmappedFunds();
        }

        [ValidateApiAntiForgeryToken]
        [Route("api/FundFactSheet/UnmappedFunds/{fundType}")]
        public IEnumerable<Entities.Fund> GetUnmappedFundsByType(Entities.FundType fundType)
        {
            return _fundFactSheetLogic.GetUnmappedFundsByType(fundType);
        }

        // GET api/FundFactSheet/Pending
        [Route("api/FundFactSheet/Pending")]
        [ValidateApiAntiForgeryToken]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public List<Entities.FundFactSheet> GetPendingFundFactSheets()
        {
            return _fundFactSheetLogic.GetPendingFundFactSheets();
        }

        // POST api/FundFactSheet/UpdatePendingStatuses
        [HttpPost]
        [ValidateApiAntiForgeryToken]
        [Route("api/FundFactSheet/UpdatePendingStatuses")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingFundFactSheetsUpdateStatus([FromBody]List<Entities.FundFactSheet> fundFactSheets, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (fundFactSheets == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundFactSheetLogic.PendingFundFactSheetsUpdateStatus(fundFactSheets, user.Identity.Name);
        }

        // GET: api/FundFactSheet/ABMM
        [Route("api/FundFactSheet/{fundCode}")]
        public HttpResponseMessage GetFundFactSheetFile(string fundCode)
        {
            try
            {
                if (String.IsNullOrWhiteSpace(fundCode))
                    return Request.CreateResponse(HttpStatusCode.BadRequest);

                var file = _fundFactSheetLogic.GetFundFactSheetFile(fundCode);

                if (file == null)
                    return Request.CreateResponse(HttpStatusCode.BadRequest);

                return new FileHttpResponseMessage(file.Data, file.Name, Constants.MimeTypes.Pdf);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // GET: api/FundFactSheet/ABMM
        [Route("api/FundFactSheet/Pending/{fundCode}")]
        public HttpResponseMessage GetPendingFundFactSheetFile(string fundCode)
        {
            try
            {
                if (String.IsNullOrWhiteSpace(fundCode))
                    return Request.CreateResponse(HttpStatusCode.BadRequest);

                var file = _fundFactSheetLogic.GetPendingFundFactSheetFile(fundCode);

                if (file == null)
                    return Request.CreateResponse(HttpStatusCode.BadRequest);

                return new FileHttpResponseMessage(file.Data, file.Name, Constants.MimeTypes.Pdf);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // GET: api/FundFactSheet/UploadFile
        [HttpPost]
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        [Route("api/FundFactSheet/UploadFile")]
        public HttpResponseMessage UploadFundFactSheetFile(
            [ModelBinder(typeof(FundFactSheetModelBinder))]Entities.FundFactSheet fundFactSheet,
            [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (fundFactSheet == null || string.IsNullOrWhiteSpace(fundFactSheet.FundCode) ||
                fundFactSheet.FileData == null || fundFactSheet.FileData.Length == 0)
                throw new HttpResponseException(HttpStatusCode.BadRequest);

            if (user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            _fundFactSheetLogic.StageFundFactSheet(fundFactSheet, user.Identity.Name);

            return Request.CreateResponse(HttpStatusCode.OK);
        }
    }
}
