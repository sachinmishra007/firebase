﻿using System;
using System.Collections.Generic;
using System.Linq;
using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

using WIMQuotesAdmin.DataAccess.Repositories.Mappings;
namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class FundMinimumRepository : IFundMinimumRepository
    {

        public List<Entities.FundMinimum> GetFundMinimumAmounts()
        {
            using (var context = new SLAService.SLAMaintenanceClient())
            {
                var fundMinimum = context.GetFundMinimumAmounts();

                if (fundMinimum == null)
                    return null;

                return fundMinimum.Select(f => new Entities.FundMinimum
                {
                    FundCode = f.FundId,
                    FundMinimumAmount = f.MinimumAmnt,
                    FundName = f.FundName,
                    ProductName = f.ProductName,
                    ProductId = f.ProductId,
                    TransactionTypeId = f.TransactionTypeId,
                    TransactionDesc = f.TransactionTypeDesc
                }).ToList();
            }
        }

        public void SaveFundMinimumToStaging(Entities.FundMinimum fundMinimum)
        {
            if (fundMinimum == null || string.IsNullOrWhiteSpace(fundMinimum.FundCode))
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                context.FundMinimumStagings.Add(WIMQuotesAdminStagingMapping.ToFundMinimumStaging(fundMinimum));
                context.SaveChanges();


            }
        }

        public List<Entities.FundMinimum> GetPendingFundMinimumAmounts()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.FundMinimumStagings
                    .Where(n => n.Status == (int)Entities.StagingStatus.PendingAuthorise)
                    .Select(WIMQuotesAdminStagingMapping.FromFundMinimumStaging)
                    .ToList();
            } 
        }

        public void PendingFundMinimumUpdateStatus(List<Entities.FundMinimum> fundMinimum, string userId)
        {
           
        }

        public void UpdateFundMinimumStagingStatus(Entities.FundMinimum fundMinimum)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundMinimum = context.FundMinimumStagings
                    .Where(f => f.FundId == fundMinimum.FundCode &&
                                f.Status == (int)Entities.StagingStatus.PendingAuthorise);

                foreach (var contextFundMinimumAmount in contextFundMinimum)
                {
                    contextFundMinimumAmount.Status = (int)fundMinimum.Status;
                    contextFundMinimumAmount.InstructionType = (int)fundMinimum.InstructionType;
                    contextFundMinimumAmount.ModifiedUserId = fundMinimum.ModifiedUserId;
                    contextFundMinimumAmount.ModifiedDateTime = DateTime.Now;
                }

                context.SaveChanges();
            }
        }

        public void SaveAuthorisedFundMinimum(Entities.FundMinimum fundMinimum)
        {
            if (fundMinimum == null)
                return;

            using (var context = new SLAService.SLAMaintenanceClient())
            {
                
               context.UpdateFundProductRule(SLAApplicationServiceMapping.ToFundMinimum(fundMinimum));

            }
        }

        public void DeleteAuthorisedFundMinimum(Entities.FundMinimum fundMinimum)
        {
            if (String.IsNullOrWhiteSpace(fundMinimum.FundCode))
                return;

            using (var context = new SLAService.SLAMaintenanceClient())
            {
                var fundZeroFees = new SLAService.FundZeroFee();
              context.DeleteFundProductRule(Mappings.SLAApplicationServiceMapping.ToFundMinimum(fundMinimum));
            }
        }
 
       public  List<Entities.Product> GetProducts()
        {
            using (var context = new SLAService.SLAMaintenanceClient())
            {
                var products = context.GetAllProducts();

                if (products == null)
                    return null;

                return products.Select(f => new Entities.Product
                {
                    Code=f.ProductId,
                    Name=f.ProductName
                }).ToList();
            }
        }

       public List<Entities.FundMinimum> GetFunds(string productId)
       {
           using (var context = new SLAService.SLAMaintenanceClient())
           {
               var funds = context.GetAllFundsFromProduct(productId);

               if (funds == null)
                   return null;

               return funds.Select(f => new Entities.FundMinimum
               {
                   FundCode = f.FundId,
                   FundName = f.FundName
               }).ToList();
           }
       }
       public List<Entities.FundMinimum> GetTransactionType(string productId, string fundId)
       {
           using (var context = new SLAService.SLAMaintenanceClient())
           {
               var funds = context.GetTransactionTypes(productId,fundId);

               if (funds == null)
                   return null;

               return funds.Select(f => new Entities.FundMinimum
               {
                 TransactionDesc=f.TransactionTypeDesc,
                 TransactionTypeId=f.TransactionTypeId
               }).ToList();
           }
       }


       void IFundMinimumRepository.AddNewFundMinimum(Entities.FundMinimum fundMinimum, string userId)
       {
           if (String.IsNullOrWhiteSpace(fundMinimum.FundCode) || String.IsNullOrWhiteSpace(fundMinimum.ProductId) || String.IsNullOrWhiteSpace(fundMinimum.TransactionDesc))
               return;


           using (var context = new SLAService.SLAMaintenanceClient())
           {
               context.SaveFundProductRule(Mappings.SLAApplicationServiceMapping.ToFundMinimum(fundMinimum));
           }
       }
    }
}
