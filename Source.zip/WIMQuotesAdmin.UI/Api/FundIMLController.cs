﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class FundIMLController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IFundIMLsLogic _fundIMLsLogic;

        public FundIMLController(Domain.Logic.Contracts.IFundIMLsLogic fundIMLsLogic)
        {
            _fundIMLsLogic = fundIMLsLogic;
        }

        #endregion

        // GET api/FundIML/ABMM
        [Route("api/FundIML/{fundCode}")]
        public Entities.FundIML Get(string fundCode)
        {
            return _fundIMLsLogic.Get(fundCode);
        }

        // POST api/FundIML
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void Post([FromBody]Entities.FundIML fundIML, [ModelBinder]IPrincipal user)
        {
            if (fundIML == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundIMLsLogic.StageIntendedMaximumLimits(fundIML, user.Identity.Name);
        }

        // GET: api/FundIML/GetAvailableFunds
        [Route("api/FundIML/GetAvailableFunds")]
        public IEnumerable<Entities.Fund> GetAvailableFunds()
        {
            return _fundIMLsLogic.GetAvailableFunds();
        }

        // GET: api/FundIML/UnmappedIMLs
        [Route("api/FundIML/UnmappedIMLs/{fundCode}")]
        public IEnumerable<Entities.IntendedMaximumLimit> GetUnmappedIMLsForFund(string fundCode)
        {
            return _fundIMLsLogic.GetUnmappedIMLsForFund(fundCode);
        }

        // GET api/FundIML/Pending
        [Route("api/FundIML/Pending")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public List<Entities.FundIML> GetPendingFundIML()
        {
            return _fundIMLsLogic.GetPendingFundIMLs();
        }

        // POST api/FundIML/UpdatePendingFundIMLsStatus
        [HttpPost]
        [Route("api/FundIML/UpdatePendingFundIMLsStatus")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingFundIMLsUpdateStatus([FromBody]List<Entities.FundIML> fundIMLs, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (fundIMLs == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundIMLsLogic.PendingFundIMLsUpdateStatus(fundIMLs, user.Identity.Name);
        }
    }
}
