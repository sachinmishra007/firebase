﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IAdminActivityReportRepository
    {
        List<Entities.AdminActivityReport> GetAdminActivityReport(Entities.AdminActivityReportDetail detail);
    }
}
