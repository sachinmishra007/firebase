﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;


namespace WIMQuotesAdmin.Entities
{
    public class Validation
    {
        public int Id { get; set; }
        public string FieldName { get; set; }
        public string Message { get; set; }
        public string MessageRevised { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public StagingStatus Status { get; set; }
        public string RevisedByUserId { get; set; }
        public DateTime? RevisionDate { get; set; }
    }
}
