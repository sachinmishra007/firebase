﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Entities
{
    public class BrokerDetails
    {
        public string SearchTerm { get; set; }
        public ReportType ReportType { get; set; }
    }
}
