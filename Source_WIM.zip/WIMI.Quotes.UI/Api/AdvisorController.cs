﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMI.Quotes.Common;
using WIMI.Quotes.UI.Web.ActionFilters;

namespace WIMI.Quotes.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class AdvisorController : ApiController
    {
        #region Contructors & DI

        private readonly Model.Domain.Contracts.IAdvisorLogic _quoteAdvisorLogic;

        public AdvisorController(Model.Domain.Contracts.IAdvisorLogic quoteLogic)
        {
            _quoteAdvisorLogic = quoteLogic;
        }

        #endregion

        // GET: api/Advisor 
        [HttpGet]
        [Authorize(Roles = Constants.Roles.Advisor)]
        public Entities.Advisor Get([ModelBinder]IPrincipal user)
        {
            return _quoteAdvisorLogic.GetAdvisor(user.Identity.Name);
        }

        // GET: api/Advisor/?searchTerm
        [HttpGet]
        [Authorize(Roles = Constants.Roles.Administrator)]
        public IEnumerable<Entities.Advisor> GetAdvisorsBySearchTerm(string searchTerm)
        {
            return _quoteAdvisorLogic.SearchAdvisors(searchTerm) ?? new List<Entities.Advisor>();
        }

        // GET: api/Product/ExistingProductValue
        
        [Route("api/Advisor/ExistingOngoingFee")]
        public decimal? GetAdvisorOngoingFee( string brokerCode, string policyNumber)
        {
            return _quoteAdvisorLogic.GetAdvisorOngoingFee(brokerCode, policyNumber);
        }
         
    }
} 