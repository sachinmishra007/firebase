﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IProductDocumentRepository
    {
        List<Entities.Product> GetProducts();

        Entities.File GetProductDocument(string productCode, Entities.Language language,
            Entities.DocumentType documentType);
    }
}
