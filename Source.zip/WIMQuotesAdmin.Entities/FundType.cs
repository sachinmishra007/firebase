﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMQuotesAdmin.Entities
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum FundType
    {
        Individual,
        Wrap
    }
}
