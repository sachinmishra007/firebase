﻿(function ()
{
    'use strict';

    angular.module('common.directives')
        .directive('ngShowSlide', function ()
        {
            return {
                restrict: 'A',
                scope: {
                    ngShowSlide: '='
                },
                link: function (scope, element)
                {
                    if (!scope.ngShowSlide)
                        element.hide();

                    scope.$watch('ngShowSlide', function (newVal)
                    {
                        if (newVal) {
                            element.stop().slideDown();
                        } else {
                            element.stop().slideUp();
                        }
                    });
                }
            };
        });

})();
