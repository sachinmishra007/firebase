﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class FundTERLogic : Contracts.IFundTERLogic
    {
        #region Constructor

        private readonly DataAccess.Repositories.Contracts.IFundTERRepository _fundTERRepository;

        public FundTERLogic(DataAccess.Repositories.Contracts.IFundTERRepository fundTERRepository)
        {
            _fundTERRepository = fundTERRepository;
        }

        #endregion

        public List<Entities.FundTER> Get(Entities.FundType fundType, string fundCode)
        {
            var fundTERs = _fundTERRepository.GetFundTERs(fundType, fundCode);
            var pendingFundTERs = GetPendingFundTERs();

            if (pendingFundTERs == null || pendingFundTERs.Count == 0)
                return fundTERs;

            foreach (var pendingFundTER in pendingFundTERs)
            {
                var fundTER = fundTERs.FirstOrDefault(f => f.FundCode == pendingFundTER.FundCode);

                if (fundTER == null)
                    continue;

                fundTER.Status = pendingFundTER.Status;
                fundTER.UserId = pendingFundTER.UserId;
                fundTER.ModifiedDateTime = pendingFundTER.ModifiedDateTime;
            }

            return fundTERs;
        }

        public List<Entities.Fund> GetUnmappedFunds()
        {
            return _fundTERRepository.GetUnmappedFunds();
        }

        public List<Entities.FundTER> GetPendingFundTERs()
        {
            return _fundTERRepository.GetPendingFundTERs();
        }

        public void StageFundTER(Entities.FundTER fundTER, string userId)
        {
            if (fundTER == null || string.IsNullOrWhiteSpace(userId))
                return;

            fundTER.Status = Entities.StagingStatus.PendingAuthorise;
            fundTER.UserId = userId;
            fundTER.ModifiedDateTime = DateTime.Now;

            _fundTERRepository.SaveFundTERToStaging(fundTER);
        }

        public void PendingFundTERsUpdateStatus(List<Entities.FundTER> fundTERs, string userId)
        {
            if (fundTERs == null || fundTERs.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return;

            foreach (var fundTER in fundTERs)
            {
                switch (fundTER.Status)
                {
                    case Entities.StagingStatus.Authorise:
                        PendingFundTERAuthorise(fundTER.FundCode, userId);
                        break;
                    case Entities.StagingStatus.Reject:
                        PendingFundTERReject(fundTER.FundCode, userId);
                        break;
                }
            }
        }

        #region Private Methods

        private void PendingFundTERAuthorise(string fundCode, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            var fundTER = _fundTERRepository.GetPendingFundTER(fundCode);

            if (fundTER == null)
                return;

            switch (fundTER.InstructionType)
            {
                case Entities.InstructionType.Delete:
                    _fundTERRepository.DeleteAuthorisedFundTER(fundTER.FundCode);
                    break;
                default:
                    _fundTERRepository.SaveAuthorisedFundTER(fundTER);
                    break;
            }

            _fundTERRepository.UpdateFundTERStagingStatus(fundCode, Entities.StagingStatus.Authorise, userId);
        }

        private void PendingFundTERReject(string fundCode, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            _fundTERRepository.UpdateFundTERStagingStatus(fundCode, Entities.StagingStatus.Reject, userId);
        }

        #endregion
    }
}
