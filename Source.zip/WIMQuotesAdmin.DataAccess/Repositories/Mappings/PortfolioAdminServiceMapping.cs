﻿using System.Linq;

namespace WIMQuotesAdmin.DataAccess.Repositories.Mappings
{
    public static class PortfolioAdminServiceMapping
    {
        #region To Mappings

        public static PortfolioAdminService.FundIML ToFundIML(Entities.FundIML fundIML)
        {
            if (fundIML == null || fundIML.IntendedMaximumLimits == null || fundIML.IntendedMaximumLimits.Count == 0)
                return null;

            return new PortfolioAdminService.FundIML
            {
                FundCode = fundIML.FundCode,
                IntendedMaximumLimits = fundIML.IntendedMaximumLimits.Select(i => new PortfolioAdminService.IntendedMaximumLimit
                {
                    Id = i.Id,
                    Code = i.Code,
                    Name = i.Name,
                    UpperLimit = (double)i.Value
                }).ToList()
            };
        }

        public static PortfolioAdminService.FundAssets ToFundAssets(Entities.FundAssets fundAsset)
        {
            if (fundAsset == null || fundAsset.AssetClass == null || fundAsset.AssetClass.Count == 0)
                return null;

            return new PortfolioAdminService.FundAssets
            {
                FundCode = fundAsset.FundCode,
                AssetClass = fundAsset.AssetClass.Select(i => new PortfolioAdminService.AssetClass
                {
                    Id = i.Id,
                    Name = i.Name,
                    Value = i.Value.GetValueOrDefault()
                }).ToList()
            };
        }

        public static PortfolioAdminService.FundTER ToFundTER(Entities.FundTER fundTER)
        {
            if (fundTER == null)
                return null;

            return new PortfolioAdminService.FundTER
            {
                FundCode = fundTER.FundCode,
                FundName = fundTER.FundName,
                TotalExpenseRatio = fundTER.TotalExpenseRatio,
                DateModified = fundTER.ModifiedDateTime
            };
        }

        public static PortfolioAdminService.Regulation28Limit ToRegulation28Limits(Entities.Regulation28Limits limit)
        {
            if (limit == null)
                return null;

            return new PortfolioAdminService.Regulation28Limit
            {
                Code = limit.Code,
                Name = limit.Name,
                Value = (double)limit.Value
            };
        }

        public static PortfolioAdminService.FundFactSheet ToFundFactSheet(Entities.FundFactSheet fundFactSheet)
        {
            if (fundFactSheet == null)
                return null;

            return new PortfolioAdminService.FundFactSheet
            {
                FundCode = fundFactSheet.FundCode,
                FundName = fundFactSheet.FundName,
                File = fundFactSheet.FileData,
                DateModified = fundFactSheet.ModifiedDateTime
            };
        }

        public static PortfolioAdminService.FundManagementFees ToFundManagementFees(Entities.FundManagementFees fundManagementFees)
        {
            if (fundManagementFees == null)
                return null;

            return new PortfolioAdminService.FundManagementFees
            {
                FundCode = fundManagementFees.FundCode,
                FundName = fundManagementFees.FundName,
                ManagementFee = fundManagementFees.ManagementFee,
                DateModified = fundManagementFees.ModifiedDateTime
            };
        }

        public static PortfolioAdminService.FundPerformanceFee ToFundPerformanceFees(Entities.FundPerformanceFees fundPerformanceFees)
        {
            if (fundPerformanceFees == null)
                return null;

            return new PortfolioAdminService.FundPerformanceFee
            {
                FundCode = fundPerformanceFees.FundCode,
                PerformanceFee = fundPerformanceFees.PerformanceFees.Select(pf => new PortfolioAdminService.PerformanceFee 
                {
                    TimePeriod = pf.TimePeriod,
                    ClosePrice = pf.ClosePrice,
                    Percentage = pf.Percentage
                }).ToList()
            };
        }

        public static PortfolioAdminService.FundType ToFundType(Entities.FundType fundType)
        {
            switch (fundType)
            {
                case Entities.FundType.Wrap:
                    return PortfolioAdminService.FundType.Wrap;
                default:
                    return PortfolioAdminService.FundType.Individual;
            }
        }

      

        #endregion

        #region From Mappings

        public static Entities.Fund FromFund(PortfolioAdminService.Fund fund)
        {
            if (fund == null)
                return null;

            return new Entities.Fund 
            {
                Code = fund.Code,
                Name = fund.Name
            };
        }

        public static Entities.FundType FromFundType(PortfolioAdminService.FundType fundType)
        {
            switch (fundType)
            {
                case PortfolioAdminService.FundType.Wrap:
                    return Entities.FundType.Wrap;
                default:
                    return Entities.FundType.Individual;
            }
        }

        #endregion
    }
}
