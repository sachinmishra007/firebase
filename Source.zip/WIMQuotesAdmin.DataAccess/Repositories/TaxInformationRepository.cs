﻿using System;
using System.Collections.Generic;
using System.Linq;
using WIMQuotesAdmin.Entities;

using WIMQuotesAdmin.Common.Extensions;
namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class TaxInformationRepository : Contracts.ITaxInformationRepository
    {
        public void AuthoriseTaxBrackets(Entities.TaxTables taxTable)
        {
            using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                
                context.UpdateTaxTables(Mappings.WIMQuotesApplicationServiceMapping.ToTaxTables(taxTable));
            }
        }

        public List<TaxInformation> GetTaxInformation()
        {
            using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                return context.GetTaxInformation().Select(f => new Entities.TaxInformation
                {
                    Id = f.Id,
                    Name = f.Name

                }).ToList();
            }
        }

        public TaxRebates GetTaxRebates()
        {
            var taxRebates = new Entities.TaxRebates();
            var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient();
            var returnedRebates = context.GetTaxRebates();

            taxRebates.PrimaryRebate = returnedRebates.PrimaryRebate;
            taxRebates.SecondaryRebate = returnedRebates.SecondaryRebate;
            taxRebates.ThirdRebate = returnedRebates.ThirdRebate;
            taxRebates.ModifiedUser = returnedRebates.UserId;
            taxRebates.LoggedInUser = string.Empty;
            taxRebates.CapturedUser = returnedRebates.UserId;
            taxRebates.Status = returnedRebates.Status.ToEnum<Entities.StagingStatus>();

            return taxRebates;
        }

        public List<TaxTables> GetTaxTables()
        {
            using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                return context.GetTaxTables().Select(tax => new Entities.TaxTables
                {
                    Id = tax.Id,
                    MinimumAmount = tax.MinimumAmount,
                    MaximumAmount = tax.MaximumAmount,
                    RateAmount = tax.RateAmount,
                    RatePercent = tax.RatePercent,
                    UserId = tax.UserId

                }).ToList();
            }
        }

        public List<Entities.TaxTables> RejectTaxBrackets()
        {
            using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                return context.RejectTaxTables().Select(tax => new Entities.TaxTables
                {
                    Id = tax.Id
                }).ToList();
            }
        }

        public void SaveTaxBracketsStaging(Entities.TaxTables taxTable, string userId)
        {
            if (taxTable == null)
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextTax = new DataModel.TaxTableStaging
                {
                    Id = taxTable.Id,
                    IncomeAmount = (decimal)taxTable.MaximumAmount,
                    TaxableAmount = (decimal)taxTable.MinimumAmount,
                    RateAmount = (decimal)taxTable.RateAmount,
                    RatePerc = (decimal)taxTable.RatePercent,
                    Status = (int) taxTable.Status,
                    UserId = userId,
                    ModifiedDateTime = DateTime.Now
                };

                context.TaxTableStagings.Add(contextTax);
                context.SaveChanges();
            }
        }

        public void SaveTaxRebatesStaging(Entities.TaxRebates rebates, string userId)
        {
            if (rebates == null)
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var rebateContext = new DataModel.TaxRebateStaging
                {
                    //TODO: Clarify which user gets sent when.
                    CapturedUser = rebates.LoggedInUser,
                    ModifiedDateTime = DateTime.Now,
                    PrimaryRebate = (decimal)rebates.PrimaryRebate,
                    SecondaryRebate = (decimal)rebates.SecondaryRebate,
                    ThirdRebate = (decimal)rebates.ThirdRebate,
                    Status = (int?)Entities.StagingStatus.PendingAuthorise
                };

                context.TaxRebateStagings.Add(rebateContext);
                context.SaveChanges();
            }
        }
        
        public void AuthoriseRebatesStaging(Entities.TaxRebates rebates, string userId)
        {
            if (rebates == null)
                return;

            var service = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient();

            service.UpdateTaxRebates(new WIMQuotesApplicationService.TaxRebate
            {
                UserId = rebates.ModifiedUser,
                SecondaryRebate = rebates.SecondaryRebate,
                ThirdRebate = rebates.ThirdRebate,
                Status = Convert.ToInt32(rebates.Status),
                PrimaryRebate = rebates.PrimaryRebate
            });

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var rebateContext = new DataModel.TaxRebateStaging
                {
                    //TODO: Clarify which user gets sent when.
                    CapturedUser = rebates.ModifiedUser,
                    ModifiedUser = userId,
                    ModifiedDateTime = DateTime.Now,
                    PrimaryRebate = (decimal)rebates.PrimaryRebate,
                    SecondaryRebate = (decimal)rebates.SecondaryRebate,
                    ThirdRebate = (decimal)rebates.ThirdRebate,
                    Status = (int?)Entities.StagingStatus.Authorise
                };



                context.TaxRebateStagings.Add(rebateContext);
                context.SaveChanges();
            }
        }

        public void RejectRebatesStaging()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextLimits = context.TaxRebateStagings
                    .Where(f => f.Status == (int)Entities.StagingStatus.PendingAuthorise);

                foreach (var contextLimit in contextLimits)
                {
                    contextLimit.Status = (int)Entities.StagingStatus.Reject;
                    contextLimit.ModifiedDateTime = DateTime.Now;
                }

                context.SaveChanges();
            }
        }


        public List<TaxTables> GetPendingTaxTables()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.TaxTableStagings
                               .Where(v => v.Status == (int)Entities.StagingStatus.PendingAuthorise)
                               .Select(Mappings.WIMQuotesAdminStagingMapping.FromTaxTablesStaging)
                               .ToList();
            }
        }


        public void UpdateTaxTablesStagingStatus(TaxTables taxTable, StagingStatus status, string userId)
        {
            if (taxTable == null || string.IsNullOrWhiteSpace(userId))
                return;
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextTaxTables = context.TaxTableStagings
                               .Where(v => v.Id == taxTable.Id &&
                                v.Status == (int)Entities.StagingStatus.PendingAuthorise);

                foreach (var contextTable in contextTaxTables)
                {
                    contextTable.Status = (int)status;
                    contextTable.UserId = userId;
                    contextTable.ModifiedDateTime = DateTime.Now;
                }

                context.SaveChanges();

            }
        }


        public TaxTables GetPendingTaxTableById(int id)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.TaxTableStagings
                       .Where(v => v.Id == id && v.Status == (int)Entities.StagingStatus.PendingAuthorise)
                       .Select(Mappings.WIMQuotesAdminStagingMapping.FromTaxTablesStaging)
                       .FirstOrDefault();
            }
        }
    }
}
