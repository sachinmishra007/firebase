﻿(function () {
    'use strict';

    angular
        .module('quotesApp.services')
        .factory('phaseInService', ['$http', 'lookupService', function ($http, lookupService) {
            var phaseInService = {};

            phaseInService.getFirstDate = function () {
                return $http({ url: 'api/PhaseIn/FirstDate' });
            };

            phaseInService.getPhaseInFundDetails = function () {
                return lookupService.getPhaseInFundDetails();
            };


            return phaseInService;
        }]);
})();
