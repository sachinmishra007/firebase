﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Entities
{
    public class Broker
    {
        public string BrokerCode { get; set; }
        public string BrokerFullName { get; set; }
    }
}
