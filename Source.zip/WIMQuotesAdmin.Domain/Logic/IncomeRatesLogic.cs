﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.DataAccess.SLAService;
using WIMQuotesAdmin.Domain.Logic.Contracts;
using WIMQuotesAdmin.Entities;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class IncomeRatesLogic : IIncomeRatesLogic
    {
        public IncomeRates CaptureRates(IncomeRates rates)
        {
            var sla = new DataAccess.SLAService.SLAMaintenanceClient();
            sla.CaptureIncome(Convert.ToString(rates.AnnuityAmount), rates.Guarantor, rates.ProductType,
                rates.StartDate, rates.EndDate, rates.PlacementDate, rates.MaturityDate, Convert.ToString(rates.AnnuityAmount),
                rates.FirstIncomeDate, rates.User);
            return MapGrowthRates(sla.GetLatestRates(rates.ProductType));
        }

        public void AutoriseRates(IncomeRates rates)
        {
            var sla = new DataAccess.SLAService.SLAMaintenanceClient();
            sla.AuthoriseIncome(rates.User, Convert.ToString(rates.Yield), Convert.ToString(rates.AIMSFee), Convert.ToString(rates.UnderWriterFees), rates.Guarantor, rates.ProductType, rates.StartDate, rates.EndDate, rates.PlacementDate, rates.MaturityDate, Convert.ToString(0.00), Convert.ToString(0.00));
        }

        public Entities.IncomeRates GetLatestRates(string productCode)
        {
            var sla = new DataAccess.SLAService.SLAMaintenanceClient();
            var mappedRates = MapGrowthRates(sla.GetLatestRates(productCode));
            mappedRates.ProductType = productCode;
            return mappedRates;
        }

        //TODO: Move this into it's own class for growth and income to use.
        public void RejectRates(string productCode)
        {
            var sla = new DataAccess.SLAService.SLAMaintenanceClient();
            sla.RejectRates(productCode);
        }

        public Entities.IncomeRates MapGrowthRates(Dictionary<string, string> calculatedRates)
        {
            Entities.IncomeRates rates = new Entities.IncomeRates();

            if (calculatedRates.Count > 0)
            {
                rates.Yield = Convert.ToDouble((from pv in calculatedRates
                                                where pv.Key.Contains("Yield")
                                                select pv.Value).First());

                rates.StartDate = Convert.ToString((from pv in calculatedRates
                                                    where pv.Key.Contains("startDate")
                                                    select pv.Value).First());

                rates.EndDate = Convert.ToString((from pv in calculatedRates
                                                  where pv.Key.Contains("endDate")
                                                  select pv.Value).First());

                rates.PlacementDate = Convert.ToString((from pv in calculatedRates
                                                        where pv.Key.Contains("trancheDate")
                                                        select pv.Value).First());

                rates.MaturityDate = Convert.ToString((from pv in calculatedRates
                                                       where pv.Key.Contains("MaturityDate")
                                                       select pv.Value).First());

                rates.User = Convert.ToString((from pv in calculatedRates
                                               where pv.Key.Contains("Capturer")
                                               select pv.Value).First());

                rates.Guarantor = Convert.ToString((from pv in calculatedRates
                                                    where pv.Key.Contains("Guarantor")
                                                    select pv.Value).First());

                rates.AnnuityAmount = Convert.ToDouble((from pv in calculatedRates
                                                        where pv.Key.Contains("AbcapAnnuity")
                                                        select pv.Value).First());

                rates.FirstIncomeDate = Convert.ToString((from pv in calculatedRates
                                                          where pv.Key.Contains("FirstIncomeDate")
                                                          select pv.Value).First());

                rates.RateAfterFees = Convert.ToDouble((from pv in calculatedRates
                                                        where pv.Key.Contains("Effective Rate")
                                                        select pv.Value).First());

                rates.UnderWriterFees = Convert.ToDouble((from pv in calculatedRates
                                                          where pv.Key.Contains("Underwriter Fee")
                                                          select pv.Value).First());

                rates.AIMSFee = Convert.ToDouble((from pv in calculatedRates
                                                  where pv.Key.Contains("AIMS Fee")
                                                  select pv.Value).First());

                rates.FeeStatus = Convert.ToString((from pv in calculatedRates
                                                    where pv.Key.Contains("FeeStatus")
                                                    select pv.Value).First());

                rates.NACMRate = calculatedRates.ContainsKey("GUARDINC Monthly") ? Convert.ToDouble((from pv in calculatedRates
                                                   where pv.Key.Contains("GUARDINC Monthly")
                                                   select pv.Value).First()) :Convert.ToDouble((from pv in calculatedRates
                                                   where pv.Key.Contains("INCOME Monthly")
                                                   select pv.Value).First());
               
            }
            return rates;
        }
    }
}
