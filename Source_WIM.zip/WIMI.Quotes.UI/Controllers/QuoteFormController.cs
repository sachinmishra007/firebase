﻿using System;
using System.Web.Mvc;

namespace WIMI.Quotes.UI.Controllers
{
    public class QuoteFormController : Controller
    {
        // GET: QuoteForm
        public ActionResult Index(Guid quoteGroupId)
        {
            if (quoteGroupId != Guid.Empty)
            {
                ViewBag.QuoteGroupId = quoteGroupId;
            }

            return View();
        }
    }
}