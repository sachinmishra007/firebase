﻿using MorningStarWebTool.Common;
using MorningStarWebTool.Common.ApplicationConstant;
using MorningStarWebTool.DataLayer.Class;
using MorningStarWebTool.Model.Domain.Contract;
using MorningStarWebTool.Web.ActionFilters;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;

namespace MorningStarWebTool.Api
{
    [RoutePrefix("api/MorningStarComponent")]
    [AuthorizeRoles(Constants.Roles.ALL)]
    public class MorningStarComponentController : ApiController
    {
        private readonly ISettingLogic _settingLogic = null;
        private readonly IMorningStarDetails _morningStarDetails = null;
        private ToolConfig _msConfigTool = null;
        private Util _utilites = null;

        public MorningStarComponentController(
            ISettingLogic settingLogic,
            IMorningStarDetails morningStarDetails
           )
        {
            _settingLogic = settingLogic;
            _morningStarDetails = morningStarDetails;
            _utilites = new Util();
            _msConfigTool = new ToolConfig();

        }

        [HttpGet]
        [AcceptVerbs("POST", "GET")]
        [ActionName("GetMorningStarLoadingDetails")]
        [Route("GetMorningStarLoadingDetails/{_toolName}")]
        [ResponseType(typeof(string))]
        public async Task<IHttpActionResult> Get(string _toolName)
        {
            try
            {
                return Ok(_morningStarDetails.GetMorningStarDetails(_toolName));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }

}
