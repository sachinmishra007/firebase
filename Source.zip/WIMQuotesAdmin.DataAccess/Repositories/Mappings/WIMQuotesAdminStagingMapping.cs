﻿using System;
using System.Collections.Generic;
using System.Linq;

using WIMQuotesAdmin.Common.Extensions;
using WIMQuotesAdmin.DataModel;

namespace WIMQuotesAdmin.DataAccess.Repositories.Mappings
{
    public static class WIMQuotesAdminStagingMapping
    {
        #region To Mappings

        public static ProductNoteStaging ToProductNoteStaging(Entities.Note note)
        {
            if (note == null)
                return null;

            return new ProductNoteStaging
            {
                NoteId = note.Id,
                ProductCode = note.ProductCode,
                ProductName = note.ProductName,
                LanguageCode = ToLanguage(note.Language),
                LanguageName = note.LanguageName,
                NoteType = note.NoteType,
                HeaderOriginal = note.Header,
                HeaderRevised = note.HeaderRevised,
                NoteOriginal = note.Description,
                NoteRevised = note.DescriptionRevised,
                Status = (int)note.Status,
                CapturedUserId = note.RevisedByUserId,
                ModifiedDateTime = note.RevisionDate.GetValueOrDefault()
            };
        }

        public static string ToLanguage(Entities.Language language)
        {
            switch (language)
            {
                case Entities.Language.Afrikaans:
                    return "AFR";
                default:
                    return "ENG";
            }
        }

        public static List<FundIMLStaging> ToFundIMLStaging(Entities.FundIML fundIML)
        {
            if (fundIML == null || fundIML.IntendedMaximumLimits == null || fundIML.IntendedMaximumLimits.Count == 0)
                return null;

            return fundIML.IntendedMaximumLimits.Select(i => new FundIMLStaging
            {
                FundCode = fundIML.FundCode,
                IMLTypeId = i.Id,
                IMLTypeCode = i.Code,
                IMLTypeName = i.Name,
                Value = i.Value,
                Status = (int)fundIML.Status,
                CapturedUserId = fundIML.UserId,
                ModifiedDateTime = fundIML.ModifiedDateTime
            }).ToList();
        }

        public static List<FundAssetClassesStaging> ToFundAssetClassesStaging(string fundCode, List<Entities.AssetClass> assetClasses, string userId)
        {
            if (assetClasses == null || assetClasses.Count == 0 || string.IsNullOrWhiteSpace(fundCode))
                return null;

            return assetClasses.Select(i => new FundAssetClassesStaging
            {
                FundCode = fundCode,
                AssetClassTypeId = i.Id,
                AssetClassDescription = i.Name,
                Value = i.Value,
                Status = (int)Entities.StagingStatus.PendingAuthorise,
                CapturedUserId = userId,
                ModifiedDateTime = DateTime.Now
            }).ToList();
        }

        public static List<FundAssetClassesStaging> ToFundAssetClassesStaging(Entities.FundAssets fundAssets, string userId)
        {
            if (fundAssets == null || fundAssets.AssetClass == null || fundAssets.AssetClass.Count == 0)
                return null;

            return fundAssets.AssetClass.Select(i => new FundAssetClassesStaging
            {
                FundCode = fundAssets.FundCode,
                AssetClassTypeId = i.Id,
                AssetClassDescription = i.Name,
                Value = i.Value,
                Status = (int)Entities.StagingStatus.PendingAuthorise,
                InstructionType = (int)i.InstructionType,
                CapturedUserId = userId,
                ModifiedDateTime = DateTime.Now

            }).ToList();
        }

        public static FundAssetClassesStaging ToFundAssetClassesStaging(Entities.AssetClass assetClass, string fundCode, string userId)
        {
            if (assetClass == null || string.IsNullOrWhiteSpace(fundCode) || string.IsNullOrWhiteSpace(userId))
                return null;

            return new FundAssetClassesStaging
            {
                FundCode = fundCode,
                AssetClassTypeId = assetClass.Id,
                AssetClassDescription = assetClass.Name,
                Value = assetClass.Value,
                Status = (int)assetClass.Status,
                InstructionType = (int)assetClass.InstructionType,
                CapturedUserId = userId,
                ModifiedDateTime = DateTime.Now

            };
        }

        public static FundMappingStaging ToFundMappingStaging(Entities.FundMapping mapping)
        {
            if (mapping == null)
                return null;

            return new FundMappingStaging
            {
                FundName = mapping.FundName,
                AIMSFundCode = mapping.FundCode,
                ModifiedDateTime = DateTime.Now,
                CapturedUserId = mapping.UserId,
                InstructionType = (int)mapping.InstructionType,
                MSISISN = mapping.MSISIN,
                ShareClassId = mapping.MorningStarShareClassId,
                Status = (int)mapping.Status

            };
        }

        public static FundPerformanceFeeStaging ToFundPerformanceFeesStaging(Entities.PerformanceFees performanceFees, string fundCode, string userId)
        {
            if (performanceFees == null || string.IsNullOrWhiteSpace(fundCode) || string.IsNullOrWhiteSpace(userId))
                return null;

            return new FundPerformanceFeeStaging
            {
                FundCode = fundCode,
                TimePeriod = performanceFees.TimePeriod,
                ClosePrice = (decimal)performanceFees.ClosePrice,
                FundPercentage = (decimal)performanceFees.Percentage,
                Status = (int)performanceFees.Status,
                InstructionType = (int)performanceFees.InstructionType,
                CapturedUserId = userId,
                ModifiedDateTime = DateTime.Now

            };
        }

        public static FundTERStaging ToFundTERStaging(Entities.FundTER fundTER)
        {
            if (fundTER == null)
                return null;

            return new FundTERStaging
            {
                FundCode = fundTER.FundCode,
                FundName = fundTER.FundName,
                TotalExpenseRatio = (decimal)fundTER.TotalExpenseRatio,
                Status = (int)fundTER.Status,
                InstructionType = (int)fundTER.InstructionType,
                CapturedUserId = fundTER.UserId,
                ModifiedDateTime = DateTime.Now
            };
        }

        public static Regulation28LimitsStaging ToLimitStaging(Entities.Regulation28Limits limit)
        {
            if (limit == null)
                return null;

            return new Regulation28LimitsStaging
            {
                Code = limit.Code,
                Name = limit.Name,
                Value = limit.Value,
                Status = (int)limit.Status,
                InstructionType = (int)limit.InstructionType,
                CapturedUserId = limit.UserId,
                ModifiedDateTime = DateTime.Now
            };
        }

        public static ReductionInYieldStaging ToYieldStaging(Entities.ReductionInYield yield)
        {
            if (yield == null)
                return null;

            return new ReductionInYieldStaging
            {
                ProductCode = yield.ProductCode,
                ProductName = yield.ProductName,
                Term = yield.Term,
                Status = (int)yield.Status,
                InstructionType = (int)yield.InstructionType,
                CapturedUserId = yield.UserId,
                ModifiedDateTime = DateTime.Now,
                AssumedGrossReturn = (decimal)yield.AssumedGrossReturn
            };
        }

        public static FundFactSheetStaging ToFundFactSheetStaging(Entities.FundFactSheet fundFactSheet)
        {
            if (fundFactSheet == null)
                return null;

            return new FundFactSheetStaging
            {
                FundCode = fundFactSheet.FundCode,
                FundName = fundFactSheet.FundName,
                FileName = fundFactSheet.FileName,
                FileData = fundFactSheet.FileData,
                Status = (int)fundFactSheet.Status,
                InstructionType = (int)fundFactSheet.InstructionType,
                CapturedUserId = fundFactSheet.UserId,
                ModifiedDateTime = DateTime.Now
            };
        }

        public static FundManagementFeeStaging ToFundManagementFeeStaging(Entities.FundManagementFees fundManagementFees)
        {
            if (fundManagementFees == null)
                return null;

            return new FundManagementFeeStaging
            {
                FundCode = fundManagementFees.FundCode,
                FundName = fundManagementFees.FundName,
                Status = (int)fundManagementFees.Status,
                ManagementFee = (decimal)fundManagementFees.ManagementFee,
                InstructionType = (int)fundManagementFees.InstructionType,
                CapturedUserId = fundManagementFees.UserId,
                ModifiedDateTime = DateTime.Now
            };
        }

        public static ValidationStaging ToValidationStaging(Entities.Validation validation)
        {
            if (validation == null)
                return null;

            return new ValidationStaging
            {
                Id = validation.Id,
                FieldName = validation.FieldName,
                MessageOriginal = validation.MessageRevised,
                MessageRevised = validation.Message,
                CapturedUserId = validation.RevisedByUserId,
                Status = (int)validation.Status,
                ModifiedDateTime = Convert.ToDateTime(validation.RevisionDate)
            };
        }

        public static FundMinimumStaging ToFundMinimumStaging(Entities.FundMinimum fundMinimum)
        {
            if (fundMinimum == null)
                return null;

            return new FundMinimumStaging
            {
                FundName = fundMinimum.FundName,
                ProductName = fundMinimum.ProductName,
                TransactionDescription = fundMinimum.TransactionDesc,
                Amount = fundMinimum.FundMinimumAmount,
                CapturedUserId = fundMinimum.CapturedUserId,
                FundId = fundMinimum.FundCode,
                InstructionType = (int)fundMinimum.InstructionType,
                ModifiedDateTime = DateTime.Now,
                ModifiedUserId = fundMinimum.ModifiedUserId,
                ProductId = fundMinimum.ProductId,
                Status = (int)fundMinimum.Status,
                TransactionTypeId = fundMinimum.TransactionTypeId
            };
        }

        #endregion

        #region From Mappings

        public static Entities.Note FromProductNoteStaging(ProductNoteStaging note)
        {
            if (note == null)
                return null;

            return new Entities.Note
            {
                Id = note.NoteId,
                ProductCode = note.ProductCode,
                ProductName = note.ProductName,
                Language = FromLanguage(note.LanguageCode),
                LanguageName = note.LanguageName,
                NoteType = note.NoteType,
                Header = note.HeaderOriginal,
                HeaderRevised = note.HeaderRevised,
                Description = note.NoteOriginal,
                DescriptionRevised = note.NoteRevised,
                Status = note.Status.ToEnum<Entities.StagingStatus>(),
                RevisedByUserId = note.CapturedUserId,
                RevisionDate = note.ModifiedDateTime
            };
        }

        public static Entities.Language FromLanguage(string language)
        {
            switch (language)
            {
                case "AFR":
                    return Entities.Language.Afrikaans;
                default:
                    return Entities.Language.English;
            }
        }

        public static List<Entities.FundIML> FromFundIMLStaging(List<FundIMLStaging> fundIMLStaging)
        {
            if (fundIMLStaging == null || fundIMLStaging.Count == 0)
                return new List<Entities.FundIML>();

            var fundIMLs = new List<Entities.FundIML>();
            var distinctFundCodes = fundIMLStaging.Select(f => f.FundCode).Distinct();

            foreach (var fundCode in distinctFundCodes)
            {
                var imls = fundIMLStaging.Where(f => f.FundCode == fundCode).ToList();

                if (imls.Count == 0)
                    continue;

                var iml = imls.First();

                fundIMLs.Add(new Entities.FundIML
                {
                    FundCode = iml.FundCode,
                    Status = iml.Status.ToEnum<Entities.StagingStatus>(),
                    UserId = iml.CapturedUserId,
                    ModifiedDateTime = iml.ModifiedDateTime,
                    IntendedMaximumLimits = imls.Select(i => new Entities.IntendedMaximumLimit
                    {
                        Id = i.IMLTypeId,
                        Code = i.IMLTypeCode,
                        Name = i.IMLTypeName,
                        Value = i.Value.GetValueOrDefault()
                    }).ToList()
                });
            }

            return fundIMLs;
        }

        public static List<Entities.FundAssets> FromFundAssetClassesStagings(List<FundAssetClassesStaging> fundAssetClassesStagings)
        {
            if (fundAssetClassesStagings == null || fundAssetClassesStagings.Count == 0)
                return new List<Entities.FundAssets>();

            var fundAssets = new List<Entities.FundAssets>();

            var distinctFundCodes = fundAssetClassesStagings.Select(f => f.FundCode).Distinct();

            foreach (var fundCode in distinctFundCodes)
            {
                var assets = fundAssetClassesStagings.Where(f => f.FundCode == fundCode).ToList();

                if (assets.Count == 0)
                    continue;

                var assetList = new List<Entities.AssetClass>();

                foreach (var assetClass in assets)
                {


                    assetList.Add(new Entities.AssetClass
                    {
                        Id = assetClass.AssetClassTypeId,
                        Name = assetClass.AssetClassDescription,
                        Value = assetClass.Value,
                        InstructionType = assetClass.InstructionType.ToEnum<Entities.InstructionType>(),
                        Status = assetClass.Status.ToEnum<Entities.StagingStatus>(),
                        UserId = assetClass.CapturedUserId
                    });
                }

                var asset = assets.First();

                fundAssets.Add(new Entities.FundAssets
                {
                    FundCode = asset.FundCode,
                    Status = asset.Status.ToEnum<Entities.StagingStatus>(),
                    UserId = asset.CapturedUserId,
                    ModifiedDatetime = asset.ModifiedDateTime,
                    AssetClass = assetList

                });




            }

            return fundAssets;
        }

        public static List<Entities.FundPerformanceFees> FromFundPerformanceFeeStagings(List<FundPerformanceFeeStaging> fundPerformanceFeeStagings)
        {
            if (fundPerformanceFeeStagings == null || fundPerformanceFeeStagings.Count == 0)
                return new List<Entities.FundPerformanceFees>();

            var fundPerFeeList = new List<Entities.FundPerformanceFees>();

            var distinctFundCodes = fundPerformanceFeeStagings.Select(f => f.FundCode).Distinct();

            foreach (var fundCode in distinctFundCodes)
            {
                var performFees = fundPerformanceFeeStagings.Where(f => f.FundCode == fundCode).ToList();

                if (performFees.Count == 0)
                    continue;

                var performFeeList = new List<Entities.PerformanceFees>();

                foreach (var perFee in performFees)
                {
                    performFeeList.Add(new Entities.PerformanceFees
                    {
                        TimePeriod = perFee.TimePeriod.GetValueOrDefault(),
                        ClosePrice = (double)perFee.ClosePrice.GetValueOrDefault(),
                        Percentage = (double)perFee.FundPercentage.GetValueOrDefault(),
                        InstructionType = perFee.InstructionType.ToEnum<Entities.InstructionType>(),
                        Status = perFee.Status.ToEnum<Entities.StagingStatus>(),
                        UserId = perFee.CapturedUserId
                    });
                }

                var asset = performFees.First();

                fundPerFeeList.Add(new Entities.FundPerformanceFees
                {
                    FundCode = asset.FundCode,
                    PerformanceFees = performFeeList
                });
            }

            return fundPerFeeList;
        }

        public static Entities.FundTER FromFundTERStaging(FundTERStaging contextFundTER)
        {
            if (contextFundTER == null)
                return null;

            return new Entities.FundTER
            {
                FundCode = contextFundTER.FundCode,
                FundName = contextFundTER.FundName,
                TotalExpenseRatio = (double)contextFundTER.TotalExpenseRatio.GetValueOrDefault(),
                Status = contextFundTER.Status.ToEnum<Entities.StagingStatus>(),
                InstructionType = contextFundTER.InstructionType.ToEnum<Entities.InstructionType>(),
                UserId = contextFundTER.CapturedUserId,
                ModifiedDateTime = contextFundTER.ModifiedDateTime
            };
        }

        public static Entities.Regulation28Limits FromLimitStaging(Regulation28LimitsStaging contextLimit)
        {
            if (contextLimit == null)
                return null;

            return new Entities.Regulation28Limits
            {
                Code = contextLimit.Code,
                Name = contextLimit.Name,
                Value = contextLimit.Value.GetValueOrDefault(),
                Status = contextLimit.Status.ToEnum<Entities.StagingStatus>(),
                InstructionType = contextLimit.InstructionType.ToEnum<Entities.InstructionType>(),
                UserId = contextLimit.CapturedUserId,
                ModifiedDateTime = contextLimit.ModifiedDateTime
            };
        }

        public static Entities.FundMapping FromFundMappingStaging(FundMappingStaging contextMapping)
        {
            if (contextMapping == null)
                return null;

            return new Entities.FundMapping
            {
                FundCode = contextMapping.AIMSFundCode,
                FundName = contextMapping.FundName,
                MSISIN = contextMapping.MSISISN,
                MorningStarShareClassId = contextMapping.ShareClassId,
                Status = contextMapping.Status.GetValueOrDefault().ToEnum<Entities.StagingStatus>(),
                InstructionType = contextMapping.InstructionType.ToEnum<Entities.InstructionType>(),
                UserId = contextMapping.CapturedUserId,
                ModifiedDateTime = contextMapping.ModifiedDateTime
            };
        }

        public static Entities.ReductionInYield FromYieldStaging(ReductionInYieldStaging contextYield)
        {
            if (contextYield == null)
                return null;

            return new Entities.ReductionInYield
            {
                ProductCode = contextYield.ProductCode,
                ProductName = contextYield.ProductName,
                Status = contextYield.Status.ToEnum<Entities.StagingStatus>(),
                InstructionType = contextYield.InstructionType.ToEnum<Entities.InstructionType>(),
                UserId = contextYield.CapturedUserId,
                ModifiedDateTime = contextYield.ModifiedDateTime,
                Term = contextYield.Term.GetValueOrDefault(),
                AssumedGrossReturn = (double)contextYield.AssumedGrossReturn.GetValueOrDefault()
            };
        }

        public static Entities.FundFactSheet FromFundFactSheetStaging(FundFactSheetStaging contextFundFactSheet)
        {
            if (contextFundFactSheet == null)
                return null;

            return new Entities.FundFactSheet
            {
                FundCode = contextFundFactSheet.FundCode,
                FundName = contextFundFactSheet.FundName,
                FileName = contextFundFactSheet.FileName,
                FileData = contextFundFactSheet.FileData,
                Status = contextFundFactSheet.Status.ToEnum<Entities.StagingStatus>(),
                InstructionType = contextFundFactSheet.InstructionType.ToEnum<Entities.InstructionType>(),
                UserId = contextFundFactSheet.CapturedUserId,
                ModifiedDateTime = contextFundFactSheet.ModifiedDateTime
            };
        }

        public static Entities.FundManagementFees FromFundManagementFeesStaging(FundManagementFeeStaging contextFundManagementFeeStaging)
        {
            if (contextFundManagementFeeStaging == null)
                return null;

            return new Entities.FundManagementFees
            {
                FundCode = contextFundManagementFeeStaging.FundCode,
                FundName = contextFundManagementFeeStaging.FundName,
                ManagementFee = (double)contextFundManagementFeeStaging.ManagementFee.GetValueOrDefault(),
                Status = contextFundManagementFeeStaging.Status.ToEnum<Entities.StagingStatus>(),
                InstructionType = contextFundManagementFeeStaging.InstructionType.ToEnum<Entities.InstructionType>(),
                UserId = contextFundManagementFeeStaging.CapturedUserId,
                ModifiedDateTime = contextFundManagementFeeStaging.ModifiedDateTime
            };
        }

        public static Entities.Validation FromValidationStaging(ValidationStaging contextValidationStaging)
        {
            if (contextValidationStaging == null)
                return null;

            return new Entities.Validation
            {
                Id = contextValidationStaging.Id,
                FieldName = contextValidationStaging.FieldName,
                Message = contextValidationStaging.MessageOriginal,
                MessageRevised = contextValidationStaging.MessageRevised,
                Status = contextValidationStaging.Status.ToEnum<Entities.StagingStatus>(),
                RevisedByUserId = contextValidationStaging.CapturedUserId,
                RevisionDate = contextValidationStaging.ModifiedDateTime
            };
        }

        public static Entities.TaxTables FromTaxTablesStaging(TaxTableStaging contextTaxTableStaging)
        {
            if (contextTaxTableStaging == null)
                return null;

            return new Entities.TaxTables
            {
                Id = contextTaxTableStaging.Id,
                MinimumAmount = (double)contextTaxTableStaging.TaxableAmount,
                MaximumAmount = (double)contextTaxTableStaging.IncomeAmount,
                RateAmount = (double)contextTaxTableStaging.RateAmount,
                RatePercent = (double)contextTaxTableStaging.RatePerc,
                Status = 1.ToEnum<Entities.StagingStatus>(),
                UserId = contextTaxTableStaging.UserId
            };
        }

        public static Entities.GuarFees FromGuarFeesStaging(GuarFeesStaging guarfees)
        {
            if (guarfees == null)
                return null;

            return new Entities.GuarFees
            {
                Type = guarfees.type,
                MinAmnt = Convert.ToDouble(guarfees.MinAmnt),
                MaxAmnt = Convert.ToDouble(guarfees.MaxAmnt),
                effrate = Convert.ToDouble(guarfees.effrate),
                startdate = Convert.ToDateTime(guarfees.startdate),
                enddate = Convert.ToDateTime(guarfees.enddate),
                tranchedate = Convert.ToDateTime(guarfees.tranchedate),

                absalifefee = Convert.ToDouble(guarfees.absalifefeeOriginal),
                aimsfee = Convert.ToDouble(guarfees.aimsfeeOriginal),
                TaxLossFee = Convert.ToDouble(guarfees.TaxLossFeeOriginal),

                Revisedabsalifefee = Convert.ToDouble(guarfees.absalifefeeRevised),
                Revisedaimsfee = Convert.ToDouble(guarfees.aimsfeeRevised),
                RevisedTaxLossFee = Convert.ToDouble(guarfees.TaxLossFeeRevised),

                acmbfee = Convert.ToDouble(guarfees.acmbfee),


                rsclevy = Convert.ToDouble(guarfees.rsclevy),
                ACMBRateNaca = Convert.ToDouble(guarfees.ACMBRateNaca),
                NACS = Convert.ToDouble(guarfees.NACS),
                Guarantor = guarfees.Guarantor,
                MaturityDate = Convert.ToDateTime(guarfees.MaturityDate),
                TradeNumber = guarfees.TradeNumber,
                GuaranteedTradeNumber = guarfees.GuaranteedTradeNumber,
                FirstIncPmtDate = Convert.ToDateTime(guarfees.FirstIncPmtDate),
                AbcapMaturity = Convert.ToDouble(guarfees.AbcapMaturity),
                AbcapAnnuity = Convert.ToDouble(guarfees.AbcapAnnuity),
                Capturer = guarfees.CapturedUserId,
                Captured = Convert.ToDateTime(guarfees.Captured),
                Authorizer = guarfees.Authorizer,
                Authorized = Convert.ToDateTime(guarfees.Authorized),
                Status = guarfees.Status.ToEnum<Entities.StagingStatus>(),
                Modifiedby = guarfees.modifiedbyUserID,
                ModifiedDateTime = Convert.ToDateTime(guarfees.ModifiedDateTime)
            };
        }

        public static GuarFeesStaging ToGuarFeesStaging(Entities.GuarFees guarfees)
        {
            if (guarfees == null)
                return null;

            return new GuarFeesStaging
            {
                type = guarfees.Type,
                MinAmnt = guarfees.MinAmnt,
                MaxAmnt = guarfees.MaxAmnt,
                effrate = guarfees.effrate,
                startdate = guarfees.startdate,
                enddate = guarfees.enddate,
                tranchedate = guarfees.tranchedate,

                absalifefeeOriginal = guarfees.Revisedabsalifefee,
                aimsfeeOriginal = guarfees.Revisedaimsfee,
                TaxLossFeeOriginal = guarfees.RevisedTaxLossFee,

                absalifefeeRevised = guarfees.absalifefee,
                aimsfeeRevised = guarfees.aimsfee,
                TaxLossFeeRevised = guarfees.TaxLossFee,

                acmbfee = guarfees.acmbfee,

                rsclevy = guarfees.rsclevy,
                ACMBRateNaca = guarfees.ACMBRateNaca,
                NACS = guarfees.NACS,
                Guarantor = guarfees.Guarantor,
                MaturityDate = guarfees.MaturityDate,
                TradeNumber = guarfees.TradeNumber,
                GuaranteedTradeNumber = guarfees.GuaranteedTradeNumber,
                FirstIncPmtDate = guarfees.FirstIncPmtDate,

                AbcapMaturity = guarfees.AbcapMaturity,
                AbcapAnnuity = guarfees.AbcapAnnuity,

                CapturedUserId = guarfees.Capturer,
                Captured = guarfees.Captured,

                Authorizer = guarfees.Authorizer,
                Authorized = guarfees.Authorized,

                Status = (int)guarfees.Status,

                UserID = guarfees.Capturer,
                modifiedbyUserID = guarfees.Modifiedby,
                ModifiedDateTime = guarfees.ModifiedDateTime
            };
        }

        public static FundZeroFeeStaging ToFundZeroFeeStaging(Entities.FundZeroFee fundZeroFee)
        {
            if (fundZeroFee == null)
                return null;

            return new FundZeroFeeStaging
            {
                FundId = fundZeroFee.FundId,
                AIMSInitialFee = fundZeroFee.AIMSInitialFee,
                AIMSOngoingFee = fundZeroFee.AIMSOngoingFee,
                AIMSRecurringFee = fundZeroFee.AIMSRecurringFee,
                FAInitialFee = fundZeroFee.FAInitialFee,
                FAOngoingFee = fundZeroFee.FAOngoingFee,
                FARecurringFee = fundZeroFee.FARecurringFee,
                EACAdminFee = fundZeroFee.EACAdminFee,
                Status = (int)fundZeroFee.Status,
                InstructionType = (int)fundZeroFee.InstructionType,
                CapturedUserId = fundZeroFee.ModifiedUserId,
                ModifiedUserId = fundZeroFee.ModifiedUserId,
                ModifiedDateTime = fundZeroFee.ModifiedDateTime
            };
        }

        public static Entities.FundZeroFee FromFundZeroFeeStaging(FundZeroFeeStaging fundZeroFee)
        {
            if (fundZeroFee == null)
                return null;

            return new Entities.FundZeroFee

            {
                FundId = fundZeroFee.FundId,
                AIMSInitialFee = Convert.ToBoolean(fundZeroFee.AIMSInitialFee),
                AIMSOngoingFee = Convert.ToBoolean(fundZeroFee.AIMSOngoingFee),
                AIMSRecurringFee = Convert.ToBoolean(fundZeroFee.AIMSRecurringFee),
                FAInitialFee = Convert.ToBoolean(fundZeroFee.FAInitialFee),
                FAOngoingFee = Convert.ToBoolean(fundZeroFee.FAOngoingFee),
                FARecurringFee = Convert.ToBoolean(fundZeroFee.FARecurringFee),
                EACAdminFee = Convert.ToBoolean(fundZeroFee.EACAdminFee),
                Status = fundZeroFee.Status.ToEnum<Entities.StagingStatus>(),
                InstructionType = fundZeroFee.InstructionType.ToEnum<Entities.InstructionType>(),
                CapturedUserId = fundZeroFee.CapturedUserId,
                ModifiedUserId = fundZeroFee.ModifiedUserId,
                ModifiedDateTime = fundZeroFee.ModifiedDateTime
            };
        }

        public static Entities.FundMinimum FromFundMinimumStaging(FundMinimumStaging fundMinimum)
        {
            if (fundMinimum == null)
                return null;

            return new Entities.FundMinimum
            {
                FundCode = fundMinimum.FundId,
                FundName = fundMinimum.FundName,
                ProductId = fundMinimum.ProductId,
                ProductName = fundMinimum.ProductName,
                FundMinimumAmount = fundMinimum.Amount,
                TransactionDesc = fundMinimum.TransactionDescription,
                TransactionTypeId = fundMinimum.TransactionTypeId,
                Status = fundMinimum.Status.ToEnum<Entities.StagingStatus>(),
                InstructionType = fundMinimum.InstructionType.ToEnum<Entities.InstructionType>(),
                CapturedUserId = fundMinimum.CapturedUserId,
                ModifiedUserId = fundMinimum.ModifiedUserId
            };
        }


        public static Entities.FundTIC FromFundTICStaging(FundTICStaging contextFundTIC)
        {
            if (contextFundTIC == null)
                return null;

            return new Entities.FundTIC
            {
                FundCode = contextFundTIC.FundCode,
                FundName = contextFundTIC.FundName,
                TIC = (double)contextFundTIC.TIC.GetValueOrDefault(),
                Status = Convert.ToInt32(contextFundTIC.Status).ToEnum<Entities.StagingStatus>(),
                //InstructionType = contextFundTIC.InstructionType.ToEnum<Entities.InstructionType>(),
                UserId = contextFundTIC.CapturedUserId,
                ModifiedDateTime = contextFundTIC.ModifiedDateTime
            };
        }

        public static Entities.FundSecurityFees FromFundSecurityFeesStaging(FundSecurityFeesStaging contextFundSecurityFees)
        {
            if (contextFundSecurityFees == null)
                return null;

            return new Entities.FundSecurityFees
            {
                FundCode = contextFundSecurityFees.FundCode,
                FundName = contextFundSecurityFees.FundName,
                Year1 = (double)contextFundSecurityFees.Year1.GetValueOrDefault(),
                Year3 = (double)contextFundSecurityFees.Year3.GetValueOrDefault(),
                Year5 = (double)contextFundSecurityFees.Year5.GetValueOrDefault(),
                Year10 = (double)contextFundSecurityFees.Year10.GetValueOrDefault(),
                Status = Convert.ToInt32(contextFundSecurityFees.Status).ToEnum<Entities.StagingStatus>(),
                //InstructionType = contextFundTIC.InstructionType.ToEnum<Entities.InstructionType>(),
                UserId = contextFundSecurityFees.CapturedUserId,
                ModifiedDateTime = contextFundSecurityFees.ModifiedDateTime
            };
        }

        #endregion
    }
}
