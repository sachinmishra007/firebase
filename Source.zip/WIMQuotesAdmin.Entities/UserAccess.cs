﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Entities
{
    public class UserAccess
    {
        public UserAccess()
        {
            MenuItems = new List<MenuItem>();
        }

        public string UserId { get; set; }
        public List<MenuItem> MenuItems { get; set; }
    }
}
