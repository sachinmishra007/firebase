﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class FundMinimumController : ApiController
    {
        #region Constructors

        private readonly Domain.Logic.Contracts.IFundMinimumLogic _fundMinimumLogic;

        public FundMinimumController(Domain.Logic.Contracts.IFundMinimumLogic fundMinimumLogic)
        {
            _fundMinimumLogic = fundMinimumLogic;
        }

        #endregion

        // GET api/FundMinimum
        public List<Entities.FundMinimum> Get()
        {
            return _fundMinimumLogic.GetFundMinimumAmounts();
        }

        // GET api/FundMinimum/GetPendingFundMinimum
        [Route("api/FundMinimum/GetPendingFundMinimum")]
        public List<Entities.FundMinimum> GetPendingFundMinimum()
        {
            return _fundMinimumLogic.GetPendingFundMinimumAmounts();
        }

        // POST api/FundMinimum
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void Post([FromBody]Entities.FundMinimum fundMinimum, [ModelBinder]IPrincipal user)
        {
            if (fundMinimum == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundMinimumLogic.StageFundMinimum(fundMinimum, user.Identity.Name);
        }

        [HttpPost]
        [Route("api/FundMinimum/UpdatePendingStatuses")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingFundTERsUpdateStatus([FromBody]List<Entities.FundMinimum> fundMinimum, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (fundMinimum == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundMinimumLogic.PendingFundMinimumUpdateStatus(fundMinimum, user.Identity.Name);
        }

        //  GET api/FundMinimum/GetProducts
        [Route("api/FundMinimum/GetProducts")]
        public List<Entities.Product> GetProducts()
        {
            return _fundMinimumLogic.GetProducts();
        }


        [Route("api/FundMinimum/GetFunds/{productId}")]
        public List<Entities.FundMinimum> GetFunds(string productId)
        {
            return _fundMinimumLogic.GetFunds(productId);
        }

      
        // GET api/FundMinimum/GetTransactionType/{productId}/{fundId}
        [Route("api/FundMinimum/GetTransactionType")]
        public List<Entities.FundMinimum> GetTransactionType(string productId, string fundId)
        {
            return _fundMinimumLogic.GetTransactionType(productId, fundId);
        }


        [HttpPost]
        [Route("api/FundMinimum/AddNewFundMinimum")]
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void PendingFundTERsUpdateStatus([FromBody]Entities.FundMinimum fundMinimum, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (fundMinimum == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundMinimumLogic.AddNewFundMinimum(fundMinimum, user.Identity.Name);
        }
       
    }
}