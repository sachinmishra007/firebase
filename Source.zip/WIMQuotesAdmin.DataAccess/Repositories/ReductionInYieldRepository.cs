﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.Entities;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class ReductionInYieldRepository : Contracts.IReductionInYieldRepository
    {
        public List<Entities.ReductionInYield> GetReductionInYields()
        {
            using (var context = new SLAService.SLAMaintenanceClient())
            {
                var limits = context.GetReductionInYieldParameters();

                if (limits == null)
                    return null;

                return limits.Select(f => new Entities.ReductionInYield
                {
                    ProductCode = f.ProductCode,
                    ProductName = "",
                    Term = Convert.ToInt32(f.Term),
                    AssumedGrossReturn = f.AssumedGrossReturn,
                    Status = Entities.StagingStatus.Uncaptured
                }).ToList();
            }
        }

        public void StagingReductionInYields(Entities.ReductionInYield yield)
        {
            if (yield == null || string.IsNullOrWhiteSpace(yield.UserId))
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextLimits = Mappings.WIMQuotesAdminStagingMapping.ToYieldStaging(yield);

                if (contextLimits == null)
                    return;

                context.ReductionInYieldStagings.Add(contextLimits);
                context.SaveChanges();
            }
        }

        public List<Entities.ReductionInYield> GetPendingReductionInYields()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.ReductionInYieldStagings
                    .Where(f => f.Status == (int)Entities.StagingStatus.PendingAuthorise)
                    .Select(Mappings.WIMQuotesAdminStagingMapping.FromYieldStaging).ToList();
            }
        }

        public Entities.ReductionInYield GetPendingReductionInYield(string productCode)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.ReductionInYieldStagings
                    .Where(f => f.Status == (int)Entities.StagingStatus.PendingAuthorise && f.ProductCode == productCode)
                    .Select(Mappings.WIMQuotesAdminStagingMapping.FromYieldStaging)
                    .FirstOrDefault();
            }
        }

        public void PendingReductionInYieldUpdateStatus(string code, Entities.StagingStatus status, string userId)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextLimits = context.ReductionInYieldStagings
                    .Where(f => f.ProductCode == code &&
                                f.Status == (int)Entities.StagingStatus.PendingAuthorise);

                foreach (var contextLimit in contextLimits)
                {
                    contextLimit.Status = (int)status;
                    contextLimit.ModifiedUserId = userId;
                    contextLimit.ModifiedDateTime = DateTime.Now;
                }

                context.SaveChanges();
            }
        }

        public void SaveAuthorisedLimit(Entities.ReductionInYield yield)
        {
            if (yield == null)
                return;

            using (var context = new SLAService.SLAMaintenanceClient())
            {
                context.SaveReductionInYield(new SLAService.ReductionInYieldParameter{AssumedGrossReturn = yield.AssumedGrossReturn, ProductCode = yield.ProductCode, Term = yield.Term.ToString()});
            }
        }
    }
}
