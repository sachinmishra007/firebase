﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Entities
{
    public class UserAccessControlReport
    {
        public DateTime ActivityTimeStamp { get; set; }
        public string SuperUserId { get; set; }
        public string UserImpacted { get; set; }
        public string Activity { get; set; }
        public string UserRoleAssigned { get; set; }
    }
}
