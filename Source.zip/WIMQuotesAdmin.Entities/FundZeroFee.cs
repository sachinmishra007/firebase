﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;

namespace WIMQuotesAdmin.Entities
{
    public class FundZeroFee
    {
        public string FundId { get; set; }
        public bool AIMSInitialFee { get; set; }
        public bool AIMSOngoingFee { get; set; }
        public bool AIMSRecurringFee { get; set; }
        public bool FAInitialFee { get; set; }
        public bool FAOngoingFee { get; set; }
        public bool FARecurringFee { get; set; }
        public bool EACAdminFee { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public StagingStatus Status { get; set; }
       

        public string CapturedUserId { get; set; }
        public string ModifiedUserId { get; set; }
        public Nullable<System.DateTime> ModifiedDateTime { get; set; }

        public InstructionType InstructionType { get; set; }

    }
}
