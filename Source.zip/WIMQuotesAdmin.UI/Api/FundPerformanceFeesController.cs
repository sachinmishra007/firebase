﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class FundPerformanceFeesController : ApiController
    {
        #region Constructor
        private readonly Domain.Logic.Contracts.IFundPerformanceFeesLogic _fundPerformanceFeesLogic;
        public FundPerformanceFeesController(Domain.Logic.Contracts.IFundPerformanceFeesLogic fundPerformanceFeesLogic)
        {
            _fundPerformanceFeesLogic = fundPerformanceFeesLogic;
        }
        #endregion
        [Route("api/FundPerformanceFees/{fundCode}")]
        public Entities.FundPerformanceFees Get(string fundCode)
        {
            return _fundPerformanceFeesLogic.GetFundPerformanceFees(fundCode);
        }

        [Route("api/FundPerformanceFees/GetAvailableFunds")]
        public IEnumerable<Entities.Fund> GetAvailableFunds()
        {
            return _fundPerformanceFeesLogic.GetAvailableFunds();
        }
       
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        //[Route("api/FundPerformanceFees")]
        public void Post([FromBody] Entities.PerformanceFees performanceFees, string fundCode,  [ModelBinder]IPrincipal user)
        {
            if (performanceFees == null || string.IsNullOrWhiteSpace(fundCode) || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;
            _fundPerformanceFeesLogic.SaveFundPerformanceFeesStaging(performanceFees, fundCode, user.Identity.Name);
        }

        [Route("api/FundPerformanceFees/UnmappedFunds")]
        public List<Entities.Fund> GetUnmappedFunds()
        {
            return _fundPerformanceFeesLogic.GetUnmappedFunds();
        }

        [Route("api/FundPerformanceFees/TimePeriod/{fundCode}")]
        public List<Entities.TimePeriod> GetMorningStarTimePeriod(string fundCode)
        {
            return _fundPerformanceFeesLogic.GetMorningStarTimePeriod(fundCode);
        }

        [Route("api/FundPerformanceFees/Pending")]
        public List<Entities.FundPerformanceFees> GetPendingFundPerformanceFees()
        {
            return _fundPerformanceFeesLogic.GetPendingFundPerformanceFees();
        }

        [Route("api/FundPerformanceFees/UpdatePendingFundPerformanceFeesStatus")]
        public void PendingFundPerformanceFeesUpdateStatus([FromBody]List<Entities.FundPerformanceFees> fundPerformanceFees, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (fundPerformanceFees == null || fundPerformanceFees.Count == 0 || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundPerformanceFeesLogic.PendingFundPerformanceFeesUpdateStatus(fundPerformanceFees, user.Identity.Name);
 
        }
    }
}