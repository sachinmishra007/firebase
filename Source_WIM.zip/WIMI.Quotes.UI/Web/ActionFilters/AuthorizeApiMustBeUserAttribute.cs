﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace WIMI.Quotes.UI.Web.ActionFilters
{
    public class AuthorizeApiMustBeUserAttribute : ActionFilterAttribute
    {
        #region Constructor And Private Members

        private readonly string _roleCode;
        private readonly string _actionArgumentName;

        public AuthorizeApiMustBeUserAttribute(string roleCode, string actionArgumentName)
        {
            _roleCode = roleCode;
            _actionArgumentName = actionArgumentName;
        }

        #endregion

        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            var principal = actionContext.RequestContext.Principal;

            if (principal == null || !principal.Identity.IsAuthenticated ||
                !actionContext.ActionArguments.ContainsKey(_actionArgumentName))
            {
                actionContext.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                return;
            }

            var parameter = actionContext.ActionArguments[_actionArgumentName].ToString();

            if (string.IsNullOrEmpty(parameter))
            {
                actionContext.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                return;
            }

            if (principal.IsInRole(_roleCode) && !principal.Identity.Name.Trim().Equals(parameter.Trim(), StringComparison.InvariantCultureIgnoreCase))
            {
                actionContext.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                return;
            }

            base.OnActionExecuting(actionContext);
        }
    }
}