﻿using System;
using System.Collections.Generic;
using System.Linq;
using WIMQuotesAdmin.Domain.Logic.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class FundManagementFeesLogic : IFundManagementFeesLogic
    {
        #region Constructors

        private readonly DataAccess.Repositories.Contracts.IFundManagementFeesRepository _fundManagementFeesRepository;

        public FundManagementFeesLogic(DataAccess.Repositories.Contracts.IFundManagementFeesRepository fundManagementFeesRepository)
        {
            _fundManagementFeesRepository = fundManagementFeesRepository;
        }

        #endregion

        public List<Entities.FundManagementFees> GetFundManagementFees(Entities.FundType fundType, string fundCode)
        {
            var fundManageFees = _fundManagementFeesRepository.GetFundManagementFees(fundType, fundCode);
            var pendingFundManageFees = _fundManagementFeesRepository.GetPendingFundManagementFees();

            if (pendingFundManageFees == null || pendingFundManageFees.Count == 0)
                return fundManageFees;

            foreach (var pendingFundManageFee in pendingFundManageFees)
            {
                var fundManageFee = fundManageFees.FirstOrDefault(f => f.FundCode == pendingFundManageFee.FundCode);

                if (fundManageFee == null)
                    continue;

                fundManageFee.Status = pendingFundManageFee.Status;
                fundManageFee.UserId = pendingFundManageFee.UserId;
                fundManageFee.ModifiedDateTime = pendingFundManageFee.ModifiedDateTime;
            }

            return fundManageFees;
        }

        public void StageFundManagementFees(Entities.FundManagementFees fundManagementFees, string userId)
        {
            if (fundManagementFees == null || string.IsNullOrWhiteSpace(userId))
                return;

            fundManagementFees.Status = Entities.StagingStatus.PendingAuthorise;
            fundManagementFees.UserId = userId;
            fundManagementFees.ModifiedDateTime = DateTime.Now;

            _fundManagementFeesRepository.SaveFundManagementFeesToStaging(fundManagementFees);
        }


        public List<Entities.Fund> GetUnmappedFunds()
        {
            return _fundManagementFeesRepository.GetUnmappedFunds();
        }


        public List<Entities.FundManagementFees> GetPendingFundManagementFees()
        {
            return _fundManagementFeesRepository.GetPendingFundManagementFees();
        }


        public void PendingFundManagementFeesUpdateStatus(List<Entities.FundManagementFees> fundManagementFees, string userId)
        {
            if (fundManagementFees == null || fundManagementFees.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return ;

            foreach (var managementFee in fundManagementFees)
            {
                switch (managementFee.Status)
                {
                    case Entities.StagingStatus.Authorise:
                        PendingFundManagementFeesAuthorise(managementFee.FundCode, userId);
                        break;
                    case Entities.StagingStatus.Reject:
                        PendingFundManagementFeesReject(managementFee.FundCode, userId);
                        break;
                }

            }
        }

        #region Private Methods

        private void PendingFundManagementFeesAuthorise(string fundCode, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            var fundManageFee = _fundManagementFeesRepository.GetPendingFundManagementFees(fundCode);

            if (fundManageFee == null)
                return;

            switch (fundManageFee.InstructionType)
            {
                case Entities.InstructionType.Delete:
                    _fundManagementFeesRepository.DeleteAuthorisedFundManagementFees(fundManageFee.FundCode);
                    break;
                default:
                    _fundManagementFeesRepository.SaveAuthorisedFundManagementFees(fundManageFee);
                    break;
            }

            _fundManagementFeesRepository.UpdateFundManagementFeesStagingStatus(fundCode, Entities.StagingStatus.Authorise, userId);
        }

        private void PendingFundManagementFeesReject(string fundCode, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            _fundManagementFeesRepository.UpdateFundManagementFeesStagingStatus(fundCode, Entities.StagingStatus.Reject, userId);
        }
        #endregion
    }
}
