﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Helpers;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using System.Web.Mvc;

namespace WIMI.Quotes.UI.Web.ActionFilters
{
    /// <summary>
    /// Validates Anti Forgery Token embedded in an Http Requests Header i.e. in an Ajax Api Call
    /// </summary>
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
    public class ValidateApiAntiForgeryTokenAttribute : AuthorizationFilterAttribute
    {
        private const string RequestVerificationTokenKey = "X-RequestVerification-Token";

        public override void OnAuthorization(HttpActionContext actionContext)
        {
            HttpRequestMessage request = actionContext.ControllerContext.Request;

            try
            {
                ValidateRequestHeader(request);
            }
            catch (HttpAntiForgeryException)
            {
                actionContext.Response = request.CreateErrorResponse(HttpStatusCode.Forbidden, "Request verification invalid");
            }
        }

        private void ValidateRequestHeader(HttpRequestMessage request)
        {
            string cookieToken = String.Empty;
            string formToken = String.Empty;

            IEnumerable<string> tokenHeaders;

            if (!request.Headers.TryGetValues(RequestVerificationTokenKey, out tokenHeaders))
                throw new HttpAntiForgeryException();

            string tokenValue = tokenHeaders.FirstOrDefault();

            if (!String.IsNullOrEmpty(tokenValue))
            {
                string[] tokens = tokenValue.Split(':');

                if (tokens.Length == 2)
                {
                    cookieToken = tokens[0].Trim();
                    formToken = tokens[1].Trim();
                }
            }

            AntiForgery.Validate(cookieToken, formToken);
        }
    }
}