﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Entities
{
    public class FundSecurityFeesFile
    {
        public string FundCode { get; set; }

        public string FundName { get; set; }

        public double Year1 { get; set; }
        public double Year3 { get; set; }
        public double Year5 { get; set; }
        public double Year10 { get; set; }

        public string FileName { get; set; }

        public byte[] FileData { get; set; }
        public bool HasFileAvailable { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public StagingStatus Status { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public InstructionType InstructionType { get; set; }

        public string UserId { get; set; }

        public DateTime? ModifiedDateTime { get; set; }
    }
}
