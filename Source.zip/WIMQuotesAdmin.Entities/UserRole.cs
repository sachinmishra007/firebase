﻿namespace WIMQuotesAdmin.Entities
{
    public enum UserRole
    {
        SuperUser = 1,
        AdminUser = 2,
        ReadOnlyUser = 3
    }
}
