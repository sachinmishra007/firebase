﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('fundZeroFeeService', ['$http', function ($http)
        {
            var fundZeroFeeService = {};

            fundZeroFeeService.getFundZeroFee = function ()
            {
                return $http({ url: 'api/FundZeroFee' });
            };

            fundZeroFeeService.getFundWrapTypeList = function (fundType)
            {
                return $http({ url: 'api/FundZeroFee/GetFund/' + fundType });
            };

            fundZeroFeeService.saveFundZeroFee = function (FundZeroFee)
            {
                return $http.post('api/FundZeroFee', FundZeroFee);
            };

            fundZeroFeeService.getPendingFundZeroFee = function ()
            {
                return $http({ url: 'api/FundZeroFee/GetPendingFundZeroFee' });

            };
            fundZeroFeeService.updatePendingStatuses = function (FundZeroFee)
            {
                return $http.post('api/FundZeroFee/updatePendingStatuses', FundZeroFee);
            };
            fundZeroFeeService.addNewFund = function (saveNewFund)
            {
                return $http.post('api/FundZeroFee/addNewFund', saveNewFund);
            };
            

            return fundZeroFeeService;
        }]);
})();
