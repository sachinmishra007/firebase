﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('fundMappingService', ['$http', function ($http)
        {
            var fundMappingService = {};

            fundMappingService.getFundMappings = function ()
            {
                return $http({ url: 'api/FundMapping' });
            };

            fundMappingService.getPendingMappings = function ()
            {
                return $http({ url: 'api/FundMapping/Pending' });
            };

            fundMappingService.stageMappings = function (limit)
            {
                debugger;
                return $http.post('api/FundMapping/Stage', limit);
            };

            fundMappingService.updatePendingStatuses = function (limits)
            {
                return $http.post('api/FundMapping/UpdatePendingStatuses', limits);
            };

            fundMappingService.saveFundMapping = function (fundMapping)
            {
                return $http.post('api/FundMapping/Save', fundMapping);
            };

            fundMappingService.authoriseFundMappings = function (limits)
            {
                return $http.post('api/FundMapping/AuthoriseMappings', limits);
            };

            fundMappingService.rejectMappings = function (limits)
            {
                return $http.post('api/FundMapping/RejectMappings', limits);
            };

            fundMappingService.getUnmappedFunds = function ()
            {
                return $http({ url: 'api/FundMapping/GetUnmappedFunds' });
            };

            fundMappingService.deleteFundMapping = function ()
            {
                return $http({ url: 'api/FundMapping/DeleteFundMapping' });
            };

            fundMappingService.updateMSFundMapping = function (fundMapping) {
                return $http.post('api/FundMapping/UpdateMSRetrieve', fundMapping);
            };
            return fundMappingService;
        }]);
})();

