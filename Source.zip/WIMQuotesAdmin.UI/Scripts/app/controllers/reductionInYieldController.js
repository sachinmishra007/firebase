﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('reductionInYieldController', ['$scope', '$timeout', 'reductionInYieldService', function ($scope, $timeout, reductionInYieldService)
        {
            $scope.yieldList = [];
            $scope.pendingYieldList = [];

            $scope.limitNameFilter = '';
            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];

            $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' ||
                $scope.application.currentMenuItem.AccessLevel === 'AdminRights';

            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
            $scope.isViewVisible = false;


            // Private Methods

            var removePendingYield = function (fundCode)
            {
                for (var i = 0; i < $scope.pendingYieldList.length; i++)
                {
                    if ($scope.pendingYieldList[i].FundCode === fundCode)
                        $scope.pendingYieldList.splice(i, 1);
                }
            }

            var filteredLimitCount = function ()
            {
                var count = 0;

                for (var i = 0; i < $scope.yieldList.length; i++)
                {
                    if ($scope.filterYield($scope.yieldList[i]))
                        count++;
                }

                return count;
            };

            var retrieveYieldList = function ()
            {

                $scope.application.showLoading = true;
                reductionInYieldService.getReductionInYields().success(function (response)
                {
                    $scope.yieldList = response;
                    $scope.application.showLoading = false;
                });
            }

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 3000);
            }

            // On Load

            retrieveYieldList();

            if ($scope.isPendingVisible)
            {
                reductionInYieldService.getPendingYields().success(function (response)
                {
                    $scope.pendingYieldList = response;
                    $scope.isViewVisible = response.length === 0;
                });
            }
            else
            {
                $scope.isViewVisible = true;
            }


            // Behaviours

            $scope.filterYield = function (item)
            {
                return (item.ProductCode.toLowerCase().indexOf($scope.limitNameFilter.toLowerCase()) !== -1 ||
                    item.ProductName.toLowerCase().indexOf($scope.limitNameFilter.toLowerCase()) !== -1);
            };

            $scope.editYield = function (currentYield)
            {
                currentYield.OriginalValue = currentYield.AssumedGrossReturn;
                currentYield.OriginalTerm = currentYield.Term;
                currentYield.$editMode = true;
            };

            $scope.cancelEditYield = function (currentYield)
            {
                currentYield.AssumedGrossReturn = currentYield.OriginalValue;
                currentYield.Term = currentYield.OriginalTerm;
                currentYield.$editMode = false;
            };

            $scope.saveEditYield = function (currentYield)
            {
                $scope.application.showLoading = true;
                reductionInYieldService.stageReductionInYields(currentYield).success(function ()
                {
                    currentYield.Status = 'PendingAuthorise';
                    currentYield.$editMode = false;
                    $scope.application.showLoading = false;

                    showMessage('Reduction in Yield parameters saved successfully');
                });
            };

            $scope.updatePendingStatuses = function ()
            {
                $scope.application.showLoading = true;

                var pendingYields = [];

                for (var i = 0; i < $scope.pendingYieldList.length; i++)
                {
                    if ($scope.pendingYieldList[i].Status !== "PendingAuthorise")
                        pendingYields.push($scope.pendingYieldList[i]);
                }

                reductionInYieldService.updatePendingStatuses(pendingYields).success(function ()
                {
                    for (var i = 0; i < pendingYields.length; i++)
                    {
                        removePendingYield(pendingYields[i].FundCode);
                    }

                    showMessage("Selected Reduction in Yield parameters were updated successfully");

                    if ($scope.pendingYieldList.length === 0)
                    {
                        $scope.isViewVisible = true;
                        $scope.yieldList = [];
                        retrieveYieldList();
                    }

                    $scope.application.showLoading = false;
                });
            };

            $scope.setPendingYieldStatus = function (currentYield, status)
            {
                currentYield.Status = currentYield.Status !== status ? status : "PendingAuthorise";
            };

            $scope.anyPendingYieldSelected = function ()
            {
                for (var i = 0; i < $scope.pendingYieldList.length; i++)
                {
                    if ($scope.pendingYieldList[i].Status !== "PendingAuthorise")
                        return true;
                }

                return false;
            };

            // Pagination

            $scope.firstPage = function ()
            {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function ()
            {
                if ($scope.currentPage > 0)
                {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function ()
            {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function ()
            {
                return Math.ceil(filteredLimitCount() / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function ()
            {
                if ($scope.currentPage < $scope.pageCount())
                {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function ()
            {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function ()
            {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n)
            {
                $scope.currentPage = n;
            };

            $scope.range = function ()
            {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0)
                {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize)
                {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++)
                {
                    range.push(i);
                }

                return range;
            };
        }]);
})();