﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('fundPerformanceFeesController', ['$scope', '$timeout', 'fundPerformanceFeesService', function ($scope, $timeout, fundPerformanceFeesService)
        {

            $scope.fundList = [];
            $scope.fundPerformanceFees = [];
            $scope.fundPerformanceFeesList = [];
            $scope.pendingFundPerformanceFeesList = [];
            $scope.pendingFundPerformanceFeesListCopy = [];
            $scope.pendingPerformanceFeeList = [];
            $scope.UnmappedFundList = [];
            $scope.timePeriodList = [];

            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];

            $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' ||
               $scope.application.currentMenuItem.AccessLevel === 'AdminRights';

            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
            $scope.isViewVisible = false;


            // Private Methods

            var removePendingFundPerformanceFees = function (fundCode, performanceFeesList)
            {

                for (var i = 0 ; i < $scope.pendingFundPerformanceFeesList.length ; i++)
                {
                    if ($scope.pendingFundPerformanceFeesList[i].FundCode === fundCode)
                    {
                        for (var j = 0 ; j < $scope.pendingFundPerformanceFeesList[i].PerformanceFees.length ; j++)
                        {
                            for (var k = 0 ; k < performanceFeesList.length ; k++)
                            {


                                if ($scope.pendingFundPerformanceFeesList[i].PerformanceFees[j].TimePeriod === performanceFeesList[k].TimePeriod)
                                    $scope.pendingFundPerformanceFeesList[i].PerformanceFees.splice(j, 1);
                            }
                        }

                        if ($scope.pendingFundPerformanceFeesList[i].PerformanceFees.length === 0)
                            $scope.pendingFundPerformanceFeesList.splice(i, 1);
                    }
                }
            };

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 5000);
            }

            var getUnmappedFundList = function ()
            {

                fundPerformanceFeesService.getUnmappedFunds().success(function (response)
                {
                    $scope.UnmappedFundList = response;
                    //$scope.application.showLoading = false;
                });
            };


            /*
            
            var getTimePeriod = function (fundCode)
            {
               
                fundPerformanceFeesService.getTimePeriod(fundCode).success(function (response)
                {
                    $scope.timePeriodList = response;
                    //  $scope.application.showLoading = false;
                });
            };
            */
            var getAvailableFunds = function ()
            {

                fundPerformanceFeesService.getAvailableFunds().success(function (response)
                {

                    $scope.fundsList = response;
                    $scope.application.showLoading = false;
                });
            }

            var getFundPerformanceFeesForFund = function (fundCode)
            {

                if (typeof fundCode === "undefined" || fundCode === null || fundCode === "")
                {
                    return;
                }

                fundPerformanceFeesService.getFundPerformanceFees(fundCode).success(function (response)
                {
                    $scope.fundPerformanceFees = response;
                    $scope.fundPerformanceFeesList = response.PerformanceFees;
                });
            };

            // On Load

            $scope.application.showLoading = true;

            getAvailableFunds();
            // getUnmappedFundList();
            // getTimePeriod();
            if ($scope.isPendingVisible)
            {

                fundPerformanceFeesService.getPendingFundPerformanceFees().success(function (response)
                {

                    $scope.pendingFundPerformanceFeesList = response;
                    $scope.isViewVisible = response.length === 0;
                });
            }
            else
            {
                $scope.isViewVisible = true;
            }

            // Behaviors

            $scope.getTimePeriod = function (fundCode)
            {

                fundPerformanceFeesService.getTimePeriod(fundCode).success(function (response)
                {
                    $scope.timePeriodList = response;
                    //  $scope.application.showLoading = false;
                });
            };

            $scope.getFundPerformanceFeesForFund = function (fundCode)
            {

                if (typeof fundCode === "undefined" || fundCode === null || fundCode === "")
                {
                    return;
                }

                fundPerformanceFeesService.getFundPerformanceFees(fundCode).success(function (response)
                {
                    $scope.fundPerformanceFees = response;
                    $scope.fundPerformanceFeesList = response.PerformanceFees;
                });
            };

            $scope.editPerformanceFees = function (perfFees)
            {

                perfFees.OriginalClosePrice = perfFees.ClosePrice;
                perfFees.OriginalPercentage = perfFees.Percentage;
                perfFees.InstructionType = 'Update';
                perfFees.$editMode = true;
            };

            $scope.cancelEditPerformanceFees = function (perfFees)
            {

                perfFees.ClosePrice = perfFees.OriginalClosePrice;
                perfFees.Percentage = perfFees.OriginalPercentage;
                perfFees.$editMode = false;
            };

            $scope.openAddPerformanceFees = function ()
            {
                $scope.selectedUnmapFund = undefined;
                getUnmappedFundList();
                $scope.selectTimePeriod = undefined;
                $scope.newClosePrice = undefined;
                $scope.newPercentage = undefined;
                $scope.$addMode = true;
            }

            $scope.saveEditPerformanceFees = function (perfFees, fundCode)
            {

                perfFees.Status = 'PendingAuthorise';
                fundPerformanceFeesService.saveFundPerfomanceFees(perfFees, fundCode).success(function ()
                {

                    perfFees.$editMode = false;

                    showMessage("Fund Performance Fees Saved Successfully. Pending Authorisation.");

                });
            };

            $scope.deletePerformanceFees = function (perfFees, fundCode)
            {

                perfFees.InstructionType = 'Delete';
                perfFees.Status = 'PendingAuthorise';
                fundPerformanceFeesService.saveFundPerfomanceFees(perfFees, fundCode).success(function ()
                {

                    perfFees.$editMode = false;

                    showMessage("Fund Performance Fees set for Deletion. Pending Authorisation.");

                });
            };

            $scope.addPerformanceFeesCancel = function ()
            {
                $scope.selectedUnmapFund = undefined;
                $scope.selectTimePeriod = undefined;
                $scope.newClosePrice = undefined;
                $scope.newPercentage = undefined;
                $scope.$addMode = false;
            }

            $scope.addNewFundPerformanceeFee = function (selectedUnmapFund, selectTimePeriod, newClosePrice, newPercentage)
            {

                var performFee =
                    {
                        TimePeriod: selectTimePeriod.TimePeriodId,
                        ClosePrice: newClosePrice,
                        Percentage: newPercentage,
                        InstructionType: 'Add',
                        Status: 'PendingAuthorise'
                    }

                fundPerformanceFeesService.saveFundPerfomanceFees(performFee, selectedUnmapFund.Code).success(function ()
                {
                    performFee.Status = 'PendingAuthorise';
                    $scope.$addMode = false;
                    showMessage("Fund Performance Fees Saved Successfully. Pending Authorisation.");
                });
            };

            $scope.setPendingFundperformanceFeeStatus = function (performanceFee, status)
            {
                performanceFee.Status = performanceFee.Status !== status ? status : "PendingAuthorise";

            };

            $scope.anyPendingFundPerformanceFeeSelected = function ()
            {

                for (var i = 0; i < $scope.pendingFundPerformanceFeesList.length; i++)
                {
                    $scope.pendingPerformanceFeeList = $scope.pendingFundPerformanceFeesList[i].PerformanceFees;
                    for (var j = 0; j < $scope.pendingPerformanceFeeList.length; j++)
                    {

                        if ($scope.pendingPerformanceFeeList[j].Status !== "PendingAuthorise")
                            return true;
                    }

                }

                return false;
            };

            $scope.updatePendingFundPerformanceFeeStatus = function (performanceFee, fundCode)
            {

                $scope.application.showLoading = true;
                angular.copy($scope.pendingFundPerformanceFeesList, $scope.pendingFundPerformanceFeesListCopy);

                for (var i = 0; i < $scope.pendingFundPerformanceFeesListCopy.length; i++)
                {
                    $scope.pendingPerformanceFeeList = $scope.pendingFundPerformanceFeesListCopy[i].PerformanceFees;
                    $scope.pendingFundPerformanceFeesListCopy[i].PerformanceFees = [];

                    for (var j = 0; j < $scope.pendingPerformanceFeeList.length; j++)
                    {
                        if ($scope.pendingPerformanceFeeList[j].Status !== "PendingAuthorise")
                            $scope.pendingFundPerformanceFeesListCopy[i].PerformanceFees.push($scope.pendingPerformanceFeeList[j]);
                        else
                            $scope.pendingFundPerformanceFeesListCopy[i].PerformanceFees.splice(j, 1);
                    }

                    if ($scope.pendingFundPerformanceFeesListCopy[i].PerformanceFees.length === 0)
                        $scope.pendingFundPerformanceFeesListCopy.splice(i, 1);

                }

                fundPerformanceFeesService.updatePendingFundPerformanceFeesStatus($scope.pendingFundPerformanceFeesListCopy).success(function ()
                {

                    for (var i = 0 ; i < $scope.pendingFundPerformanceFeesListCopy.length ; i++)
                    {
                        removePendingFundPerformanceFees($scope.pendingFundPerformanceFeesListCopy[i].FundCode,
                            $scope.pendingFundPerformanceFeesListCopy[i].PerformanceFees)
                    }

                    showMessage("Selected Fund Performance Fees were updated successfully");
                    getAvailableFunds();

                    if ($scope.pendingFundPerformanceFeesList.length === 0)
                        $scope.isViewVisible = true;

                    $scope.application.showLoading = false;
                });
            };


            // Pagination

            $scope.firstPage = function ()
            {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function ()
            {
                if ($scope.currentPage > 0)
                {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function ()
            {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function ()
            {
                return Math.ceil(($scope.fundPerformanceFeesList || []).length / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function ()
            {
                if ($scope.currentPage < $scope.pageCount())
                {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function ()
            {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function ()
            {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n)
            {
                $scope.currentPage = n;
            };

            $scope.range = function ()
            {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0)
                {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize)
                {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++)
                {
                    range.push(i);
                }

                return range;
            };
        }]);
})();