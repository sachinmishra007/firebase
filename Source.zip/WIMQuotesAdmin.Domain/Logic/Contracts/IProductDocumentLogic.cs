﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IProductDocumentLogic
    {
        List<Entities.Product> GetProducts();

        Entities.File GetProductDocumentFile(string productCode, Entities.Language language,
            Entities.DocumentType documentType);

        bool CheckDocumentExists(string productCode, Entities.Language language, Entities.DocumentType documentType,
            Entities.Platform platform);
    }
}
