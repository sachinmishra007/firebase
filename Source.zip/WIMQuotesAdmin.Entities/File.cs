﻿namespace WIMQuotesAdmin.Entities
{
    public class File
    {
        public string Name { get; set; }
        public string FullQualifiedName { get; set; }
        public byte[] Data { get; set; }
    }
}
