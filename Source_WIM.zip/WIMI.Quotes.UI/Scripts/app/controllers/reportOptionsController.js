﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('reportOptionsController', ['$scope', 'quotesService', 'lookupService', 'fundService',
            function ($scope, quotesService, lookupService, fundService)
        {
            $scope.languageList = lookupService.getLanguages();


            // Private Methods

            var getFundFactSheetsList = function (quoteItem)
            {
                fundService.getFundFactSheetsList(quoteItem.QuoteNumber).success(function (data)
                {
                    quoteItem.FundFactSheets = data;
                });
            };


            // On Load

            $scope.init = function (quoteItem)
            {
               
                quoteItem.ReportOptions = quoteItem.ReportOptions || {};

                $scope.showAssetAllocations = !$scope.quoteItem.Product.IsGuaranteedProduct;
                $scope.showFundFactSheets = !$scope.quoteItem.Product.IsGuaranteedProduct;

                quoteItem.ReportOptions.IncludeRegulation28 = quoteItem.Product.IsRegulation28Required;

                if (!angular.isDefined(quoteItem.ReportOptions.Language))
                    quoteItem.ReportOptions.Language = $scope.languageList[0];

                if (!angular.isDefined(quoteItem.ReportOptions.ReportType))
                    quoteItem.ReportOptions.ReportType = "ShortQuote";
                
                if (typeof quoteItem.QuoteNumber !== "undefined" && quoteItem.QuoteNumber != null && quoteItem.QuoteNumber > -1)
                    getFundFactSheetsList(quoteItem);
            };


            // Behaviours

            $scope.generateQuoteReport = function (quoteItem)
            {
                
                $scope.application.showLoading = true;
                $scope.generateQuoteFailed = false;               

                var data = angular.copy(quoteItem.ReportOptions);
                data.QuoteItemId = quoteItem.QuoteItemId;
                data.Language = quoteItem.ReportOptions.Language.Code;

                quotesService.generateQuote(data).then(function (response)
                {
                    $scope.application.showLoading = false;

                    if (response.data.IsSuccess && angular.isNumber(response.data.QuoteNumber))
                    {
                        quoteItem.QuoteNumber = response.data.QuoteNumber;
                        quoteItem.$isGeneratedNew = true;

                        getFundFactSheetsList(quoteItem);

                        $scope.application.downloadFile('api/Report/' + response.data.QuoteNumber, true);
                    }
                    else
                    {
                        $scope.notification.show('Validation', response.data.Message);
                    }
                },
                function ()
                {
                    $scope.application.showLoading = false;
                    $scope.generateQuoteFailed = true;
                });
            };

            $scope.downloadQuoteReport = function(quoteNumber) 
            {
                if (angular.isNumber(quoteNumber))
                {
                    $scope.application.downloadFile('api/Report/' + quoteNumber, true);
                }
            };

        }]);

})();
