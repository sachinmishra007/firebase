﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.Entities;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IIncomeRatesLogic
    {
        IncomeRates CaptureRates(Entities.IncomeRates rates);
        void AutoriseRates(Entities.IncomeRates rates);
        Entities.IncomeRates GetLatestRates(string productCode);
        void RejectRates(string productCode);
    }
}
