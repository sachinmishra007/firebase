﻿
(function ()
{
    'use strict';

    angular.module('adminApp.services')
        .factory('cdsBreakdownService', ['$http', function ($http)
        {
            var cdsBreakdownService = {};
            
            cdsBreakdownService.getQuoteReports = function (dtoReportDetails)
            {
                debugger;
                return $http({ method: 'GET', url: 'api/CDSBreakdownReport/Get', params: dtoReportDetails });
            };


            return cdsBreakdownService;
        }]);
})();

    