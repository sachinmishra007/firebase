﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace WIMQuotesAdmin.UI.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();

            Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookieName, String.Empty)
            {
                Expires = DateTime.Now.AddYears(-1)
            });

            Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", "")
            {
                Expires = DateTime.Now.AddYears(-1)
            });

            return RedirectToAction("Index", "Login");
        }
    }
}