﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class QuoteFrequencyRepository : IQuoteFrequencyRepository
    {
        public List<Entities.QuoteFrequencyReport> GetQuoteFrequencyReport(DateTime startDate, DateTime endDate, string brokerCode)
        {
            if (startDate == null || endDate == null)
                return null;

            using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                var report = context.GetQuoteReports(startDate, endDate, brokerCode);

                return report.Select(r => new Entities.QuoteFrequencyReport 
                {
                    DateCreated = r.DateCreated,
                    BrokerCode = r.BrokerCode,
                    BrokerFullName = r.BrokerFullName,
                    BrokerHouse = r.BrokerHouse,
                    ProductName = r.ProductName,
                    QuoteNumber = r.QuoteNumber,
                    IsAddition = r.IsAddition,
                    IsLumpSum = r.IsLumpSum,
                    IsDebitOrder = r.IsDebitOrder,
                    IsIncome = r.IsIncome,
                    IsGrowth = r.IsGrowth,
                    IsCapital = r.IsCapital
                    //StartDate = DateTime.Now,
                    //EndDate = DateTime.Now,
                    //ReportType = Entities.GenerateReport.AllQuotes
                }).ToList();
            }
        }


        public List<Entities.Broker> GetBrokers(string searchTerm)
        {
            using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                var brokers = context.SearchBrokers(searchTerm);

                return brokers.Select(b => new Entities.Broker 
                {
                    BrokerCode = b.BrokerCode,
                    BrokerFullName = b.BrokerFullName
                }).ToList();
            }
        }

        public List<Entities.Broker> GetBrokerHouse(string searchTerm)
        {
            using (var context = new WIMQuotesApplicationService.WIMQuotesApplicationServiceClient())
            {
                var brokers = context.SearchBrokerHouse(searchTerm);

                return brokers.Select(b => new Entities.Broker
                {
                    BrokerCode = b.BrokerCode,
                    BrokerFullName = b.BrokerFullName
                }).ToList();
            }
        }
    }
}
