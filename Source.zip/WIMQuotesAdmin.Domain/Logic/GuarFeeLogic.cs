﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class GuarFeeLogic : Contracts.IGuarFee
    {
        #region Constructor

        private readonly IGuarFeeRepository _guarFeeRepository;

        public GuarFeeLogic(IGuarFeeRepository guarFeeRepository)
        {
            _guarFeeRepository = guarFeeRepository;
        }

        #endregion

        public List<Entities.GuarFees> GetGuarFees(Entities.GuarFeesType guarFeesType)
        {
            var guarFee = _guarFeeRepository.GetGuarFees(guarFeesType);
            var guarFeepending = GetPendingGuarFees();

            foreach (var pendingGuarFee in guarFeepending)
            {
                var guarfeesingle = from n in guarFee
                                    where n.Type == pendingGuarFee.Type && n.MinAmnt == pendingGuarFee.MinAmnt && n.startdate == pendingGuarFee.startdate
                                    select n;

                var guarfees = guarfeesingle.FirstOrDefault();

                if (guarfees != null)
                {
                    guarfees.Status = pendingGuarFee.Status;
                    guarfees.absalifefee = pendingGuarFee.Revisedabsalifefee;
                    guarfees.aimsfee = pendingGuarFee.Revisedaimsfee;
                    guarfees.TaxLossFee = pendingGuarFee.RevisedTaxLossFee;
                }
            }

            return guarFee;
        }

        public List<Entities.GuarFees> GetPendingGuarFees()
        {
            return _guarFeeRepository.GetPendingGuarFees();
        }

        public void StageGuarFees(Entities.GuarFees guarfees, string userId)
        {
            if (guarfees == null || string.IsNullOrWhiteSpace(userId))
                return;

            guarfees.Status = Entities.StagingStatus.PendingAuthorise;
            guarfees.Capturer = userId;
            guarfees.Captured = DateTime.Now;
            _guarFeeRepository.SaveGuarFeesStaging(guarfees);
        }

        public void PendingGuarFeesUpdateStatus(List<Entities.GuarFees> guarfees, string userId)
        {
            if (guarfees == null || guarfees.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return;

            foreach (var guarfee in guarfees)
            {
                switch (guarfee.Status)
                {
                    case Entities.StagingStatus.Authorise:
                        PendingGuarFeeAuthorise(guarfee.Type, guarfee.MinAmnt, guarfee.startdate, userId);
                        break;
                    case Entities.StagingStatus.Reject:
                        PendingGuarFeeReject(guarfee.Type, guarfee.MinAmnt, guarfee.startdate, userId);
                        break;
                }
            }
        }

        #region Private Methods

        private void PendingGuarFeeAuthorise(string type, double MinAmnt, DateTime startdate, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            _guarFeeRepository.GuarFeesStagingStatus(type, startdate, MinAmnt, Entities.StagingStatus.Authorise, userId);

            var guarfee = _guarFeeRepository.GetGuarFee(type, startdate, MinAmnt);

            if (guarfee == null)
                return;

            _guarFeeRepository.SaveAuthorisedGuarFees(guarfee);
        }

        private void PendingGuarFeeReject(string type, double MinAmnt, DateTime startdate, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            _guarFeeRepository.GuarFeesStagingStatus(type, startdate, MinAmnt, Entities.StagingStatus.Reject, userId);
        }

        #endregion
        
    }
}
