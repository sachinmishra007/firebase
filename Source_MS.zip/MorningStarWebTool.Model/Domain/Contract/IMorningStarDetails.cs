﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorningStarWebTool.Model.Domain.Contract
{
    public interface IMorningStarDetails
    {
        object GetMorningStarDetails(string ToolName);
    }
}
