﻿using System;
using System.Collections.Generic;
using WIMQuotesAdmin.Entities;
using System.Linq;


namespace WIMQuotesAdmin.Domain.Logic
{
    public class ValidationLogic : Contracts.IValidationLogic
    {
        private readonly WIMQuotesAdmin.DataAccess.Repositories.Contracts.IValidationRepository _validationRepository;

        public ValidationLogic(WIMQuotesAdmin.DataAccess.Repositories.Contracts.IValidationRepository validationRepository)
        {
            _validationRepository = validationRepository;
        }

        public List<Validation> GetUIValidations()
        {

            var validation = _validationRepository.GetUIValidations();
            var pendingValidation = _validationRepository.GetPendingValidation();
            if (pendingValidation == null || pendingValidation.Count == 0)
                return validation;

            foreach(var pendingVal in pendingValidation)
            {
                var valid = validation.FirstOrDefault(v => v.Id == pendingVal.Id);
                if (valid == null)
                    continue;

                valid.Status = pendingVal.Status;
                valid.RevisedByUserId = pendingVal.RevisedByUserId;
                valid.RevisionDate = pendingVal.RevisionDate;
            }


            return validation;
        }

        public void SaveValidationToStaging(Validation validation, string userId)
        {
            if (validation == null || string.IsNullOrWhiteSpace(userId))
                return;

            validation.Status = StagingStatus.PendingAuthorise;
            validation.RevisedByUserId = userId;
            validation.RevisionDate = DateTime.Now;
            _validationRepository.SaveValidationToStaging(validation);
        }


        public List<Validation> GetPendingValidation()
        {
            return _validationRepository.GetPendingValidation();
        }


        public void PendingValidationUpdateStatus(List<Validation> validations, string userId)
        {
            foreach(var valid in validations)
            {
                switch(valid.Status)
                {
                    case StagingStatus.Authorise:
                        PendingValidationAuthorise(valid, userId);
                        break;
                    case StagingStatus.Reject:
                      PendingValidationReject(valid, userId);
                        break;
                }
                    
            }
        }

        #region Private Methods

        private void PendingValidationAuthorise(Entities.Validation validation , string userId)
        {
            if (validation == null || string.IsNullOrWhiteSpace(userId))
                return;

            var valid = _validationRepository.GetPendinValidationById(validation.Id);
            if (valid == null)
                return;

            _validationRepository.SaveAuthorisedValidation(valid);
            _validationRepository.UpdateValidationStagingStatus(validation, Entities.StagingStatus.Authorise, userId);
 
        }

        private void PendingValidationReject(Entities.Validation validation, string userId)
        {
            if (validation == null || string.IsNullOrWhiteSpace(userId))
                return;
            _validationRepository.UpdateValidationStagingStatus(validation, Entities.StagingStatus.Reject, userId);

        }
        #endregion
    }
}
