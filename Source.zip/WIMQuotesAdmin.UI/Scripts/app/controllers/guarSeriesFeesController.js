﻿(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
    .controller('guarSeriesFeesController', ['$scope', '$timeout', 'lookupService', 'guarSeriesFeeService', function ($scope, $timeout, lookupService, guarSeriesFeeService)
    {
        $scope.editingGuarFee = undefined;
        $scope.guarGuarFees = [];
        $scope.pendingGuarFees = [];
        $scope.guarFeetypes = lookupService.getGuarFeesType();
        $scope.selectedGuarTypes = $scope.guarFeetypes[2];
        // $scope.$editMode = false;
        $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' || 
            $scope.application.currentMenuItem.AccessLevel === 'AdminRights';
        $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
        $scope.isViewVisible = false;
        $scope.pendingGuarFeesList = [];


        // Private Methods

        var removePendingGuarFee = function (type, startdate, minamt)
        {
            debugger;
            for (var i = 0; i < $scope.pendingGuarFeesList.length; i++)
            {
                if ($scope.pendingGuarFeesList[i].type === type && $scope.pendingGuarFeesList[i].startdate === startdate && $scope.pendingGuarFeesList[i].MinAmnt === minamt
                    && $scope.pendingGuarFeesList[i].Status !== "PendingAuthorise")
                    $scope.pendingGuarFeesList.splice(i, 1);
            }
        }

        var showMessage = function (message)
        {
            $scope.notificationMessage = message;
            $scope.showSuccessMessage = true;

            $timeout(function ()
            {
                $scope.showSuccessMessage = false;
            }, 3000);
        }

        // Behaviours

        $scope.getGuarseriesFee = function (guarType)
        {
            if (typeof guarType == "undefined" || guarType == null || guarType == "")
                return;
            $scope.application.showLoading = true;

            guarSeriesFeeService.getGuarFees(guarType).success(function (response)
            {
                $scope.guarGuarFees = response;
                $scope.application.showLoading = false;
            });
        };

        $scope.editGuarseriesFeeOpen = function (guarfees)
        {
            guarfees.Revisedabsalifefee = guarfees.absalifefee;
            guarfees.Revisedaimsfee = guarfees.aimsfee;
            guarfees.RevisedTaxLossFee = guarfees.TaxLossFee;
            //$scope.editingGuarFee = guarfees;
            guarfees.$editMode = true;
        };

        $scope.editGuarseriesFeeCancel = function (guarfees)
        {
            guarfees.absalifefee = guarfees.Revisedabsalifefee;
            guarfees.aimsfee = guarfees.Revisedaimsfee;
            guarfees.TaxLossFee = guarfees.RevisedTaxLossFee;
            guarfees.$editMode = false;
        };

        $scope.editGuarseriesFeeSave = function (guarfees)
        {
            guarSeriesFeeService.saveGuarFees(guarfees).success(function ()
            {
                guarfees.absalifefee = guarfees.absalifefee;
                guarfees.aimsfee = guarfees.aimsfee;
                guarfees.TaxLossFee = guarfees.TaxLossFee;
                guarfees.Status = 'PendingAuthorise';
                guarfees.$editMode = false;
            });
        };

        $scope.updatePendingGuarseriesFeeStatus = function ()
        {
            debugger;
            
            $scope.application.showLoading = true;

            var pendingGuarFee = [];

            for (var i = 0; i < $scope.pendingGuarFeesList.length; i++)
            {
                if ($scope.pendingGuarFeesList[i].Status !== "PendingAuthorise")
                    pendingGuarFee.push($scope.pendingGuarFeesList[i]);
            }

            guarSeriesFeeService.UpdatePendingGuarFeeStatus(pendingGuarFee).success(function ()
            {
                for (var i = 0; i < pendingGuarFee.length; i++)
                {
                    removePendingGuarFee(pendingGuarFee[i].type, pendingGuarFee[i].startdate, pendingGuarFee[i].MinAmnt);
                }

                showMessage("Selected GuarFee(s) were updated successfully");
                debugger;
                if ($scope.pendingGuarFeesList.length === 0)
                    $scope.isViewVisible = true;

                $scope.application.showLoading = false;
            });
        };

        $scope.setPendingGuarseriesFeeStatus = function (guarfees, status)
        {
            guarfees.Status = guarfees.Status !== status ? status : "PendingAuthorise";
        };

        $scope.anyPendingguarfeesSelected = function ()
        {
            for (var i = 0; i < $scope.pendingGuarFeesList.length; i++)
            {
                if ($scope.pendingGuarFeesList[i].Status !== "PendingAuthorise")
                    return true;
            }

            return false;
        };

        // On Load

        if ($scope.isPendingVisible)
        {
            guarSeriesFeeService.getPendingGuarfees().success(function (response)
            {
                debugger;
                $scope.pendingGuarFeesList = response;
                $scope.isViewVisible = response.length === 0;
            });
        }
        else
        {
            $scope.isViewVisible = true;
        }
    }]);
})();