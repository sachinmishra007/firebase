﻿using System;

namespace WIMQuotesAdmin.Common.Helpers
{
    public static class AuditHelper
    {
        public static void Log(string message)
        {
            Elmah.ErrorSignal.FromCurrentContext().Raise(new Exception(String.Format("Audit Log: {0}", message)));
        }

        public static void LogException(Exception ex)
        {
            Elmah.ErrorSignal.FromCurrentContext().Raise(ex);
        }
    }
}
