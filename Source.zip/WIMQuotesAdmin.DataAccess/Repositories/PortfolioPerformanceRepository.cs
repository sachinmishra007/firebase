﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class PortfolioPerformanceRepository : Contracts.IPortfolioPerformanceRepository
    {

        public Entities.FundAssets GetFundWithAssetClasses(string fundCode)
        {
            var assetClasses = GetFundAssetClasses(fundCode);
            var fundAssetClass = new Entities.FundAssets();
            fundAssetClass.FundCode = fundCode;
            fundAssetClass.AssetClass = assetClasses;

            return fundAssetClass;
        }

        public List<Entities.AssetClass> GetFundAssetClasses(string fundCode)
        {
            using (var context = new PortfolioPerformanceService.PortfolioPerformanceServiceClient())
            {
                var funds = new List<PortfolioPerformanceService.Fund>
                {
                    new PortfolioPerformanceService.Fund { Code = fundCode, PercentageSplit = 100.00m }
                };

                return context.GetFundAssetClasses(funds).Select(a => new Entities.AssetClass
                {
                    Id = a.Id,
                    Name = a.Name,
                    Value = a.Value
                }).ToList();
            }
        }

        public List<Entities.AssetClass> GetAssetClassesTypes()
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                return context.GetAssetClassesTypes().Select(al => new Entities.AssetClass
                {
                    Id = al.AssetClassTypeId,
                    Name = al.Description,
                    TimeStamp = al.TimeStamp,
                    Value = 0M
                }
                ).ToList();

            }
        }
        /*
        public void SaveFundAssetsStaging(string fundCode, List<Entities.AssetClass> assetClasses , string userId)
        {
            if (assetClasses == null || assetClasses.Count == 0 || fundCode == null || string.IsNullOrWhiteSpace(fundCode))
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundAssetClasses = Mappings.WIMQuotesAdminStagingMapping.ToFundAssetClassesStaging(fundCode,assetClasses,userId);

                if (contextFundAssetClasses == null)
                    return;

                context.FundAssetClassesStagings.AddRange(contextFundAssetClasses);
                context.SaveChanges();
            }
        }
        */
        public void SaveFundAssetsStaging(Entities.FundAssets fundAssets, string userId)
        {
            if (fundAssets == null || fundAssets.AssetClass == null || fundAssets.AssetClass.Count == 0)
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundAssetClasses = Mappings.WIMQuotesAdminStagingMapping.ToFundAssetClassesStaging(fundAssets, userId);

                if (contextFundAssetClasses == null)
                    return;

                context.FundAssetClassesStagings.AddRange(contextFundAssetClasses);
                context.SaveChanges();
            }
        }



        public List<Entities.FundAssets> GetPendingFundAssets()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundIMLs = context.FundAssetClassesStagings.Where(f => f.Status == (int)Entities.StagingStatus.PendingAuthorise).ToList();
                return Mappings.WIMQuotesAdminStagingMapping.FromFundAssetClassesStagings(contextFundIMLs);
            }
        }

        public void UpdateFundAssetsStagingStatus(string fundCode, Entities.StagingStatus status, string userId , int assetClasId)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundAssets = context.FundAssetClassesStagings.Where(
                    f => f.FundCode == fundCode && f.Status == (int)Entities.StagingStatus.PendingAuthorise && f.AssetClassTypeId == assetClasId);
                foreach (var contextFunAsset in contextFundAssets)
                {
                    contextFunAsset.Status = (int)status;
                    contextFunAsset.ModifiedUserId = userId;
                    contextFunAsset.ModifiedDateTime = DateTime.Now;
                }
                context.SaveChanges();
            }
        }

        public void SaveAuthorisedFundAsset(Entities.FundAssets fundAsset)
        {
            if (fundAsset == null)
                return;

            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.SaveFundAssets(Mappings.PortfolioAdminServiceMapping.ToFundAssets(fundAsset));
            }
        }

        public void DeleteAuthorisedFundAsset(Entities.FundAssets fundAsset)
        {
            if (fundAsset == null)
                return;

            using(var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.DeleteFundAssets(Mappings.PortfolioAdminServiceMapping.ToFundAssets(fundAsset));

            }
        }

        public Entities.FundAssets GetPendingFundAsset(string fundCode)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundAssets = context.FundAssetClassesStagings
                    .Where(f => f.FundCode == fundCode &&
                                f.Status == (int)Entities.StagingStatus.PendingAuthorise).ToList();

                var mappedFundAssets = Mappings.WIMQuotesAdminStagingMapping.FromFundAssetClassesStagings(contextFundAssets);
                return mappedFundAssets.Count == 0 ? null : mappedFundAssets.FirstOrDefault();
            }
        }

        public List<Entities.Fund> GetAvailableWraps()
        {
            using (var context = new PortfolioPerformanceService.PortfolioPerformanceServiceClient())
            {
                var wraps = context.GetAvailableWraps();

                return wraps.Select(w => new Entities.Fund
                {
                    Code = w.Code,
                    Name = w.Name
                }).ToList();
            }
        }

        public List<Entities.Fund> GetFundsForWrap(string wrapCode)
        {
            using (var context = new PortfolioPerformanceService.PortfolioPerformanceServiceClient())
            {
                var funds = context.GetFundsForWrap(wrapCode);

                return funds.Select(f => new Entities.Fund
                {
                    Code = f.Code,
                    Name = f.Name,
                    SplitPercentage = f.PercentageSplit
                }).ToList();
            }
        }

        public void SaveFundAssetsStaging(Entities.AssetClass assetClass, string fundCode, string userId)
        {
            if (assetClass == null || string.IsNullOrWhiteSpace(fundCode) || string.IsNullOrWhiteSpace(userId))
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundAssetClasses = Mappings.WIMQuotesAdminStagingMapping.ToFundAssetClassesStaging(assetClass, fundCode, userId);

                if (contextFundAssetClasses == null)
                    return;

                context.FundAssetClassesStagings.Add(contextFundAssetClasses);
                context.SaveChanges();
            }
        }

        public List<Entities.Fund> GetUnmappedFunds()
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var funds = context.GetUnmappedFundManagementFeesFund();
                return funds == null ? new List<Entities.Fund>() : funds.Select(Mappings.PortfolioAdminServiceMapping.FromFund).ToList();

            }
        }
    }
}
