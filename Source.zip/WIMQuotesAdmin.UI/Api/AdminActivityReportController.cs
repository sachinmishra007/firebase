﻿using System.Collections.Generic;
using System.Web.Http;

namespace WIMQuotesAdmin.UI.Api
{
    public class AdminActivityReportController : ApiController
    {
        #region Constructors

        private readonly Domain.Logic.Contracts.IAdminActivityReportLogic _adminActivityReportLogic;

        public AdminActivityReportController(Domain.Logic.Contracts.IAdminActivityReportLogic adminActivityReportLogic)
        {
            _adminActivityReportLogic = adminActivityReportLogic;
        }

        #endregion

        public List<Entities.AdminActivityReport> Get([FromUri]Entities.AdminActivityReportDetail details)
        {
            return _adminActivityReportLogic.GetAdminActivityReport(details);
        }
    }
}