﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('regulation28Controller', ['$scope', 'regulation28Service', function ($scope, regulation28Service)
        {
            $scope.regulation28 = undefined;


            // Private Methods

            var onPrePersist = $scope.$on('quoteDetails.onPrePersist', function (event, promises)
            {
                
                if (!$scope.profile.IsActive)
                    return;

                var complianceDetails = {
                    ClientNumber: $scope.application.selectedClient.ClientNumber,
                    ProductCode: $scope.quoteItem.Product.Code,                    
                    Type: $scope.profile.Type === 'LumpSum' && ($scope.quoteItem.additionProfile || {}).IsActive ? 'Addition' : 'NewBusiness',
                    Funds: $scope.profile.Funds
                }

                promises
                    .push(regulation28Service.checkCompliant(complianceDetails)
                    .success(function (response)
                    {
                        $scope.profile.IsRegulation28Compliant = response.IsOverallCompliant;
                        $scope.quoteItem.$valid = response.IsOverallCompliant;

                        $scope.regulation28 = response;
                    }));
            });


            // On Unload

            $scope.$on("$destroy", function ()
            {
                onPrePersist();
            });

        }]);
})();