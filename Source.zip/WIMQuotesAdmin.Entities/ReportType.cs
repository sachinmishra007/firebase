﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Entities
{
    public enum ReportType
    {
        AllQuotes = 0,
        BrokerHouse = 1,
        BrokerId = 2
    }
}
