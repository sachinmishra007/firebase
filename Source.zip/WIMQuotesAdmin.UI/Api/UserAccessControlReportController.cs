﻿using System.Collections.Generic;
using System.Web.Http;

namespace WIMQuotesAdmin.UI.Api
{
    public class UserAccessControlReportController : ApiController
    {
        private readonly Domain.Logic.Contracts.IUserAccessControlReportLogic _userAccessControlReportLogic;

        public UserAccessControlReportController(Domain.Logic.Contracts.IUserAccessControlReportLogic userAccessControlReportLogic)
        {
            _userAccessControlReportLogic = userAccessControlReportLogic;
        }

        [Route("api/UserAccessControlReport/Get")]
        public List<Entities.UserAccessControlReport> Get([FromUri]Entities.UserAccessControlReportDetail details)
        {
            return _userAccessControlReportLogic.GetUserAccessControlReportData(details);
        }

        [Route("api/UserAccessControlReport/GetRoles")]
        public List<Entities.User> GetUserRolesReport()
        {
            return _userAccessControlReportLogic.GetUserRolesReport();
        }

        [Route("api/UserAccessControlReport/GetRoleCounts")]
        public int[] GetUserRolesCounts()
        {
            return _userAccessControlReportLogic.GetUserRoleCount();
        }
    }
}