﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IWrapLogic
    {
        List<Entities.Fund> GetAvailableWraps();
        List<Entities.Fund> GetFundsForWrap(string wrapCode);
    }
}