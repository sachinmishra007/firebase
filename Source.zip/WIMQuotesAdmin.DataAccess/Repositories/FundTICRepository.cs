﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using System.Data.OleDb;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class FundTICRepository : Contracts.IFundTICRepository
    {
        private readonly string _connectionString = ConfigurationManager.ConnectionStrings["WIMQuotesAdminStaging"].ToString();

        public FundTICRepository()
        {
            //_connectionString = connectionString;
        }

        public void StageFundTICSheet(OleDbDataReader fundTIC, string userID) //
        {

            var dataTable = new DataTable();
            dataTable.Load(fundTIC);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {

                SqlBulkCopy bulkCopy =
                new SqlBulkCopy(connection,
                SqlBulkCopyOptions.TableLock |

                 SqlBulkCopyOptions.FireTriggers |

                SqlBulkCopyOptions.UseInternalTransaction,

            null
            );
                //set default table name 
                bulkCopy.DestinationTableName = "FundTICFile";
                connection.Open();


                bulkCopy.WriteToServer(dataTable);
                connection.Close();
            }


            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                context.pUpdateFundTICStatus((int?)Entities.StagingStatus.PendingAuthorise, userID);
            }

            //DataTable dt = fundTIC.GetSchemaTable();
            //dt.Rows = 

        }



        public void SaveAuthorisedFundTIC()
        {


            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.SaveFundTIC();
            }
        }



        public List<Entities.FundTIC> GetPendingFundTICs()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.FundTICStagings
                    .Where(f => f.Status == (int)Entities.StagingStatus.PendingAuthorise)
                    .Select(Mappings.WIMQuotesAdminStagingMapping.FromFundTICStaging)
                    .ToList();
            }
        }


        public void AutoriseRejectFundTIC(Entities.StagingStatus status, string userID)
        {
            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                context.pAuthoriseRejectFundTIC((int?)status, userID);
            }
        }

    }
}
