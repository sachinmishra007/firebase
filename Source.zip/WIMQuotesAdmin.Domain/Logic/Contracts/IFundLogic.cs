﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IFundLogic
    {
        List<Entities.Fund> Get();
    }
}
