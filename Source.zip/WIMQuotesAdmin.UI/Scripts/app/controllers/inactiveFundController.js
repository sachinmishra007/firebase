﻿
(function () {
    'use strict';

    angular.module('adminApp.controllers')
        .controller('inactiveFundController', ['$scope', '$timeout', 'inactiveFundService',
            function ($scope, $timeout, inactiveFundService) {
 
            $scope.inactiveFunds = [];
            $scope.showSuccessMessage = false;
            $scope.UnmappedFundList = [];
            $scope.newSelectedFund = {};

            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];
            $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' || $scope.application.currentMenuItem.AccessLevel === 'AdminRights';
            $scope.isbuttonVisible = true;
            $scope.isPaginiationVisible = true;
            $scope.showDetails = false;

            // Private Methods

            var retrieveMappingList = function () {
                $scope.application.showLoading = true;
                inactiveFundService.getInactiveFunds().success(function (response) {
                  
                    $scope.inactiveFunds = response;
                    $scope.application.showLoading = false;
                });
            }

            var filteredInactiveFundCount = function () {
                var count = 0;
                for (var i = 0; i < $scope.inactiveFunds.length; i++) {
                        count++;
                }

                return count;
            };

            var showMessage = function (message) {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function () {
                    $scope.showSuccessMessage = false;
                }, 3000);
            };

            var getUnmappedFundList = function () {
                inactiveFundService.getUnmappedFunds().success(function (response) {
                    $scope.UnmappedFundList = response;
                    //$scope.application.showLoading = false;
                });
            };


            // On Load

            retrieveMappingList();

            // Behaviours

            $scope.deleteInactiveFund = function (inactiveFund) {
                debugger;
                if (typeof inactiveFund === "undefined" || inactiveFund === null || inactiveFund.FundCode === "")
                    return;
                inactiveFund.InstructionType = 'Delete';
                inactiveFundService.deleteInactive(inactiveFund).success(function () {
                    //inactiveFund.$editMode = false;
                    showMessage('Fund Deleted successfully');

                    retrieveMappingList();
                });

                retrieveMappingList();
            };

            $scope.openAddunmappedFunds = function () {
                //$scope.selectedUnmapFund = undefined;
                getUnmappedFundList();
                //$scope.selectTimePeriod = undefined;
                //$scope.newClosePrice = undefined;
                //$scope.newPercentage = undefined;
                $scope.$addMode = true;
            }

            $scope.addInactiveFundCancel = function () {
                $scope.$addMode = false;
                $scope.showDetails = false;
            }

            $scope.addNewInactiveFund = function (selectedUnmapFund) {
                var newFund =
                    {
                        FundCode: selectedUnmapFund.FundCode,
                        FundName: selectedUnmapFund.FundName,
                        IsWrap:selectedUnmapFund.IsWrap,
                        InstructionType: 'Add',
                        Status: 'PendingAuthorise'
                    }

                inactiveFundService.addInactiveFund(newFund).success(function () {
            
                    getUnmappedFundList();
                    retrieveMappingList();
                    $scope.showDetails = false;
                    showMessage("New Inactive fund added successfully");
                });
            };

            $scope.showUnmappedFund = function () {
        
                $scope.showDetails = true;

            }

            // Pagination

            $scope.firstPage = function () {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function () {
                if ($scope.currentPage > 0) {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function () {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function () {
                return Math.ceil(filteredInactiveFundCount() / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function () {
                if ($scope.currentPage < $scope.pageCount()) {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function () {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function () {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n) {
                $scope.currentPage = n;
            };

            $scope.range = function () {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0) {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize) {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++) {
                    range.push(i);
                }

                return range;
            };

        }]);
})();