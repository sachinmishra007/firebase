﻿using System;
using System.Linq;
using WIMQuotesAdmin.Common.Extensions;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class AuthenticationRepository : Contracts.IAuthenticationRepository
    {
        public bool AuthenticateUser(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
                return false;

            using (var authService = new AuthenticationService.GenericAuthSoapClient())
            {
                //var auth = authService.Authenticate(username, password, "intranet");
                var auth = authService.FalseAuthenticate(username, password);

                //auth.Status = "SUCCESS";
                return auth != null && auth.Status == "SUCCESS";
            }
        }

        public Entities.UserRole? GetUserRole(string userId)
        {
            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                var result = context.pGetUser(userId).ToList();
                return result.Count == 0 ? (Entities.UserRole?)null : result.First().UserRoleCode.ToEnum<Entities.UserRole>();
            }
        }
    }
}
