﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class FundManagementFeesController : ApiController
    {
        #region Constructors

        private readonly Domain.Logic.Contracts.IFundManagementFeesLogic _fundManagementFeesLogic;

        public FundManagementFeesController(Domain.Logic.Contracts.IFundManagementFeesLogic fundManagementFeesLogic)
        {
            _fundManagementFeesLogic = fundManagementFeesLogic;
        }

        #endregion

        // GET api/FundManagementFees
        public List<Entities.FundManagementFees> Get(Entities.FundType fundType, string fundCode)
        {
            return _fundManagementFeesLogic.GetFundManagementFees(fundType, fundCode);
        }

        // POST api/FundTER
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void Post([FromBody]Entities.FundManagementFees fundManagementFees, [ModelBinder]IPrincipal user)
        {
            if (fundManagementFees == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundManagementFeesLogic.StageFundManagementFees(fundManagementFees, user.Identity.Name);
        }

        [Route("api/FundManagementFees/GetUnmappedFunds")]
        public IEnumerable<Entities.Fund> GetUnmappedFunds()
        {
            return _fundManagementFeesLogic.GetUnmappedFunds();
        }

        [Route("api/FundManagementFees/Pending")]
        public List<Entities.FundManagementFees> GetPendingFundManagementFees()
        {
            return _fundManagementFeesLogic.GetPendingFundManagementFees();
        }

        [HttpPost]
        [Route("api/FundManagementFees/UpdatePendingStatuses")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingFundTERsUpdateStatus([FromBody]List<Entities.FundManagementFees> fundManageFees, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (fundManageFees == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _fundManagementFeesLogic.PendingFundManagementFeesUpdateStatus(fundManageFees, user.Identity.Name);
        }
    }
}