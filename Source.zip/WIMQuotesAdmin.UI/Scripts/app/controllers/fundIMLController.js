﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('fundIMLController', ['$scope', '$timeout', 'fundIMLService', function ($scope, $timeout, fundIMLService)
        {
            $scope.fundsList = [];
            $scope.pendingFundIMLsList = [];
            $scope.fundIML = undefined;
            $scope.unmappedIMLs = [];
            $scope.assetStatus = undefined;

            $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' ||
                $scope.application.currentMenuItem.AccessLevel === 'AdminRights';

            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
            $scope.isViewVisible = false;


            // Private Methods

            var removePendingFundIML = function (fundCode)
            {
                for (var i = 0; i < $scope.pendingFundIMLsList.length; i++)
                {
                    if ($scope.pendingFundIMLsList[i].FundCode === fundCode)
                        $scope.pendingFundIMLsList.splice(i, 1);
                }
            }

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 3000);
            }


            // On Load

            $scope.application.showLoading = true;

            fundIMLService.getAvailableFunds().success(function (response)
            {
                $scope.fundsList = response;
                $scope.application.showLoading = false;
            });

            if ($scope.isPendingVisible)
            {
                fundIMLService.getPendingFundIMLs().success(function (response)
                {
                    $scope.pendingFundIMLsList = response;
                    $scope.isViewVisible = response.length === 0;
                });
            }
            else
            {
                $scope.isViewVisible = true;
            }


            // Behaviours

            $scope.getIMLsForFund = function (fundCode)
            {
                if (typeof fundCode === "undefined" || fundCode === null || fundCode === "")
                {
                    $scope.fundIMLs = undefined;
                    return;
                }

                $scope.unmappedIMLs = [];

                fundIMLService.getIMLsForFund(fundCode).success(function (response)
                {
                    $scope.fundIML = response;

                    fundIMLService.getUnmappedIMLsForFund(fundCode).success(function (response)
                    {
                        $scope.unmappedIMLs = response;
                    });
                });
            };

            $scope.addUnmappedIMLtoFund = function (iml)
            {
                for (var i = 0; i < $scope.unmappedIMLs.length; i++)
                {
                    if ($scope.unmappedIMLs[i].Code === iml.Code)
                    {
                        $scope.unmappedIMLs.splice(i, 1);
                    }
                }

                iml.$isNew = true;

                $scope.fundIML.IntendedMaximumLimits.push(iml);
                $scope.selectedIML = undefined;
                $scope.showAddFund = false;
            };

            $scope.cancelAddUnmappedIMLtoFund = function ()
            {
                $scope.selectedIML = undefined;
                $scope.showAddFund = false;
            };

            $scope.editIML = function (fundIML)
            {
                fundIML.OriginalValue = fundIML.Value;
                fundIML.$editMode = true;
            };

            $scope.cancelEditIML = function (fundIML)
            {
                fundIML.Value = fundIML.OriginalValue;
                fundIML.$editMode = false;
            };

            $scope.saveEditIML = function (fundIML)
            {
                fundIML.$editMode = false;
            };

            $scope.removeNewIML = function (fundIML)
            {
                
                for (var i = 0; i < $scope.fundIML.IntendedMaximumLimits.length; i++)
                {
                    if ($scope.fundIML.IntendedMaximumLimits[i].Code === fundIML.Code)
                        $scope.fundIML.IntendedMaximumLimits.splice(i, 1);
                }

                fundIML.Value = 0;

                $scope.unmappedIMLs.push(fundIML);
            };

            $scope.cancelFundIMLs = function ()
            {
                $scope.selectedFund = undefined;
                $scope.fundIML = undefined;
                $scope.unmappedIMLs = [];
            };

            $scope.updatePendingFundIMLStatus = function ()
            {
                $scope.application.showLoading = true;

                var pendingFundIMLs = [];

                for (var i = 0; i < $scope.pendingFundIMLsList.length; i++)
                {
                    if ($scope.pendingFundIMLsList[i].Status !== "PendingAuthorise")
                        pendingFundIMLs.push($scope.pendingFundIMLsList[i]);
                }

                fundIMLService.updatePendingFundIMLsStatus(pendingFundIMLs).success(function ()
                {
                    for (var i = 0; i < pendingFundIMLs.length; i++)
                    {
                        removePendingFundIML(pendingFundIMLs[i].FundCode);
                    }

                    showMessage("Selected Fund IML(s) were updated successfully");

                    if ($scope.pendingFundIMLsList.length === 0)
                        $scope.isViewVisible = true;

                    $scope.application.showLoading = false;
                });
            };

            $scope.setPendingFundIMLStatus = function (fundIML, status)
            {
                fundIML.Status = fundIML.Status !== status ? status : "PendingAuthorise";
            };

            $scope.anyPendingFundIMLSelected = function ()
            {
                for (var i = 0; i < $scope.pendingFundIMLsList.length; i++)
                {
                    if ($scope.pendingFundIMLsList[i].Status !== "PendingAuthorise")
                        return true;
                }

                return false;
            };

            $scope.saveFundIMLs = function ()
            {
                fundIMLService.saveFundIMLs($scope.fundIML).success(function ()
                {
                    $scope.fundIML.Status = 'PendingAuthorise';
                    showMessage('Intended Maximum Limits saved successfully');
                });
            };

        }]);
})();