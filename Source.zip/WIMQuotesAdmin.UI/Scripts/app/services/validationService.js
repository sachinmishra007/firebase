﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('validationService', ['$http', function ($http)
        {
            var validationService = {};

            validationService.getValidations = function ()
            {
                debugger;
                return $http({ url: 'api/Validation/' });
            };
            
            validationService.saveValidations = function (valid) {
                debugger;
                return $http.post('api/Validation', valid);
            };

            validationService.getPendingValidation = function () {
                return $http({ url: 'api/Validation/Pending' });
            };

            validationService.updatePendingStatuses = function (validList) {
                debugger;
                return $http.post('api/Validation/UpdatePendingStatuses', validList);
            };

            return validationService;
        }]);
})();

