﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IReductionInYieldRepository
    {
         List<Entities.ReductionInYield> GetReductionInYields();
         void StagingReductionInYields(Entities.ReductionInYield yield);
         List<Entities.ReductionInYield> GetPendingReductionInYields();
         Entities.ReductionInYield GetPendingReductionInYield(string productCode);
         void PendingReductionInYieldUpdateStatus(string code, Entities.StagingStatus status, string userId);
         void SaveAuthorisedLimit(Entities.ReductionInYield limit);
    }
}
