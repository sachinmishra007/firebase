﻿(function () {
    "use strict";

    angular.module('morningStar.controllers')
        .controller('MorningStarFund', ['$scope', 'MorningStarService',
            function ($scope, MorningStarService) {

                $scope.showLoading = true;
                $scope.FundSLAMapping;

                $scope.init = function () {
                    //Get fund SLA Mapping details
                    MorningStarService
                        .GetMornigStarFundMapping()
                        .success(function (data) {
                            $scope.FundSLAMapping = JSON.parse(data);

                            $scope.fundname = $scope.FundSLAMapping[0];
                            $scope.showLoading = false;
                        })
                        .error(function (error) {
                            console.log(error);
                        })
                };

                $scope.init();

            }]);
})();