﻿using System;
using System.Collections.Generic;
using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class UserLogic : Contracts.IUserLogic
    {
        #region Constructor

        private readonly IAuthenticationRepository _authenticationRepository;
        private readonly IQuoteAdminRepository _quoteAdminRepository;

        public UserLogic(
            IAuthenticationRepository authenticationRepository,
            IQuoteAdminRepository quoteAdminRepository)
        {
            _authenticationRepository = authenticationRepository;
            _quoteAdminRepository = quoteAdminRepository;
        }

        #endregion

        public bool AuthenticateUser(string username, string password)
        {
            if (String.IsNullOrWhiteSpace(username) || String.IsNullOrWhiteSpace(password))
                return false;

            return _authenticationRepository.AuthenticateUser(username, password);
        }

        public Entities.User GetUser(string userId)
        {
            if (string.IsNullOrWhiteSpace(userId) && IsValidUser(userId))
                return null;

            return new Entities.User
            {
                Id = userId,
                Role = GetUserRole(userId).GetValueOrDefault()
            };
        }

        public Entities.UserRole? GetUserRole(string userId)
        {
            return String.IsNullOrWhiteSpace(userId) ? null : _authenticationRepository.GetUserRole(userId);
        }

        public bool IsValidUser(string userId)
        {
            return GetUserRole(userId).HasValue; //TODO: Implement has access check
        }

        public Entities.UserAccess GetUserAccess(string userId)
        {
            return _quoteAdminRepository.GetUserAccess(userId);
        }

        public List<Entities.User> SearchUnmappedUsers(string searchTerm)
        {
            return _quoteAdminRepository.SearchUnmappedUsers(searchTerm);
        }

        public List<Entities.User> SearchExistingUsers(string searchTerm)
        {
            return _quoteAdminRepository.SearchExistingUsers(searchTerm);
        }

        public void SaveUser(Entities.User user, string currentSystemUser)
        {
            if (user == null || string.IsNullOrWhiteSpace(user.Id) || string.IsNullOrWhiteSpace(currentSystemUser))
                return;

            _quoteAdminRepository.SaveUser(user, currentSystemUser);
        }

        public void SaveUserAccess(Entities.UserAccess userAccess, string currentSystemUser)
        {
            if (userAccess == null || string.IsNullOrWhiteSpace(userAccess.UserId) || string.IsNullOrWhiteSpace(currentSystemUser))
                return;

            _quoteAdminRepository.SaveMenuItems(userAccess.MenuItems, userAccess.UserId, currentSystemUser);
        }

        public void DeleteUser(Entities.User user, string currentSystemUser)
        {
            if (user == null || string.IsNullOrWhiteSpace(user.Id) || string.IsNullOrWhiteSpace(currentSystemUser))
                return;

            _quoteAdminRepository.UpdateUserActive(user.Id, false, currentSystemUser);
        }
    }
}
