﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class Regulation28LimitsController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IRegulation28LimitLogic _regulation28LimitLimitsLogic;

        public Regulation28LimitsController(Domain.Logic.Contracts.IRegulation28LimitLogic regulation28LimitLimitsLogic)
        {
            _regulation28LimitLimitsLogic = regulation28LimitLimitsLogic;
        }

        #endregion

        // GET api/Regulation28Limits/GetRegulation28Limits
        [Route("api/Regulation28Limits/GetRegulation28Limits")]
        public List<Entities.Regulation28Limits> Get()
        {
            return _regulation28LimitLimitsLogic.Get();
        }

        // POST api/Regulation28Limits
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void Post([FromBody]Entities.Regulation28Limits limit, [ModelBinder]IPrincipal user)
        {
            if (limit == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _regulation28LimitLimitsLogic.StageLimit(limit, user.Identity.Name);
        }

        // GET api/Regulation28Limits/Pending
        [Route("api/Regulation28Limits/Pending")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public List<Entities.Regulation28Limits> GetPendingRegulation28Limits()
        {
            return _regulation28LimitLimitsLogic.GetPendingLimits();
        }

        // POST api/Regulation28Limits/UpdatePendingStatuses
        [HttpPost]
        [Route("api/Regulation28Limits/UpdatePendingStatuses")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public void PendingLimitsUpdateStatus([FromBody]List<Entities.Regulation28Limits> limits, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (limits == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

            _regulation28LimitLimitsLogic.PendingLimitUpdateStatus(limits, user.Identity.Name);
        }
    }
}
