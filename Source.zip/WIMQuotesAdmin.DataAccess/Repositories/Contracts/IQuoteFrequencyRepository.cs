﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IQuoteFrequencyRepository
    {
        List<Entities.QuoteFrequencyReport> GetQuoteFrequencyReport(DateTime startDate, DateTime endDate, string brokerCode);
        List<Entities.Broker> GetBrokers(string searchTerm);
        List<Entities.Broker> GetBrokerHouse(string searchTerm);
       
    }
}
