﻿using System.Collections.Generic;


namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IRegulation28Repository
    {
        
    }
}
