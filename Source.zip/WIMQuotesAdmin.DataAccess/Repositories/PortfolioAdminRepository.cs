﻿using System;
using System.Collections.Generic;
using System.Linq;
using WIMQuotesAdmin.DataAccess.PortfolioAdminService;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class PortfolioAdminRepository : Contracts.IPortfolioAdminRepository
    {
        public List<Entities.FundMapping> GetFundMappings()
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                return context.GetFundMappings().Select(f => new Entities.FundMapping
                {
                    MorningStarFundId = f.FundId,
                    MorningStarShareClassId = f.FundShareClassId,
                    FundCode = f.FundCode,
                    FundName = f.FundName,
                    MSISIN = f.MSISIN,
                    ModifiedDateTime = f.ModifiedDateTime,
                    IsFundIML = f.IsFundIML,
                    IsFundPerform = f.IsFundPerform,
                    IsFundManage = f.IsFundManage,
                    IsFundAssets = f.IsFundAssets,
                    IsFundFacts = f.IsFundFacts,
                    IsFundTER = f.IsFundTER
                }).ToList();
            }
        }

        public void SaveFundMapping(Entities.FundMapping fundMapping)
        {
            if (fundMapping == null)
                return;

            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.SaveFundMapping(new PortfolioAdminService.FundMapping
                {
                    FundId = fundMapping.MorningStarFundId,
                    FundShareClassId = fundMapping.MorningStarShareClassId,
                    FundCode = fundMapping.FundCode,
                    FundName = fundMapping.FundName,
                    MSISIN = fundMapping.MSISIN
                });
            }
        }

        public List<Entities.Fund> GetAssetClassesAvailableFunds()
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                return context.GetAssetClassesAvailableFunds().Select(f => new Entities.Fund
                {
                    Code = f.Code,
                    Name = f.Name
                }).ToList();
            }
        }

        public void StagingFundMapping(Entities.FundMapping mapping)
        {
            if (mapping == null || string.IsNullOrWhiteSpace(mapping.UserId))
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextMapping = Mappings.WIMQuotesAdminStagingMapping.ToFundMappingStaging(mapping);

                if (contextMapping == null)
                    return;

                context.FundMappingStagings.Add(contextMapping);
                context.SaveChanges();
            }
        }

        public List<Entities.FundMapping> GetPendingFundMappings()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.FundMappingStagings
                    .Where(f => f.Status == (int)Entities.StagingStatus.PendingAuthorise)
                    .Select(Mappings.WIMQuotesAdminStagingMapping.FromFundMappingStaging).ToList();
            }
        }

        public Entities.FundMapping GetPendingFundMapping(string code)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.FundMappingStagings
                    .Where(f => f.Status == (int)Entities.StagingStatus.PendingAuthorise && f.AIMSFundCode == code)
                    .Select(Mappings.WIMQuotesAdminStagingMapping.FromFundMappingStaging)
                    .FirstOrDefault();
            }
        }

        public void PendingFundMappingUpdateStatus(string code, Entities.StagingStatus status, string userId)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextLimits = context.FundMappingStagings
                    .Where(f => f.AIMSFundCode == code &&
                                f.Status == (int)Entities.StagingStatus.PendingAuthorise);

                foreach (var contextLimit in contextLimits)
                {
                    contextLimit.Status = (int)status;
                    contextLimit.ModifiedUserId = userId;
                    contextLimit.ModifiedDateTime = DateTime.Now;
                }

                context.SaveChanges();
            }
        }

        public void SaveAuthorisedFundMapping(Entities.FundMapping mapping)
        {
            if (mapping == null)
                return;

            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.SaveFundMapping(new FundMapping
                {
                    MSISIN = mapping.MSISIN,
                    FundName = mapping.FundName,
                    FundCode = mapping.FundCode,
                    FundShareClassId = mapping.MorningStarShareClassId
                });
            }
        }

        public List<Entities.Fund> GetUnmappedFunds()
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var funds = context.GetUnmappedFundManagementFeesFund();
                return funds == null ? new List<Entities.Fund>() : funds.Select(Mappings.PortfolioAdminServiceMapping.FromFund).ToList();

            }
        }

        public void DeleteFundMapping(string fundCode)
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.DeleteFundMapping(fundCode);
            }
        }

        public void UpdateMSRetriveFundMapping(Entities.FundMapping mapping)
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {

                context.UpdateRetrieveMSFundMapping(new FundMapping
                {
                    MSISIN = mapping.MSISIN,
                    FundName = mapping.FundName,
                    FundCode = mapping.FundCode,
                    FundShareClassId = mapping.MorningStarShareClassId,
                    FundId = mapping.FundCode,
                    IsFundFacts = mapping.IsFundFacts,
                    IsFundIML = mapping.IsFundIML,
                    IsFundAssets = mapping.IsFundAssets,
                    IsFundManage = mapping.IsFundManage,
                    IsFundPerform = mapping.IsFundPerform,
                    IsFundTER = mapping.IsFundTER
                });
            }
        }
    }
}
