﻿using System;
using System.Web.Http;

namespace WIMQuotesAdmin.UI.Web.ActionFilters
{
    /// <summary>
    /// Specifies the authorization filter that verifies the request's System.Security.Principal.IPrincipal against the provided
    /// list of Roles
    /// </summary>
    public class AuthorizeRolesAttribute : AuthorizeAttribute
    {
        public AuthorizeRolesAttribute(params string[] roles)
        {
            Roles = String.Join(",", roles);
        }
    }
}