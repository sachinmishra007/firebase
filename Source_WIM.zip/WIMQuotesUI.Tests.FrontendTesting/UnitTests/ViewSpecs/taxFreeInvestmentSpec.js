﻿/// <reference path="../../../wimi.quotes.ui/scripts/jasmine/jasmine.js" />
/// <reference path="../../../wimi.quotes.ui/scripts/common/jquery-1.10.2.js" />
/// <reference path="../../../wimi.quotes.ui/scripts/common/angular.js" />
/// <reference path="../../../wimi.quotes.ui/scripts/common/angular-mocks.js" />
/// <reference path="../../helpers/viewtesterhelper.js" />
/// <reference path="../../helpers/testDataHelper.js" />


/// Test Contoller and View
/// <reference path="../../../wimi.quotes.ui/scripts/app/controllers/lumpsumcontroller.js" />
/// <reference path="../../../wimi.quotes.ui/views/partials/quotedetails/lumpsum.html" />
/// <reference path="../../../wimi.quotes.ui/scripts/app/controllers/debitordercontroller.js" />
/// <reference path="../../../wimi.quotes.ui/views/partials/quotedetails/debitorder.html" />
/// <reference path="../../../wimi.quotes.ui/scripts/app/controllers/quoteapplicationcontroller.js" />
/// <reference path="../../../wimi.quotes.ui/views/quoteform/index.cshtml" />


describe('Test Suite:Tax Free Investment Test', function ()
{
    var scope, viewTester, httpBackend, quoteApplicationViewTester;

    // Setup 1 - Initialise Angular Online Transacting Application
    beforeEach(window.module('quotesApp'));

    // Setup 2 - Setup mock ajax requests/responses
    beforeEach(inject(function ($httpBackend)
    {
        testData.hookupHttpBackend($httpBackend);
        httpBackend = $httpBackend;
    }));

    describe('Tax Free Investment Test-LumSum/DebitOrder - Monthly  ', function ()
    {
        // Setup 3 - Before each spec/'it'/test - Setup Angular Scope, Controller & $compile the View
        beforeEach(inject(function ($controller, $rootScope, $compile, commonUtils, clientService, lookupService)
        {
            var lumpsumcontroller = 'lumpSumController';
            var debitordercontroller = 'debitOrderController';
            var quoteApplicationController = 'quoteApplicationController';
         
            // Setup Initial Scope 

            $scope = $rootScope.$new();

            scope = $rootScope.$new();

            $scope.quoteItem = {};
            $scope.quoteItem.Product = { Code: 'TAXFREESAV' };
            $scope.quoteItem.lumpSumProfile = { Amount: 10000 };
            $scope.quoteItem.hasDebitOrder = true;
            $scope.quoteItem.Currency = { Code: "ZAR", Name: "South African Rand", Symbol: "R" }

            $scope.application = {};
            $scope.application.selectedClient = {};
            $scope.application.selectedClient = { ClientNumber: 'AI83587' };



            scope.quoteItem = {};
            scope.quoteItem.Product = { Code: 'TAXFREESAV' };
            scope.quoteItem.lumpSumProfile = { Amount: 1000000 };
            scope.quoteItem.hasDebitOrder = true;
            scope.quoteItem.Currency = { Code: "ZAR", Name: "South African Rand", Symbol: "R" }

            scope.application = {};
            scope.application.selectedClient = {};
            scope.application.selectedClient = { ClientNumber: 'AI83587' };


            $scope.newProfile = [{
                Type: "LumpSum",
                Description: "LumpSum",
                ShowUseLumpSumFunds: false,
                Funds: [{
                    Amount: 10000,
                    Code: "ABMM",
                    Name: "Absa Money Market",
                    Percentage: 100,
                    Type: "I "
                }],
                IsActive: true
            }];

            scope.newProfile = [{
                Type: "DebitOrder",
                Description: "DebitOrder",
                Frequency: "Monthly",
                ShowUseLumpSumFunds: true,
                Funds: [{
                    Amount: 600,
                    Code: "ABMM",
                    Name: "Absa Money Market",
                    Percentage: 100,
                    Type: "I "
                }],
            }];


            // Instantiate Controller
            $controller(lumpsumcontroller, { $scope: $scope, $rootScope: $rootScope, lookupService: lookupService, clientService: clientService });

            // Instantiate Controller
            $controller(debitordercontroller, { $scope: $scope, lookupService: lookupService, commonUtils: commonUtils });


            // Send response to any "ajax" calls
            httpBackend.flush();



            // Compile View and trigger any watches for scope/controller/view
            var lumpsumViewHtml = $('.lumpsum-declaration').prop('outerHTML');
            var lumpsumCompiledView = $compile(angular.element(lumpsumViewHtml))($scope);
            $scope.$digest();

            lumpsumTester = $viewTester(lumpsumCompiledView, $scope);


            var viewHtml = $('.debitOrder-declaration').prop('outerHTML');
            var compiledView = $compile(angular.element(viewHtml))(scope);
            $scope.$digest();
            debitOrderviewTester = $viewTester(compiledView, scope);

            //var quoteviewHtml = $('.quote-declaration').prop('outerHTML');
            var quoteviewHtml = $('[ng-controller="' + quoteApplicationController + '"]').prop('outerHTML');
            var quotecompiledView = $compile(angular.element(quoteviewHtml))($scope);
            $scope.$digest();

            quoteApplicationViewTester = $viewTester(quotecompiledView, scope);

        // var quoteviewHtml = $('.quote-declaration').prop('outerHTML');
        //var quoteviewHtml = $('[ng-controller="' + quoteApplicationController + '"]').prop('outerHTML');
        //var quotecompiledView = $compile(angular.element(quoteviewHtml))($scope);
        //$scope.$digest();

            //quoteviewTester = $viewTester(quotecompiledView, $scope);
            
        }));


        // ************ BDD - Acceptance Tests *****************

        given('User has captured a Absa Tax Free Investment Account and selected Quote option is Lump Sum and Debit order', function ()
        {
            when('Lump sum amount is greater than equal to <=  10000 and less than equal  to >= 30000 and Debit amount is greater than equal to <= 250 and multiplication of debit amount with remaining  tax month is less than to lump sum amount and  Debit order Frequency is selected Monthly and  Click on Next Button', function ()
            {
                then(' It will allow advisor to proceed further as amount is valid for the Tax free investment.', function ()
                {
                    var nextButton = quoteApplicationViewTester.byNgClick('moveForward()');

                    nextButton.simulateClick();

                    expect($scope.profile.AmountAnnual).toBe();


                });
            });


    });
});


