﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using WIMQuotesAdmin.DataAccess.Repositories.Mappings;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class FundZeroFeeRepository : Contracts.IFundZeroFeeRepository
    {
        public List<Entities.FundZeroFee> GetFundZeroFee()
        {
            using (var context = new SLAService.SLAMaintenanceClient())
            {
                var fundZeroFee = context.GetFundZeroFee();

                if (fundZeroFee == null)
                    return null;

                return fundZeroFee.Select(f => new Entities.FundZeroFee
                {
                    FundId = f.FundId,
                    AIMSInitialFee = f.AIMSInitialFee,
                    AIMSOngoingFee = f.AIMSOngoingFee,
                    AIMSRecurringFee = f.AIMSRecurringFee,
                    FAInitialFee = f.FAInitialFee,
                    FAOngoingFee = f.FAOngoingFee,
                    FARecurringFee = f.FARecurringFee,
                    EACAdminFee = f.EACAdminFee
                }).ToList();
            }
        }

        public List<Entities.Fund> GetFund(string fundType)
        {
            using (var context = new SLAService.SLAMaintenanceClient())
            {
                var fund = context.GetFund(fundType);

                if (fund == null)
                    return null;

                return fund.Select(f => new Entities.Fund
                {
                    Code = f.FundCode,
                    Name = f.FundName
                }).ToList();
            }
        }


        public List<Entities.FundZeroFee> GetPendingFundZeroFees()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.FundZeroFeeStagings
                    .Where(n => n.Status == (int)Entities.StagingStatus.PendingAuthorise)
                    .Select(WIMQuotesAdminStagingMapping.FromFundZeroFeeStaging)
                    .ToList();
            }
        }

        public List<Entities.FundZeroFee> GetPendingFundZeroFee(string FundId)
        {

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.FundZeroFeeStagings
                    .Where(n => n.Status == (int)Entities.StagingStatus.PendingAuthorise && n.FundId == FundId)
                    .Select(WIMQuotesAdminStagingMapping.FromFundZeroFeeStaging)
                    .ToList();
            }
        }



        public void SaveFundZeroFeesToStaging(Entities.FundZeroFee fundZeroFee)
        {

            if (fundZeroFee == null || string.IsNullOrWhiteSpace(fundZeroFee.FundId))
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                context.FundZeroFeeStagings.Add(WIMQuotesAdminStagingMapping.ToFundZeroFeeStaging(fundZeroFee));
                context.SaveChanges();


            }
        }

        public void SaveAuthorisedFundZeroFees(Entities.FundZeroFee fundZeroFee)
        {
            if (fundZeroFee == null)
                return;

            using (var context = new SLAService.SLAMaintenanceClient())
            {
                context.UpdateFundZeroFee(SLAApplicationServiceMapping.ToFundZeroFee(fundZeroFee));

            }
        }

        public void DeleteAuthorisedFundZeroFees(Entities.FundZeroFee fundZeroFee)
        {
            if (String.IsNullOrWhiteSpace(fundZeroFee.FundId))
                return;

            using (var context = new SLAService.SLAMaintenanceClient())
            {
                //var fundZeroFees = new SLAService.FundZeroFee();
                context.DeleteFundZeroFee(Mappings.SLAApplicationServiceMapping.ToFundZeroFee(fundZeroFee));
            }
        }

        public void UpdateFundZeroFeesStagingStatus(Entities.FundZeroFee fundZeroFee)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundFees = context.FundZeroFeeStagings
                    .Where(f => f.FundId == fundZeroFee.FundId &&
                                f.Status == (int)Entities.StagingStatus.PendingAuthorise);

                foreach (var contextFundZeroFee in contextFundFees)
                {
                    contextFundZeroFee.Status = (int)fundZeroFee.Status;
                    contextFundZeroFee.InstructionType = (int)fundZeroFee.InstructionType;
                    contextFundZeroFee.ModifiedUserId = fundZeroFee.ModifiedUserId;
                    contextFundZeroFee.ModifiedDateTime = DateTime.Now;
                }

                context.SaveChanges();
            }
        }

        public void AddNewFund(Entities.FundZeroFee fundZeroFee)
        {

            if (String.IsNullOrWhiteSpace(fundZeroFee.FundId))
                return;


            using (var context = new SLAService.SLAMaintenanceClient())
            {
                context.SaveFundZeroFee(Mappings.SLAApplicationServiceMapping.ToFundZeroFee(fundZeroFee));
            }
        }
    }
}
