using System;
using System.Web;
using Microsoft.Web.Infrastructure.DynamicModuleHelper;

using Ninject;
using Ninject.Web.Common;

using WIMI.Quotes.Model.Domain;
using WIMI.Quotes.Model.Domain.Contracts;
using WIMI.Quotes.UI;

[assembly: WebActivatorEx.PreApplicationStartMethod(typeof(NinjectWebCommon), "Start")]
[assembly: WebActivatorEx.ApplicationShutdownMethodAttribute(typeof(NinjectWebCommon), "Stop")]

namespace WIMI.Quotes.UI
{
    public static class NinjectWebCommon 
    {
        private static readonly Bootstrapper Bootstrapper = new Bootstrapper();

        /// <summary>
        /// Starts the application
        /// </summary>
        public static void Start() 
        {
            DynamicModuleUtility.RegisterModule(typeof(OnePerRequestHttpModule));
            DynamicModuleUtility.RegisterModule(typeof(NinjectHttpModule));
            Bootstrapper.Initialize(CreateKernel);
        }
        
        /// <summary>
        /// Stops the application.
        /// </summary>
        public static void Stop()
        {
            Bootstrapper.ShutDown();
        }
        
        /// <summary>
        /// Creates the kernel that will manage your application.
        /// </summary>
        /// <returns>The created kernel.</returns>
        private static IKernel CreateKernel()
        {
            var kernel = new StandardKernel();
            try
            {
                kernel.Bind<Func<IKernel>>().ToMethod(ctx => () => new Bootstrapper().Kernel);
                kernel.Bind<IHttpModule>().To<HttpApplicationInitializationHttpModule>();

                RegisterServices(kernel);
                return kernel;
            }
            catch
            {
                kernel.Dispose();
                throw;
            }
        }

        /// <summary>
        /// Load your modules or register your services here!
        /// </summary>
        /// <param name="kernel">The kernel.</param>
        private static void RegisterServices(IKernel kernel)
        {
            // Domain
            kernel.Bind<IAdvisorLogic>().To<AdvisorLogic>();
            kernel.Bind<IClientLogic>().To<ClientLogic>();
            kernel.Bind<IFundsLogic>().To<FundsLogic>();
            kernel.Bind<IProductsLogic>().To<ProductsLogic>();
            kernel.Bind<IQuoteItemLogic>().To<QuoteItemLogic>();
            kernel.Bind<IQuoteGenerationLogic>().To<QuoteGenerationLogic>();
            kernel.Bind<IQuoteReportLogic>().To<QuoteReportLogic>();
            kernel.Bind<IRegulation28Logic>().To<Regulation28Logic>();
            kernel.Bind<ISettingsLogic>().To<SettingsLogic>();
            kernel.Bind<IUserLogic>().To<UserLogic>();
            kernel.Bind<IValidationLogic>().To<ValidationLogic>();
            kernel.Bind<ILookupLogic>().To<LookupLogic>();
            kernel.Bind<IIntegrationLogic>().To<IntegrationLogic>();
            kernel.Bind<IPhaseInLogic>().To<PhaseInLogic>();
            kernel.Bind <ITaxYearLogic>().To<TaxYearLogic>();

            // Repository 
            kernel.Bind<Repositories.Contracts.IWIMQuotesWCFServiceRepository>().To<Repositories.WIMQuotesWCFServiceRepository>();
            kernel.Bind<Repositories.Contracts.IWIMQuotesDataRepository>().To<Repositories.WIMQuotesDataRepository>();
            kernel.Bind<Repositories.Contracts.IWIMQuotesApplicationServiceRepository>().To<Repositories.WIMQuotesApplicationServiceRepository>();
            kernel.Bind<Repositories.Contracts.IPortfolioPerformanceServiceRepository>().To<Repositories.PortfolioPerformanceServiceRepository>();
            kernel.Bind<Repositories.Contracts.IClientMaintenanceRepository>().To<Repositories.ClientMaintenanceRepository>();
            kernel.Bind<Repositories.Contracts.ISLAMaintenanceRepository>().To<Repositories.SLAMaintenanceRepository>();
            kernel.Bind<Repositories.Contracts.IRegulation28ServiceRepository>().To<Repositories.Regulation28ServiceRepository>();
            kernel.Bind<Repositories.Contracts.IAuthenticationService>().To<Repositories.AuthenticationRepository>();
            kernel.Bind<Repositories.Contracts.ISessionApiRepository>().To<Repositories.SessionApiRepository>();
            kernel.Bind<Repositories.Contracts.IPhaseInRepository>().To<Repositories.PhaseInRepository>();
            kernel.Bind<Repositories.Contracts.ITransferDataRepository>().To<Repositories.TransferDataRepository>();
            kernel.Bind<Repositories.Contracts.IOnlineTransactingServiceRepository>().To<Repositories.OnlineTransactingServiceRepository>();
            kernel.Bind<Repositories.Contracts.IDataWarehouseServiceRepository>().To<Repositories.DataWarehouseServiceRepository>();
        }
    }
}
