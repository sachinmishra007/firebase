﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class WrapLogic : Contracts.IWrapLogic
    {
        #region Constructor

        private readonly DataAccess.Repositories.Contracts.IPortfolioPerformanceRepository _portfolioPerformanceRepository;

        public WrapLogic(DataAccess.Repositories.Contracts.IPortfolioPerformanceRepository portfolioPerformanceRepository)
        {
            _portfolioPerformanceRepository = portfolioPerformanceRepository;
        }

        #endregion

        public List<Entities.Fund> GetAvailableWraps()
        {
            return _portfolioPerformanceRepository.GetAvailableWraps();
        }

        public List<Entities.Fund> GetFundsForWrap(string wrapCode)
        {
            return _portfolioPerformanceRepository.GetFundsForWrap(wrapCode);
        }
    }
}
