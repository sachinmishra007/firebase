﻿using System;
using System.Collections.Generic;
using System.Linq;
using WIMQuotesAdmin.Domain.Logic.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class FundMinimumLogic : IFundMinimumLogic
    {
        #region Constructors

        private readonly DataAccess.Repositories.Contracts.IFundMinimumRepository _fundMinimumRepository;

        public FundMinimumLogic(DataAccess.Repositories.Contracts.IFundMinimumRepository fundMinimumRepository)
        {
            _fundMinimumRepository = fundMinimumRepository;
        }

        #endregion

        public List<Entities.FundMinimum> GetFundMinimumAmounts()
        {
            return _fundMinimumRepository.GetFundMinimumAmounts();
        }

        void IFundMinimumLogic.StageFundMinimum(Entities.FundMinimum fundMinimum, string userId)
        {
            if (fundMinimum == null || string.IsNullOrWhiteSpace(userId))
                return;

            fundMinimum.Status = Entities.StagingStatus.PendingAuthorise;
            fundMinimum.CapturedUserId = userId;
            fundMinimum.ModifiedUserId = userId;
            fundMinimum.ModifiedDateTime = DateTime.Now;
            _fundMinimumRepository.SaveFundMinimumToStaging(fundMinimum);
        }


        public void PendingFundMinimumUpdateStatus(List<Entities.FundMinimum> fundMinimum, string userId)
        {
            if (fundMinimum == null || fundMinimum.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return;

            foreach (var fund in fundMinimum)
            {
                switch (fund.Status)
                {
                    case Entities.StagingStatus.Authorise:
                        PendingFundMinimumAmountAuthorise(fund, userId);
                        break;
                    case Entities.StagingStatus.Reject:
                        PendingFundMinimumAmountReject(fund, userId);
                        break;
                }
            }
        }


        public List<Entities.FundMinimum> GetPendingFundMinimumAmounts()
        {
            return _fundMinimumRepository.GetPendingFundMinimumAmounts();
        }

        public List<Entities.Product> GetProducts()
        {
            return _fundMinimumRepository.GetProducts();
        }

        public List<Entities.FundMinimum> GetFunds(string productId)
        {
            return _fundMinimumRepository.GetFunds(productId);
        }

        public List<Entities.FundMinimum> GetTransactionType(string productId, string fundId)
        {
            return _fundMinimumRepository.GetTransactionType(productId, fundId);
        }

        void IFundMinimumLogic.AddNewFundMinimum(Entities.FundMinimum fundMinimum, string userId)
        {
            if (fundMinimum == null || string.IsNullOrWhiteSpace(userId))
                return;

            _fundMinimumRepository.AddNewFundMinimum(fundMinimum, userId);
        }


        #region Private Methods

        private void PendingFundMinimumAmountAuthorise(Entities.FundMinimum fundMinimum, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            var fundFee = _fundMinimumRepository.GetPendingFundMinimumAmounts();

            if (fundFee == null)
                return;

            switch (fundMinimum.InstructionType)
            {
                case Entities.InstructionType.Delete:
                    _fundMinimumRepository.DeleteAuthorisedFundMinimum(fundMinimum);
                    break;
                default:
                    _fundMinimumRepository.SaveAuthorisedFundMinimum(fundMinimum);
                    break;
            }

            _fundMinimumRepository.UpdateFundMinimumStagingStatus(fundMinimum);
        }

        private void PendingFundMinimumAmountReject(Entities.FundMinimum fundMinimum, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId) || fundMinimum == null)
                return;

            fundMinimum.Status = Entities.StagingStatus.Reject;
            fundMinimum.ModifiedUserId = userId;
            fundMinimum.ModifiedDateTime = DateTime.Now;
            _fundMinimumRepository.UpdateFundMinimumStagingStatus(fundMinimum);
        }
        #endregion



    }
}
