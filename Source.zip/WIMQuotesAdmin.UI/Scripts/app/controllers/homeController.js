﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('homeController', ['$scope', '$window', 'menuService', 'userManagementService', function ($scope, $window, menuService, userManagementService)
        {
            $scope.menuItems = undefined;
            $scope.contentFileName = undefined;

            $scope.application = {
                showLoading: true,
                userProfile: undefined,
                currentMenuItem: undefined
            }


            // Behaviours

            $scope.openMenuItem = function (menuItem)
            {
                if (typeof menuItem === "undefined" || menuItem === null)
                    return;

                if (typeof menuItem.ActionUrl !== "undefined" && menuItem.ActionUrl !== null)
                {
                    $window.location.href = menuItem.ActionUrl;
                }
                else
                {
                    menuItem.$isExpanded = !menuItem.$isExpanded;
                }
            };

            $scope.navigate = function (menuItem)
            {
                $scope.application.currentMenuItem = menuItem;
                $scope.contentFileName = 'Views/Partials/' + menuItem.ViewFileUrl;
            }


            // On Load

            userManagementService.getUserProfile().success(function (response)
            {
                $scope.application.userProfile = response;
            });

            menuService.getMenu().success(function (response)
            {
                $scope.menuItems = response;
                $scope.contentFileName = "Views/Partials/UserManagement/UserProfile.html";

                $scope.application.showLoading = false;
            });

        }]);
})();
