﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('ratesCaptureController', ['$scope', 'lookupService', function ($scope, lookupService)
        {
            $scope.rateTypes = lookupService.getRateTypes();
            $scope.selectedRateType = {};
            $scope.includeView = undefined;

            //On load
            $scope.init = function ()
            {
                $scope.includeView = '';
            };

            //Behaviours
            $scope.changeRateType = function (type)
            {
                switch (type)
                {
                    case 'ABMM':
                        $scope.includeView = '';
                        break;
                    case 'GROWTH':
                        $scope.includeView = 'Views/Partials/Product/guaranteedGrowthRates.html';
                        break;
                    case 'INCOME':
                        $scope.includeView = 'Views/Partials/Product/guaranteedIncomeRates.html';
                        break;
                }
            }
        }]);
})();
