﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IMenuLogic
    {
        List<Entities.MenuItem> Get(string userId);
    }
}
