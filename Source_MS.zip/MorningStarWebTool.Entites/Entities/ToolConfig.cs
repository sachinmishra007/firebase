﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorningStarWebTool.Entites.Entities
{
    public class ToolConfig
    {
        public int ConfigId { get; set; }
        public string ConfigName { get; set; }
        public string ConfigValue { get; set; }
    }
}
