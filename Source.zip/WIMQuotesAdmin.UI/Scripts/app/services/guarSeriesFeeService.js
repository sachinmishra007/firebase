﻿(function () {

    angular.module('adminApp.services')
    .factory('guarSeriesFeeService', ['$http', function ($http) {

        var guarSeriesFeeService = {};
       
        guarSeriesFeeService.getGuarFees = function (guarFeesType) {
            return $http({ url: 'api/GuarSeriesFee/?guarFeesType=' + guarFeesType });
        };

        guarSeriesFeeService.getPendingGuarfees = function () {
            return $http({ url: 'api/GuarSeriesFee/Pending' });
        };
        
        guarSeriesFeeService.saveGuarFees = function (guarFees) {
            return $http.post('api/GuarSeriesFee/saveGuarFees', guarFees);
        };

        guarSeriesFeeService.UpdatePendingGuarFeeStatus = function (guarFees) {
            return $http.post('api/GuarSeriesFee/UpdatePendingGuarFeeStatus', guarFees);
        };

        //guarSeriesFeeService.saveGuarFees = function (guarFees, userId) {
        //    debugger;
        //    return $http.post('api/GuarSeriesFee/SaveguarFeesStaging?userId=' + userId, guarFees, userId);
        //};

        //guarSeriesFeeService.authoriseGuarFees = function () {

        //    return $http.post('api/GuarSeriesFee/AuthoriseGuarFees');
        //};

        //guarSeriesFeeService.rejectGuarFees = function (reject) {
        //    return $http.post('api/GuarSeriesFee/RejectGuarFees', reject);
        //};
        //productService.getPendingGuarfees = function () {
        //    return $http({ url: 'api/GuarSeriesFee/Pending' });
        //};


        //productService.saveProductNote = function (note) {
        //    return $http.post('api/ProductNotes', note);
        //};

            return guarSeriesFeeService;


        }]);


})();