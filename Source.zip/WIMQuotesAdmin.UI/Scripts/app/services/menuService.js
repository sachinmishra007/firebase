﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('menuService', ['$http', function ($http)
        {
            var menuService = {};

            menuService.getMenu = function ()
            {
                return $http({ url: 'api/Menu' });
            };

            return menuService;
        }]);
})();

