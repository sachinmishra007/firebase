﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Entities
{
    public class WrapBreakdownReport : Fund
    {
        public string  CompleteMS { get; set; }
        public string  LinkedToMS{get;set;}
        public decimal Equity { get; set; }
        public decimal Property { get; set; }
        public decimal ForeignExclAfrica { get; set; }
        public decimal AfricaExclRSA { get; set; }
    }
}
