﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('regulation28LimitsService', ['$http', function ($http)
        {
            var regulation28LimitsService = {};

            regulation28LimitsService.getRegulation28Limits = function ()
            {
                return $http({ url: 'api/Regulation28Limits/GetRegulation28Limits' });
            };

            regulation28LimitsService.getPendingLimits = function ()
            {
                return $http({ url: 'api/Regulation28Limits/Pending' });
            };

            regulation28LimitsService.stageRegulation28Limits = function (limit)
            {
                return $http.post('api/Regulation28Limits', limit);
            };

            regulation28LimitsService.updatePendingStatuses = function (limits)
            {
                return $http.post('api/Regulation28Limits/UpdatePendingStatuses', limits);
            };

            regulation28LimitsService.authoriseRegulation28Limits = function (limits)
            {
                return $http.post('api/Regulation28Limits/AuthoriseRegulation28Limits', limits);
            };

            regulation28LimitsService.rejectRegulation28Limits = function (limits)
            {
                return $http.post('api/Regulation28Limits/RejectRegulation28Limits', limits);
            };

            return regulation28LimitsService;
        }]);
})();
