﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMQuotesAdmin.Entities
{
    public class Note
    {
        public int Id { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public Language Language { get; set; }
        public string LanguageName { get; set; }
        public string Header { get; set; }
        public string NoteType { get; set; }
        public int Sequence { get; set; }
        public string Description { get; set; }

        public string HeaderRevised { get; set; }
        public string DescriptionRevised { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public StagingStatus Status { get; set; }
        public string RevisedByUserId { get; set; }
        public DateTime? RevisionDate { get; set; }
    }
}
