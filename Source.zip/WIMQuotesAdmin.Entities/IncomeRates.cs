﻿namespace WIMQuotesAdmin.Entities
{
    public class IncomeRates
    {
        public string ProductType { get; set; }
        public string Guarantor { get; set; }
        public double AnnuityAmount { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string PlacementDate { get; set; }
        public string MaturityDate { get; set; }
        public double Yield { get; set; }
        public double RateAfterFees { get; set; }
        public double UnderWriterFees { get; set; }
        public double AIMSFee { get; set; }
        public string FirstIncomeDate { get; set; }
        public double NACMRate { get; set; }
        public string User { get; set; }
        public string FeeStatus { get; set; }
    }
}