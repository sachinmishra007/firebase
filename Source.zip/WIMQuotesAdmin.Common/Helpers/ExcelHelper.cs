﻿using System;
using System.Collections.Generic;
using System.Linq;
using OfficeOpenXml;

using WIMQuotesAdmin.Common.Extensions;

namespace WIMQuotesAdmin.Common.Helpers
{
    public static class ExcelHelper
    {
        public static byte[] CollectionToExcel<T>(List<T> collection)
        {
            using (var excelPackage = new ExcelPackage())
            {
                ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets.Add("Sheet1");
                worksheet.Cells["A1"].LoadFromCollection(collection, true);

                int totalCols = worksheet.Dimension.End.Column;
                int totalRows = worksheet.Dimension.End.Row;

                var headerCells = worksheet.Cells[1, 1, 1, totalCols];
                headerCells.Style.Font.Bold = true;

                if (collection.Any())
                {
                    var datePropertyNames = typeof(T).PropertyNamesForType(typeof(DateTime));

                    for (int i = 1; i <= totalCols; i++)
                    {
                        if (String.IsNullOrWhiteSpace(headerCells[1, i].Address) || headerCells[1, i].Value == null)
                            continue;

                        var value = headerCells[1, i].Value.ToString();

                        if (datePropertyNames.Contains(value))
                        {
                            worksheet.Cells[2, i, totalRows, i].Style.Numberformat.Format = "yyyy-mm-dd hh:mm:ss";
                        }
                    }
                }

                worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

                return excelPackage.GetAsByteArray();
            }
        }
    }
}
