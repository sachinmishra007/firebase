﻿using System.Web.Mvc;

namespace WIMQuotesAdmin.UI.Controllers
{
    public class ErrorController : Controller
    {
        [AllowAnonymous]
        public ActionResult Index()
        {
            return View("Error");
        }
    }
}