﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.Http.Filters;
using System.Web.Security;

namespace MorningStarWebTool.Web.ActionFilters
{
    public class SessionTimeoutAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            FormsAuthentication.SignOut();
            HttpContext.Current.Session.Abandon();
            HttpContext.Current.Session.Clear();
            base.OnActionExecuting(actionContext);
        }
    }
}