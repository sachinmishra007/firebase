﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{

    [ValidateApiAntiForgeryToken]
    public class InactiveFundController : ApiController
    {
        #region Constructor
        private readonly Domain.Logic.Contracts.IinactiveFundLogic _inactiveFundLogic;
        public InactiveFundController(Domain.Logic.Contracts.IinactiveFundLogic inactiveFundLogic)
        {
            _inactiveFundLogic = inactiveFundLogic;
        }

        #endregion
        [Route("api/InactiveFunds")]
        public  List<Entities.InactiveFund> Get()
        {
            return _inactiveFundLogic.GetInactiveFunds();
        }

        [Route("api/InactiveFunds/GetUnmappedFunds")]
        public List<Entities.InactiveFund> GetUnmappedFunds()
        {
            return _inactiveFundLogic.GetUnmappedFunds();
        }

        [HttpPost]
        [Route("api/InactiveFunds/AddInactiveFund")]
        public void AddInactiveFund([FromBody]Entities.InactiveFund fund, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            //if (limit == null || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
            //    return;

            _inactiveFundLogic.AddInactiveFund(fund, user.Identity.Name);
        }
        
        [HttpPost]
        [Route("api/InactiveFunds/DeleteInactiveFund")]
        public void UpdateInactiveFund([FromBody]Entities.InactiveFund fundCode, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            _inactiveFundLogic.DeleteInactiveFund(fundCode.FundCode, user.Identity.Name);
        }
    }
}