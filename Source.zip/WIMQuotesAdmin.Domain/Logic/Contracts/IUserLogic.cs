﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IUserLogic
    {
        bool AuthenticateUser(string username, string password);
        Entities.User GetUser(string userId);
        Entities.UserRole? GetUserRole(string userId);
        bool IsValidUser(string userId);
        Entities.UserAccess GetUserAccess(string userId);

        List<Entities.User> SearchUnmappedUsers(string searchTerm);
        List<Entities.User> SearchExistingUsers(string searchTerm);

        void SaveUser(Entities.User user, string currentSystemUser);
        void SaveUserAccess(Entities.UserAccess userAccess, string currentSystemUser);
        void DeleteUser(Entities.User user, string currentSystemUser);
    }
}
