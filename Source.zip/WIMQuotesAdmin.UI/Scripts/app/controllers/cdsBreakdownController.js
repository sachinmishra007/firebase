﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('cdsBreakdownController', ['$scope', '$timeout', 'lookupService', 'cdsBreakdownService', 'quoteFrequencyReportService', function ($scope, $timeout, lookupService, cdsBreakdownService, quoteFrequencyReportService)
        {
            $scope.reportGenerateTypes = lookupService.getReportGenerateTypes();
           
            var minDateOffSet = 1000 * 60 * 60 * 24 * 365 * 5; // Offset by 5 Years;
            $scope.maxDate = new Date();
            $scope.minDate = new Date();
            $scope.minDate.setTime($scope.maxDate.getTime() - minDateOffSet);

            var startDateOffset = 1000 * 60 * 60 * 24 * 31; // Offset by 31 Days;
            var startDate = new Date();
            startDate.setTime(startDate.getTime() - startDateOffset);

            //$scope.reportSearchDetails = {
            //    BrokerCode: '',
            //    ReportType: undefined,
            //    StartDate: startDate,
            //    EndDate: new Date()
            //}

            $scope.reportSearchDetails = {
                BrokerCode: '',
                ReportType: undefined,
                StartDate: startDate,
                EndDate: new Date()
            }

            $scope.quoteReportList = [];
            $scope.quoteBrokerReportList = [];
            $scope.brokerList = [];
            $scope.brokerHouseList = [];
           
            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];
            
          
            // Behaviours

            $scope.getQuoteReports = function ()
            {
                $scope.application.showLoading = true;

                $scope.quoteReportList.length = 0;

                if ($scope.reportSearchDetails.ReportType === 'AllQuotes')
                {
                    $scope.$isAllQuotesReport = true;
                }

                cdsBreakdownService.getQuoteReports($scope.reportSearchDetails).success(function (response)
                {
                    debugger;
                    $scope.quoteReportList = response;
                    $scope.currentPage = 0;
                    $scope.application.showLoading = false;
                });
            };

            $scope.getReportsMode = function ()
            {
                $scope.quoteReportList = [];
            };  

            $scope.searchBrokers = function (searchTerm)
            {
                return quoteFrequencyReportService.searchBrokers(searchTerm).success(function (response)
                {
                    $scope.brokerList = response;
                });
            };

            $scope.searchBrokerHouse = function (searchTerm)
            {
                return quoteFrequencyReportService.searchBrokerHouse(searchTerm).success(function (response)
                {
                    $scope.brokerHouseList = response;
                });
            };

            $scope.setSelectedBroker = function (broker)
            {
                $scope.reportSearchDetails.BrokerCode = broker.BrokerCode;
            };

            $scope.downloadReportOutput = function ()
            {
                debugger;
                $scope.downloadUrl = "Report/CDSBreakdownOutput?startDate=" + $scope.reportSearchDetails.StartDate.toDateString() + "&endDate=" + $scope.reportSearchDetails.EndDate.toDateString() + "&brokerCode=" + $scope.reportSearchDetails.BrokerCode + "&reportType=" + $scope.reportSearchDetails.ReportType + "&rnd=" + new Date().getTime();
            };


            // Pagination

            $scope.firstPage = function ()
            {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function ()
            {
                if ($scope.currentPage > 0)
                {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function ()
            {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function ()
            {
                return Math.ceil(($scope.quoteReportList || []).length / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function ()
            {
                if ($scope.currentPage < $scope.pageCount())
                {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function ()
            {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function ()
            {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n)
            {
                $scope.currentPage = n;
            };

            $scope.range = function ()
            {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0)
                {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize)
                {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++)
                {
                    range.push(i);
                }

                return range;
            };

        }]);
})();
