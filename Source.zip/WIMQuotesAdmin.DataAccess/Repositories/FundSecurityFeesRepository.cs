﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class FundSecurityFeesRepository : IFundSecurityFeesRepository
    {
        private readonly string _connectionString = ConfigurationManager.ConnectionStrings["WIMQuotesAdminStaging"].ToString();

        public FundSecurityFeesRepository()
        {
            //_connectionString = connectionString;
        }

        public void StageFundSecurityFees(OleDbDataReader fundSecurityFees, string userID) //
        {

            var dataTable = new DataTable();
            dataTable.Load(fundSecurityFees);

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {

                SqlBulkCopy bulkCopy =
                new SqlBulkCopy(connection,
                SqlBulkCopyOptions.TableLock |

                 SqlBulkCopyOptions.FireTriggers |

                SqlBulkCopyOptions.UseInternalTransaction,

            null
            );
                //set default table name 
                bulkCopy.DestinationTableName = "FundSecurityFeesFile";
                connection.Open();


                bulkCopy.WriteToServer(dataTable);
                connection.Close();
            }


            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                context.pUpdateFundSecurityFeesStatus((int?)Entities.StagingStatus.PendingAuthorise, userID);
                
            }

            //DataTable dt = fundTIC.GetSchemaTable();
            //dt.Rows = 

        }
        
        public List<Entities.FundSecurityFees> GetPendingFundSecurityFees()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.FundSecurityFeesStagings
                    .Where(f => f.Status == (int)Entities.StagingStatus.PendingAuthorise)
                    .Select(Mappings.WIMQuotesAdminStagingMapping.FromFundSecurityFeesStaging)
                    .ToList();
            }
        }
        
        public void AutoriseRejectFundSecurityFees(Entities.StagingStatus status, string userID)
        {
            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                context.pAuthoriseRejectFundSecurityFees((int?)status, userID);
            }
        }

        public void SaveAuthorisedFundSecurityFees()
        {
            using(var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.SaveFundSecurityFees();
            }
        }
    }
}
