﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class FundZeroFeeLogic : Contracts.IFundZeroFeeLogic
    {
        #region Constructor

        private readonly DataAccess.Repositories.Contracts.IFundZeroFeeRepository _fundZeroFeeRepository;

        public FundZeroFeeLogic(DataAccess.Repositories.Contracts.IFundZeroFeeRepository fundZeroFeeRepository)
        {
            _fundZeroFeeRepository = fundZeroFeeRepository;
        }

        #endregion

        public List<Entities.FundZeroFee> GetFundZeroFee()
        {
            return _fundZeroFeeRepository.GetFundZeroFee();
        }

        public List<Entities.Fund> GetFund(string fundType)
        {
            return _fundZeroFeeRepository.GetFund(fundType);
        }

        public List<Entities.FundZeroFee> GetPendingFundZeroFees()
        {
            return _fundZeroFeeRepository.GetPendingFundZeroFees();
        }

        public void StageFundZeroFee(Entities.FundZeroFee fundZeroFee, string userId)
        {
            if (fundZeroFee == null || string.IsNullOrWhiteSpace(userId))
                return;

            fundZeroFee.Status = Entities.StagingStatus.PendingAuthorise;
            //fundZeroFee.CapturedUserId = userId;
            fundZeroFee.ModifiedUserId = userId;
            fundZeroFee.ModifiedDateTime = DateTime.Now;

            _fundZeroFeeRepository.SaveFundZeroFeesToStaging(fundZeroFee);
        }



        public void PendingFundZeroFeesUpdateStatus(List<Entities.FundZeroFee> fundZeroFee, string userId)
        {
            if (fundZeroFee == null || fundZeroFee.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return;

            foreach (var fundFee in fundZeroFee)
            {
                switch (fundFee.Status)
                {
                    case Entities.StagingStatus.Authorise:
                        PendingFundZeroFeesAuthorise(fundFee, userId);
                        break;
                    case Entities.StagingStatus.Reject:
                        PendingFundFeesReject(fundFee, userId);
                        break;
                }

            }
        }


        public void AddNewFund(Entities.FundZeroFee fundZeroFee, string userId)
        {

            if (fundZeroFee == null || string.IsNullOrWhiteSpace(userId))
                return;


            _fundZeroFeeRepository.AddNewFund(fundZeroFee);
        }

        #region Private Methods

        private void PendingFundZeroFeesAuthorise(Entities.FundZeroFee fundZeroFee, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return;

            var fundFee = _fundZeroFeeRepository.GetPendingFundZeroFee(fundZeroFee.FundId).FirstOrDefault();

            if (fundFee == null)
                return;

            switch (fundFee.InstructionType)
            {
                case Entities.InstructionType.Delete:
                    _fundZeroFeeRepository.DeleteAuthorisedFundZeroFees(fundZeroFee);
                    break;
                default:
                    _fundZeroFeeRepository.SaveAuthorisedFundZeroFees(fundZeroFee);
                    break;
            }

            _fundZeroFeeRepository.UpdateFundZeroFeesStagingStatus(fundZeroFee);
        }

        private void PendingFundFeesReject(Entities.FundZeroFee fundZeroFee, string userId)
        {
            if (string.IsNullOrWhiteSpace(userId) || fundZeroFee == null)
                return;

            fundZeroFee.Status = Entities.StagingStatus.Reject;
            fundZeroFee.ModifiedUserId = userId;
            fundZeroFee.ModifiedDateTime = DateTime.Now;
            _fundZeroFeeRepository.UpdateFundZeroFeesStagingStatus(fundZeroFee);
        }
        #endregion

    }
}
