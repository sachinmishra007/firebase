﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IFundTERRepository
    {
        List<Entities.FundTER> GetFundTERs(Entities.FundType fundType, string fundCode);
        List<Entities.FundTER> GetPendingFundTERs();
        Entities.FundTER GetPendingFundTER(string fundCode);
        List<Entities.Fund> GetUnmappedFunds();

        void SaveFundTERToStaging(Entities.FundTER fundTER);
        void SaveAuthorisedFundTER(Entities.FundTER fundTER);
        void UpdateFundTERStagingStatus(string fundCode, Entities.StagingStatus status, string userId);
        void DeleteAuthorisedFundTER(string fundCode);
    }
}