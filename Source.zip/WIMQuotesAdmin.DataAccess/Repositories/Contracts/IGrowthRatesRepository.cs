﻿using System.Collections.Generic;


namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IGrowthRatesRepository
    {
        List<Entities.TaxInformation> CaptureRates();
    }
}
