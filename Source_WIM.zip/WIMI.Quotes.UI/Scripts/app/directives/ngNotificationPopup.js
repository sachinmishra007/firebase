﻿(function ()
{
    'use strict';

    angular.module('common.directives')
        .directive('ngNotificationPopup', ['$parse', function ()
        {
            return {
                restrict: 'A',
                replace: true,
                scope: {
                    ngNotificationPopup: '=',
                    ngNotificationHeader: '=',
                    ngNotificationContent: '=',
                    ngNotificationContinue: '='
                },
                template: '<div ng-show="ngNotificationPopup">' +
                            '<div class="notification-modal notification notification-alert">' +
                                '<div class="notification-icon"></div>' +
                                '<div class="notification-title">{{ngNotificationHeader}}</div>' +
                                '<div class="notification-content">{{ngNotificationContent}}</div>' +
                                '<div class="buttons-list">' +
                                '   <input type="button" value="Close & Correct" class="button" ng-click="closePopup()" />' +
                                '   <input type="button" value="Continue" class="button" ng-show="ngNotificationContinue" ng-click="continue()" />' +
                                '</div>' +
                            '</div>' +
                            '<div class="cover"></div>' +
                          '</div>',
                link: function (scope)
                {
                    scope.continue = function ()
                    {
                        if (angular.isDefined(scope.ngNotificationContinue))
                            scope.ngNotificationContinue();
                    };

                    scope.closePopup = function ()
                    {
                        scope.ngNotificationPopup = !scope.ngNotificationPopup;
                    };
                }
            }
        }]);

})();
