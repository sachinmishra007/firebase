﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common.Extensions;
using WIMQuotesAdmin.UI.Web.StreamProviders;

namespace WIMQuotesAdmin.UI.Web.ModelBinders.Application
{
    /// <summary>
    /// Model Binder to bind Multipart File Data for actual Fund TIC Sheet File to be bound to Entities.FundTIC
    /// </summary>
    public class FundTICModelBinder : IModelBinder
    {
        public bool BindModel(System.Web.Http.Controllers.HttpActionContext actionContext, ModelBindingContext bindingContext)
        {
            if (bindingContext.ModelType != typeof(Entities.FundTIC))
                return false;

            if (!actionContext.Request.Content.IsMimeMultipartContent())
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);

            var provider = new MultipartFormDataMemoryStreamProvider();

            IDictionary<string, byte[]> fileStreams = null;
            Task.Factory
                .StartNew(() => fileStreams = actionContext.Request.Content.ReadAsMultipartAsync(provider).Result.FileStreams,
                    CancellationToken.None,
                    TaskCreationOptions.LongRunning, // Guarantees separate thread
                    TaskScheduler.Default)
                .Wait();

            Entities.FundTIC fundTICFile = new Entities.FundTIC();
    

            var file = fileStreams.FirstOrDefault();

            if (file.Value.Length == 0)
                throw new HttpResponseException(HttpStatusCode.BadRequest);

            fundTICFile.FileName = file.Key;
            fundTICFile.FileData = file.Value;

            bindingContext.Model = fundTICFile;

            return true;
        }
    }
}