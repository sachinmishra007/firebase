﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('fundAssetClassesController', ['$scope', '$timeout', 'fundAssetClassesService', function ($scope, $timeout, fundAssetClassesService)
        {
            $scope.fundsList = [];
            $scope.assetClasses = [];
            $scope.fundAssets = undefined;
            $scope.pendingFundAssetsList = [];
            $scope.assetClassesTotalPercentage = 0.00;
            $scope.unmappedAssetClasses = [];
            $scope.pendingAssetsList = [];
            $scope.pendingFundAssetsListCopy = [];

            $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' ||
                $scope.application.currentMenuItem.AccessLevel === 'AdminRights';

            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
            $scope.isViewVisible = false;


            // Private Members
            
            var removePendingFundAsset = function (fundCode,assetClassList) {
                
                for (var i = 0; i < $scope.pendingFundAssetsList.length; i++) {
                   if($scope.pendingFundAssetsList[i].FundCode === fundCode)
                    for (var j = 0; j < $scope.pendingFundAssetsList[i].AssetClass.length; j++)
                    {
                        for (var k = 0 ; k < assetClassList.length ; k++)
                        {
                            //var assetId = assetClassList[k].Id;
                            if($scope.pendingFundAssetsList[i].AssetClass[j].Id === assetClassList[k].Id)
                                $scope.pendingFundAssetsList[i].AssetClass.splice(j, 1);
                            //if(assetClassList[k].InstructionType === 'Add')

                        }
                    }
                   if ($scope.pendingFundAssetsList[i].AssetClass.length === 0)
                       $scope.pendingFundAssetsList.splice(i, 1);
                }
            }
            

            var sumArray = function (array, propertyName)
            {
                var total = 0.00;

                for (var i = 0; i < array.length; i++)
                {
                    var amount = parseFloat(array[i][propertyName]);
                    total += isNaN(amount) ? 0 : amount;
                }

                return total;
            };

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 3000);
            }

            // On Load

            $scope.application.showLoading = true;

            fundAssetClassesService.getAvailableFunds().success(function (response)
            {
                $scope.fundsList = response;
                $scope.application.showLoading = false;
            });

            if ($scope.isPendingVisible)
            {
                
                fundAssetClassesService.getPendingFundAssets().success(function (response)
                {
                    $scope.pendingFundAssetsList = response;
                    $scope.isViewVisible = response.length === 0;
                });
            }
            else
            {
                $scope.isViewVisible = true;
            }


            // Behaviours

            $scope.getAssetClassesForFund = function (fundCode)
            {
                if (typeof fundCode === "undefined" || fundCode === null || fundCode === "")
                {
                    $scope.assetClasses = [];
                    $scope.assetClassesTotalPercentage = 0.00;
                    return;
                }

                $scope.unmappedAssetClasses = [];

                fundAssetClassesService.getAssetClasses(fundCode).success(function (response)
                {
                    $scope.fundAssets = response;
                    $scope.assetClasses = response.AssetClass;
                    $scope.assetClassesTotalPercentage = sumArray(response.AssetClass, "Value");

                    fundAssetClassesService.getUnmappedAssetClassesForFund(fundCode).success(function (response)
                    {
                        $scope.unmappedAssetClasses = response;
                    });
                });
            };

            $scope.editAssets = function (assetClass)
            {
                assetClass.OriginalValue = assetClass.Value;
                assetClass.InstructionType = 'Update';
                assetClass.$editMode = true;
            };
            /*
            $scope.deleteAssets = function (assetClass) {
                
                assetClass.InstructionType = 'Delete';
                assetClass.$editMode = false;
                assetClass.$deleteMode = true;
            };
            
            $scope.saveEditAssets = function (assetClass)
            {
                assetClass.OriginalValue = assetClass.Value;
                assetClass.$editMode = false;

                $scope.assetClassesTotalPercentage = sumArray($scope.fundAssets.AssetClass, "Value");
            };
            */
            
            $scope.deleteAssets = function (assetClass,fundCode) {
                assetClass.InstructionType = 'Delete';
                fundAssetClassesService.saveFundAssets(assetClass, fundCode).success(function () {
                    assetClass.Status = 'PendingAuthorise';
                    assetClass.$editMode = false;
                    showMessage('Asset Values set for deletion.Pending Authorisation.');
                });
            };

            $scope.saveEditAssets = function (assetClass, fundCode) {
                fundAssetClassesService.saveFundAssets(assetClass,fundCode).success(function () {
                    assetClass.Status = 'PendingAuthorise';
                    assetClass.$editMode = false;
                    showMessage('Asset Values saved successfully.Pending Authorisation.');
                });

                $scope.assetClassesTotalPercentage = sumArray($scope.fundAssets.AssetClass, "Value");
            };
            
            $scope.cancelEditAssets = function (assetClassList)
            {
                assetClassList.Value = assetClassList.OriginalValue;
                assetClassList.$editMode = false;
            };

           

            $scope.cancelAddUnmappedAssetsToFund = function () {
                $scope.selectedAssets = undefined;
            };

            $scope.removeNewAssets = function (assetClass) {
                for (var i = 0; i < $scope.assetClasses.length; i++) {
                    if ($scope.assetClasses[i].Name === assetClass.Name)
                        $scope.assetClasses.splice(i, 1);
                }

                assetClass.Value = 0;

                $scope.unmappedAssetClasses.push(assetClass);
            };

            $scope.saveFundAssets = function () {
                fundAssetClassesService.saveFundAssets($scope.fundAssets).success(function () {
                    $scope.fundAssets.Status = 'PendingAuthorise';
                    showMessage('Asset Values saved successfully');
                });
            };

            
            $scope.addUnmappedAssetsToFund = function (asset,fundCode)
            {
                for (var i = 0; i < $scope.unmappedAssetClasses.length; i++) {
                    if ($scope.unmappedAssetClasses[i].Id === asset.Id) {
                        $scope.unmappedAssetClasses.splice(i, 1);
                    }
                }

                asset.$IsNew = true;
                asset.InstructionType = 'Add';
                
                fundAssetClassesService.saveFundAssets(asset, fundCode).success(function () {
                    asset.Status = 'PendingAuthorise';
                    asset.$editMode = false;
                    showMessage('Asset Values added successfully.Pending Authorisation.');
                });


                //$scope.assetClasses.push(asset);
                $scope.selectedAssets = undefined;
                
                $scope.assetClassesTotalPercentage = sumArray($scope.fundAssets.AssetClass, "Value");
            };

            $scope.cancelAddUnmappedAssetsToFund = function ()
            {
                $scope.selectedAssets = undefined;
            };

            $scope.removeNewAssets = function (assetClass)
            {
                for (var i = 0; i < $scope.assetClasses.length; i++)
                {
                    if ($scope.assetClasses[i].Name === assetClass.Name)
                        $scope.assetClasses.splice(i, 1);
                }

                assetClass.Value = 0;

                $scope.unmappedAssetClasses.push(assetClass);
            };
            
            $scope.saveFundAssets = function ()
            {
                
                fundAssetClassesService.saveFundAssets($scope.fundAssets).success(function ()
                {
                    $scope.fundAssets.Status = 'PendingAuthorise';
                    showMessage('Asset Values saved successfully');
                });
            };
            
            $scope.cancelFundAssets = function ()
            {
                $scope.selectedFund = undefined;
                $scope.fundAssets = undefined;
                $scope.assetClasses = [];
                $scope.unmappedAssetClasses = [];
            };

            $scope.setPendingFundAssetsStatus = function (asset, status)
            {
                
                asset.Status = asset.Status !== status ? status : "PendingAuthorise";
            };

            /*
            $scope.anyPendingFundAssetsSelected = function () {
                
                //$scope.pendingAssetsList = $scope.pendingFundAssetsList.AssetClass;
                for (var i = 0; i < $scope.pendingFundAssetsList.length; i++)
                {
                    if ($scope.pendingFundAssetsList[i].Status !== "PendingAuthorise")
                        return true;
                }

                return false;
            };

             $scope.updatePendingFundAssetsStatus = function ()
            {
                
                $scope.application.showLoading = true;

                var fundCode = undefined;
                
                var pendingFundAssets = [];
                var pendingAssets = [];
                for (var i = 0; i < $scope.pendingFundAssetsList.length; i++) {
                    if ($scope.pendingFundAssetsList[i].Status !== "PendingAuthorise")
                        pendingFundAssets.push($scope.pendingFundAssetsList[i]);
                }
            */

            $scope.anyPendingFundAssetsSelected = function () {
                
                for (var i = 0; i < $scope.pendingFundAssetsList.length; i++) {
                    $scope.pendingAssetsList = $scope.pendingFundAssetsList[i].AssetClass;
                    for (var j = 0; j < $scope.pendingAssetsList.length; j++) {
                       
                        if ($scope.pendingAssetsList[j].Status !== "PendingAuthorise")
                            return true;
                    }
                   
                }

                return false;
            };
            
           
        $scope.updatePendingFundAssetsStatus = function ()
                {
                    
                    $scope.application.showLoading = true;

                    angular.copy($scope.pendingFundAssetsList, $scope.pendingFundAssetsListCopy);
                    //angular.copy($scope.pendingFundAssetsList, $scope.pendingFundAssetsListRemove);
                    //$scope.pendingFundAssetsListCopy = $scope.pendingFundAssetsList;
                    var pendingFundAssets = [];
                    var assetClassList = [];
                
                    for (var i = 0; i < $scope.pendingFundAssetsListCopy.length; i++) {

                        $scope.pendingAssetsList = $scope.pendingFundAssetsListCopy[i].AssetClass;
                        
                       // $scope.pendingFundAssetsListCopy[i] = $scope.pendingFundAssetsList[i];
                        $scope.pendingFundAssetsListCopy[i].AssetClass = [];
                        

                        for (var j = 0; j < $scope.pendingAssetsList.length; j++)
                        {
                            if ($scope.pendingAssetsList[j].Status !== "PendingAuthorise")
                                

                            //assetClassList.push($scope.pendingAssetsList[j])
                                $scope.pendingFundAssetsListCopy[i].AssetClass.push($scope.pendingAssetsList[j]);
                            else
                                $scope.pendingFundAssetsListCopy[i].AssetClass.splice(j,1);
                            
                        }
                        if ($scope.pendingFundAssetsListCopy[i].AssetClass.length === 0) 
                            $scope.pendingFundAssetsListCopy.splice(i, 1);
                        //else
                        //{
                        //   
                        //}
                            
                            //$scope.pendingFundAssets.AssetClass = assetClassList;
                            
                            
                    }

                fundAssetClassesService.updatePendingFundAssetsStatus($scope.pendingFundAssetsListCopy).success(function ()
                {
                    
                    for (var i = 0; i < $scope.pendingFundAssetsListCopy.length; i++) {
                        removePendingFundAsset($scope.pendingFundAssetsListCopy[i].FundCode,$scope.pendingFundAssetsListCopy[i].AssetClass);
                    }
                    
                    

                    showMessage("Selected Fund Assets(s) were updated successfully");
                    //$scope.isAuthorised = true;
                    if ($scope.pendingFundAssetsList.length === 0)
                        $scope.isViewVisible = true;

                    $scope.application.showLoading = false;
                });

            };

            $scope.sumAssetClasses = function (assetClasses)
            {
                var total = 0.00;

                for (var i = 0; i < assetClasses.length; i++)
                {
                    total += assetClasses[i].Value;
                }

                return total;
            };

            $scope.openAddAssetClasses = function () {
                
                $scope.$addMode = true;
            };
        }]);
})();