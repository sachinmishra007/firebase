﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('fundAssetClassesService', ['$http', function ($http)
        {
            
            var fundAssetClassesService = {};

            fundAssetClassesService.getAvailableFunds = function ()
            {
                return $http({ url: 'api/FundAssetClasses/GetAvailableFunds' });
            };

            fundAssetClassesService.getAssetClasses = function (fundCode)
            {
                return $http({ url: 'api/FundAssetClasses/' + fundCode });
            };

            fundAssetClassesService.getUnmappedAssetClassesForFund = function (fundCode) {
                return $http({ url: 'api/FundAssetClasses/UnmappedAssetClasses/' + fundCode });
            };
            /*
            fundAssetClassesService.saveFundAssets = function (fundAssets) {
                
                return $http.post('api/FundAssetClasses/', fundAssets);
            };
            */
                

            fundAssetClassesService.saveFundAssets = function (assetClass, fundCode) {
                debugger;
                return $http.post('api/FundAssetClasses/?fundCode=' + fundCode, assetClass, fundCode);
            };

            fundAssetClassesService.getPendingFundAssets = function ()
            {
                
                return $http({ url: 'api/FundAssetClasses/Pending' });
            };

            fundAssetClassesService.updatePendingFundAssetsStatus = function (fundAssets)
            {
                
                return $http.post('api/FundAssetClasses/UpdatePendingFundAssetsStatus', fundAssets);
            }

            return fundAssetClassesService;
        }]);
})();

