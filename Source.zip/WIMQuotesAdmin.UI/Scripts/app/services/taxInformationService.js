﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('taxInformationService', ['$http', function ($http)
        {
            var taxInformationService = {};

            taxInformationService.getTaxInformation = function ()
            {
                return $http({ url: 'api/TaxInformation/GetTaxInformation' });
            };

            taxInformationService.getTaxTables = function ()
            {
                return $http({ url: 'api/TaxInformation/GetTaxTables' });
            };

            taxInformationService.saveTaxBrackets = function (taxTabs, userId)
            {
                return $http.post('api/TaxInformation/SaveTaxBrackets/?userId=' + userId, taxTabs, userId);
            };

            taxInformationService.authoriseTaxBrackets = function (taxTables)
            {
                debugger;
                
                return $http.post('api/TaxInformation/AuthoriseTaxBrackets',taxTables);
            };

            taxInformationService.rejectTaxBrackets = function (reject)
            {
                return $http.post('api/TaxInformation/RejectTaxBrackets', reject);
            };

            taxInformationService.getTaxRebates = function ()
            {
                return $http({ url: 'api/TaxInformation/GetTaxRebates' });
            }

            taxInformationService.saveTaxRebates = function (rebates)
            {
                return $http.post('api/TaxInformation/SaveTaxRebates', rebates);
            }

            taxInformationService.authoriseRebates = function (rebates)
            {
                
                return $http.post('api/TaxInformation/AuthoriseRebates', rebates);
            };

            taxInformationService.rejectRebates = function (rebates)
            {
                return $http.post('api/TaxInformation/rejectRebates', rebates);
            };

            taxInformationService.getPendingTaxTables = function () {
                return $http({ url: 'api/TaxInformation/Pending' });
            };

            return taxInformationService;
        }]);
})();

