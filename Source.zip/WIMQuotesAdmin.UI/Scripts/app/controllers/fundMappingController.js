﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('fundMappingController', ['$scope', '$timeout', 'fundMappingService', function ($scope, $timeout, fundMappingService)
        {
            $scope.fundMappings = [];
            $scope.showOnlyUnmappedFunds = true;
            $scope.limitNameFilter = '';
            $scope.showSuccessMessage = false;
            $scope.pendingMappingList = [];
            $scope.UnmappedFundList = [];
            $scope.newSelectedFund = {};

            $scope.limitNameFilter = '';
            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];

            $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' || $scope.application.currentMenuItem.AccessLevel === 'AdminRights';

            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
            $scope.isViewVisible = false;
            $scope.isretriveVisible = false;
            $scope.isbuttonVisible = true;
            $scope.isPaginiationVisible = true;
            $scope.isRetrivePaginiationVisible = false;
            $scope.ispendingRetrieveVisible = true;

            // Private Methods

            var retrieveMappingList = function ()
            {
                $scope.application.showLoading = true;

                fundMappingService.getFundMappings().success(function (response)
                {
                    $scope.fundMappings = response;
                    $scope.application.showLoading = false;
                });
            }

            var removePendingMapping = function (fundCode)
            {
                for (var i = 0; i < $scope.pendingMappingList.length; i++)
                {
                    if ($scope.pendingMappingList[i].FundCode === fundCode)
                        $scope.pendingMappingList.splice(i, 1);
                }
            }

            var filteredFundMappingsCount = function ()
            {
                var count = 0;

                for (var i = 0; i < $scope.fundMappings.length; i++)
                {
                    if ($scope.filterFundMappings($scope.fundMappings[i]))
                        count++;
                }

                return count;
            };

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 3000);
            };

            var getUnmappedFundList = function ()
            {
                fundMappingService.getUnmappedFunds().success(function (response)
                {
                    $scope.UnmappedFundList = response;
                    //$scope.application.showLoading = false;
                });
            };

            var deleteFundMapping = function (fundMapping)
            {
                if (typeof fundMapping === "undefined" || fundMapping === null || fundMapping.FundCode === "")
                    return;

                fundMapping.InstructionType = 'Delete';

                fundMappingService.stageMappings(fundMapping).success(function ()
                {
                    

                    fundMapping.$editMode = false;
                    fundMapping.Status = 'PendingAuthorise';

                    showMessage('Fund Mappings saved successfully');
                });
            };



            // On Load

            retrieveMappingList();

            if ($scope.isPendingVisible)
            {
                fundMappingService.getPendingMappings().success(function (response)
                {
                    $scope.pendingMappingList = response;
                    $scope.isViewVisible = response.length === 0;
                });
            }
            else
            {
                $scope.isViewVisible = true;
            }


            // Behaviours

            $scope.deleteFundMapping = function (fundMapping)
            {
                if (typeof fundMapping === "undefined" || fundMapping === null || fundMapping.FundCode === "")
                    return;

                fundMapping.InstructionType = 'Delete';

                fundMappingService.stageMappings(fundMapping).success(function ()
                {
                    fundMapping.$editMode = false;
                    fundMapping.Status = 'PendingAuthorise';

                    showMessage('Fund Mappings saved successfully');
                });
            };

            $scope.openAddMappings = function ()
            {
                $scope.selectedUnmapFund = undefined;
                getUnmappedFundList();
                $scope.selectTimePeriod = undefined;
                $scope.newClosePrice = undefined;
                $scope.newPercentage = undefined;
                $scope.$addMode = true;
            }

            $scope.openRetrieveMorningStar = function (fundMapping) {

                $scope.selectedUnmapFund = undefined;
                getUnmappedFundList();
                $scope.selectTimePeriod = undefined;
                $scope.newClosePrice = undefined;
                $scope.newPercentage = undefined;
                $scope.$addMode = false;
                $scope.$retrieveMode = true;
                $scope.isViewVisible = false;
                $scope.isretriveVisible = true;
                $scope.isbuttonVisible = false;
                $scope.isPaginiationVisible = true;
                $scope.isRetrivePaginiationVisible = true;
                $scope.ispendingRetrieveVisible = false;



                //$scope.selectedUnmapFund = undefined;
                //getUnmappedFundList();
                //$scope.selectTimePeriod = undefined;
                //$scope.newClosePrice = undefined;
                //$scope.newPercentage = undefined;
                ////$scope.$addMode = true;
                //$scope.$retrieveMode = true;
            }


            $scope.addPerformanceFeesCancel = function ()
            {
                $scope.$addMode = false;
            }

            $scope.backRetrive = function () {

                $scope.$addMode = false;
                $scope.$retrieveMode = false;
                $scope.isViewVisible = true;
                $scope.isretriveVisible = false;
                $scope.isbuttonVisible = true;
                $scope.isPaginiationVisible = true;
                $scope.ispendingRetrieveVisible = true;

                if ($scope.isPendingVisible && $scope.pendingMappingList.length > 0)
                { $scope.isViewVisible = false; }
                // $scope.$addMode = false;
            }

            $scope.filterFundMappings = function (item)
            {
                return (!$scope.showOnlyUnmappedFunds || !item.IsMapped) &&
                    (item.FundName.toLowerCase().indexOf($scope.limitNameFilter.toLowerCase()) !== -1 ||
                    item.FundCode.toLowerCase().indexOf($scope.limitNameFilter.toLowerCase()) !== -1);
            };

            $scope.filterLimit = function (item)
            {
                return (item.FundName.toLowerCase().indexOf($scope.limitNameFilter.toLowerCase()) !== -1 ||
                    item.FundCode.toLowerCase().indexOf($scope.limitNameFilter.toLowerCase()) !== -1);
            };

            $scope.saveFundMapping = function (fundMapping)
            {
                if (typeof fundMapping === "undefined" || fundMapping === null || fundMapping.FundCode === "")
                    return;



                fundMappingService.stageMappings(fundMapping).success(function ()
                {
                    

                    fundMapping.$editMode = false;
                    fundMapping.Status = 'PendingAuthorise';

                    showMessage('Fund Mappings saved successfully');
                });
            };

            $scope.editLimit = function (limit)
            {
                limit.OriginalValue = limit.MorningStarShareClassId;
                limit.$editMode = true;
            };

            $scope.cancelEditLimit = function (fundLimit)
            {
                fundLimit.MorningStarShareClassId = fundLimit.OriginalValue;
                fundLimit.$editMode = false;
            };

            $scope.cancelRetrieveMS = function (fundLimit) {
                //debugger;
                // fundLimit.IsFundPerform = fundLimit.OriginalValue;
                //fundLimit.IsFundPerform = fundLimit.OriginalIsFundPerform;
                //fundMapping.IsFundManage = fundLimit.OriginalIsFundManage;
                //fundMapping.IsFundAssets = fundLimit.OriginalIsFundAssets;
                //fundMapping.IsFundFacts = fundLimit.OriginalIsFundFacts;
                //fundMapping.IsFundTER = fundLimit.OriginalIsFundTER;
                fundLimit.$editMode = false;
            };

            $scope.saveEditLimit = function (limit)
            {
                fundMappingService.stageMappings(limit).success(function ()
                {
                    limit.Status = 'PendingAuthorise';
                    limit.$editMode = false;

                    showMessage('Fund Mappings saved successfully');
                });
            };

            $scope.updatePendingStatuses = function ()
            {
                debugger;
                $scope.application.showLoading = true;

                var pendingLimits = [];

                for (var i = 0; i < $scope.pendingMappingList.length; i++)
                {
                    if ($scope.pendingMappingList[i].Status !== "PendingAuthorise")
                        pendingLimits.push($scope.pendingMappingList[i]);
                }

                fundMappingService.updatePendingStatuses(pendingLimits).success(function ()
                {
                    debugger;
                    for (var i = 0; i < pendingLimits.length; i++)
                    {
                        removePendingMapping(pendingLimits[i].FundCode);
                    }

                    showMessage("Selected Fund Mappings were updated successfully");

                    if ($scope.pendingMappingList.length === 0)
                    {
                        $scope.isViewVisible = true;
                        $scope.fundMappings = [];
                        retrieveMappingList();
                    }

                    $scope.application.showLoading = false;
                });
            };

            $scope.setPendingLimitStatus = function (limit, status)
            {
                limit.Status = limit.Status !== status ? status : "PendingAuthorise";
            };

            $scope.anyPendingLimitSelected = function ()
            {
                for (var i = 0; i < $scope.pendingMappingList.length; i++)
                {
                    if ($scope.pendingMappingList[i].Status !== "PendingAuthorise")
                        return true;
                }

                return false;
            };

            $scope.addNewMappingFund = function (selectedUnmapFund)
            {
                debugger;

                var newFund =
                    {
                        FundCode: selectedUnmapFund.Code,
                        FundName: selectedUnmapFund.Name,
                        InstructionType: 'Add',
                        Status: 'PendingAuthorise'
                    }

                fundMappingService.stageMappings(newFund).success(function ()
                {
                    var pendingLimits = [];
                    pendingLimits.push(newFund);

                    newFund.Status = 'Authorise';

                    fundMappingService.updatePendingStatuses(pendingLimits).success(function ()
                    {
                        debugger;
                        getUnmappedFundList();
                        retrieveMappingList();
                        showMessage("New mapping fund added successfully");
                    });


                });
            };

            $scope.updateMSFundMapping = function (fundMapping) {
                if (typeof fundMapping === "undefined" || fundMapping === null || fundMapping.FundCode === "")
                    return;
                debugger;
                fundMappingService.updateMSFundMapping(fundMapping).success(function () {


                    fundMapping.$editMode = false;


                    showMessage('Funds Morning Star retrieve saved successfully');
                });
            };

            // Pagination

            $scope.firstPage = function ()
            {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function ()
            {
                if ($scope.currentPage > 0)
                {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function ()
            {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function ()
            {
                return Math.ceil(filteredFundMappingsCount() / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function ()
            {
                if ($scope.currentPage < $scope.pageCount())
                {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function ()
            {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function ()
            {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n)
            {
                $scope.currentPage = n;
            };

            $scope.range = function ()
            {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0)
                {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize)
                {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++)
                {
                    range.push(i);
                }

                return range;
            };

        }]);
})();