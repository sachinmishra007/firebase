﻿using System;
using System.Collections.Generic;
using System.Linq;

using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class UserAccessControlReportLogic : Contracts.IUserAccessControlReportLogic
    {
        #region Constructor

        private readonly WIMQuotesAdmin.DataAccess.Repositories.Contracts.IUserAccessControlReportRepository _userAccessControlReportRepository;


        public UserAccessControlReportLogic(
            IUserAccessControlReportRepository userAccessControlReportRepository)
        {
            _userAccessControlReportRepository = userAccessControlReportRepository;
           
        }

        #endregion

        public List<Entities.UserAccessControlReport> GetUserAccessControlReportData(
            Entities.UserAccessControlReportDetail detail)
        {
            return _userAccessControlReportRepository.GetUserAccessControlReport(detail);
        }

        public List<Entities.User> GetUserRolesReport()
        {
            return _userAccessControlReportRepository.GetUserRolesReport();
        }

        public int[] GetUserRoleCount()
        {
            var users = _userAccessControlReportRepository.GetUserRolesReport();
            int[] counts = new int[3];

            counts[0] = users.Count(f => f.Role == Entities.UserRole.SuperUser);
            counts[1] = users.Count(f => f.Role == Entities.UserRole.AdminUser);
            counts[2] = users.Count(f => f.Role == Entities.UserRole.ReadOnlyUser);

            return counts;
        }
    }
}
