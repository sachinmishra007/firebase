﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('reductionInYieldService', ['$http', function ($http)
        {
            var reductionInYieldService = {};
            
            reductionInYieldService.getReductionInYields = function ()
            {
                return $http({ url: 'api/ReductionInYield/GetReductionInYields' });
            };

            reductionInYieldService.getPendingYields = function ()
            {
                return $http({ url: 'api/ReductionInYield/Pending' });
            };

            reductionInYieldService.stageReductionInYields = function (currentYield)
            {
                return $http.post('api/ReductionInYield', currentYield);
            };

            reductionInYieldService.updatePendingStatuses = function (currentYields)
            {
                return $http.post('api/ReductionInYield/UpdatePendingStatuses', currentYields);
            };

            reductionInYieldService.authoriseReductionInYields = function (currentYields)
            {
                return $http.post('api/ReductionInYield/AuthoriseReductionInYields', currentYields);
            };

            reductionInYieldService.rejectReductionInYields = function (currentYields)
            {
                return $http.post('api/ReductionInYield/RejectReductionInYields', currentYields);
            };

            return reductionInYieldService;
        }]);
})();
