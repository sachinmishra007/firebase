﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.DataAccess.Repositories.Contracts;


namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class InactiveFundRepository : IinactiveFundRepository
    {
        public List<Entities.InactiveFund> GetInactiveFunds()
        {

            using (var context = new DataAccess.PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var result = context.RetrieveInactiveFunds();
                if (result == null)
                    return null;
                return result.Select(a => new Entities.InactiveFund{
                                       FundCode = a.FundCode,
                                       FundName= a.FundName,
                                       IsWrap = (bool)a.IsWrap,                                     
                }).ToList();
            }

        }


        public List<Entities.InactiveFund> GetUnmappedFunds()
        {
            using (var context = new DataAccess.PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var result = context.GetUnmappedFunds();
                if (result == null)
                    return null;
                return result.Select(a => new Entities.InactiveFund
                {
                    FundCode = a.FundCode,
                    FundName = a.FundName,
                    IsWrap = a.IsWrap
                }).ToList();
            }

        }

        public void AddInactiveFund(Entities.InactiveFund inactiveFund, string userId)
        {
            using (var context = new DataAccess.PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var fund = new PortfolioAdminService.InactiveFund
                {
                    FundCode = inactiveFund.FundCode,
                    FundName = inactiveFund.FundName,
                    IsWrap = inactiveFund.IsWrap,
                    IsDeleted = false,
                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now                  
                };
                context.SaveInactivefund(fund);

            }
        }

        public void DeleteInactiveFund(string fundCode, string userId)
        {
            using (var context = new DataAccess.PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.DeleteInactiveFund(fundCode,userId,DateTime.Now);
            }
        }
    }
}
