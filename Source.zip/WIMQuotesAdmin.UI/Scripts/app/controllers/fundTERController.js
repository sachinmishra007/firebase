﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('fundTERController', ['$scope', '$timeout', 'fundTERService', 'lookupService', 'wrapService',
            function ($scope, $timeout, fundTERService, lookupService, wrapService)
        {
            $scope.unmappedFundsList = [];
            $scope.fundTERsList = [];
            $scope.pendingFundTERsList = [];
            $scope.wrapsList = [];

            $scope.fundTypes = lookupService.getFundTypes();
            $scope.selectedFundType = $scope.fundTypes[0];

            $scope.fundNameFilter = '';
            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];

            $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' ||
                $scope.application.currentMenuItem.AccessLevel === 'AdminRights';

            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
            $scope.isViewVisible = false;
            $scope.$addMode = false;


            // Private Methods

            var removePendingFundTER = function (fundCode)
            {
                for (var i = 0; i < $scope.pendingFundTERsList.length; i++)
                {
                    if ($scope.pendingFundTERsList[i].FundCode === fundCode)
                        $scope.pendingFundTERsList.splice(i, 1);
                }
            }

            var filteredFundTERCount = function ()
            {
                var count = 0;

                for (var i = 0; i < $scope.fundTERsList.length; i++)
                {
                    if ($scope.filterFundTER($scope.fundTERsList[i]))
                        count++;
                }

                return count;
            };

            var retrieveFundTERList = function ()
            {
                $scope.application.showLoading = true;

                var fundType = $scope.selectedFundType.Code;
                var fundCode = angular.isDefined($scope.selectedWrap) ? $scope.selectedWrap.Code : '';

                fundTERService.getFundTERs(fundType, fundCode).success(function (response)
                {
                    $scope.fundTERsList = response;
                    $scope.application.showLoading = false;
                });
            }

            var retrieveFundTERList = function (isShow) {
                debugger;
                $scope.application.showLoading = isShow;

                var fundType = $scope.selectedFundType.Code;
                var fundCode = angular.isDefined($scope.selectedWrap) ? $scope.selectedWrap.Code : '';

                fundTERService.getFundTERs(fundType, fundCode).success(function (response) {
                    $scope.fundTERsList = response;
                    $scope.application.showLoading = false;
                });
            }

            var retrieveUnmappedFundsList = function ()
            {
                fundTERService.getUnmappedFunds().success(function (response)
                {
                    $scope.unmappedFundsList = response;
                });
            };

            var retrieveWrapsList = function ()
            {
                wrapService.getAvailableWraps().success(function (response)
                {
                    $scope.wrapsList = response;
                });
            };

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 5000);
            }


            // On Load

            retrieveFundTERList();
            retrieveUnmappedFundsList();
            retrieveWrapsList();
            
            if ($scope.isPendingVisible)
            {
                fundTERService.getPendingFundTERs().success(function (response)
                {
                    $scope.pendingFundTERsList = response;
                    $scope.isViewVisible = response.length === 0;
                });
            }
            else
            {
                $scope.isViewVisible = true;
            }


            // Behaviours

            $scope.filterFundTER = function (item)
            {
                return (item.FundName.toLowerCase().indexOf($scope.fundNameFilter.toLowerCase()) !== -1 ||
                    item.FundCode.toLowerCase().indexOf($scope.fundNameFilter.toLowerCase()) !== -1);
            };

            $scope.editTER = function (fundTER)
            {
                
                fundTER.OriginalValue = fundTER.Value;
                fundTER.$editMode = true;
            };

            $scope.cancelEditTER = function (fundTER)
            {
                
                fundTER.Value = fundTER.OriginalValue;
                fundTER.$editMode = false;
            };

            $scope.saveEditTER = function (fundTER)
            {
                fundTERService.saveFundTER(fundTER).success(function ()
                {
                    fundTER.Status = 'PendingAuthorise';
                    fundTER.$editMode = false;

                    showMessage('Total Expense Ratio saved successfully. Pending authorisation.');
                });
            };

            $scope.deleteTER = function (fundTER)
            {
                fundTER.InstructionType = 'Delete';

                fundTERService.saveFundTER(fundTER).success(function ()
                {
                    fundTER.Status = 'PendingAuthorise';
                    fundTER.$editMode = false;

                    showMessage('Total Expense Ratio set for deletion. Pending authorisation.');
                });
            };

            $scope.openAddTER = function ()
            {
                $scope.$addMode = true;
            };

            $scope.addTERCancel = function ()
            {
                $scope.$addMode = false;
            }

            $scope.addNewTER = function (fund, totalExpenseRatio)
            {
                var fundTER = {
                    FundCode: fund.Code,
                    FundName: fund.Name,
                    TotalExpenseRatio: totalExpenseRatio,
                    InstructionType: 'Add'
                }

                fundTERService.saveFundTER(fundTER).success(function ()
                {
                    
                    retrieveFundTERList(false);
                    $scope.$addMode = false;

                    showMessage('Total Expense Ratio added successfully. Pending authorisation.');
                });
            };

            $scope.updatePendingStatuses = function ()
            {
                $scope.application.showLoading = true;

                var pendingFunds = [];

                for (var i = 0; i < $scope.pendingFundTERsList.length; i++)
                {
                    if ($scope.pendingFundTERsList[i].Status !== "PendingAuthorise")
                        pendingFunds.push($scope.pendingFundTERsList[i]);
                }

                fundTERService.updatePendingStatuses(pendingFunds).success(function ()
                {
                    for (var i = 0; i < pendingFunds.length; i++)
                    {
                        removePendingFundTER(pendingFunds[i].FundCode);
                    }

                    showMessage("Selected Fund Total Expense Ratios were updated successfully");

                    if ($scope.pendingFundTERsList.length === 0)
                    {
                        $scope.isViewVisible = true;
                        $scope.fundTERsList = [];

                        retrieveFundTERList();
                        retrieveUnmappedFundsList();
                    }

                    $scope.application.showLoading = false;
                });
            };

            $scope.selectedFundTypeChanged = function ()
            {
                $scope.selectedWrap = undefined;
                $scope.fundNameFilter = '';
                retrieveFundTERList();
            };

            $scope.selectedWrapChanged = function ()
            {
                retrieveFundTERList();
            };

            $scope.setPendingFundTERStatus = function (fundTER, status)
            {
                fundTER.Status = fundTER.Status !== status ? status : "PendingAuthorise";
            };

            $scope.anyPendingFundTERSelected = function ()
            {
                for (var i = 0; i < $scope.pendingFundTERsList.length; i++)
                {
                    if ($scope.pendingFundTERsList[i].Status !== "PendingAuthorise")
                        return true;
                }

                return false;
            };


            // Pagination

            $scope.firstPage = function ()
            {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function ()
            {
                if ($scope.currentPage > 0) {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function ()
            {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function ()
            {
                return Math.ceil(filteredFundTERCount() / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function ()
            {
                if ($scope.currentPage < $scope.pageCount()) {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function ()
            {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function ()
            {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n)
            {
                $scope.currentPage = n;
            };

            $scope.range = function ()
            {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0) {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize) {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++) {
                    range.push(i);
                }

                return range;
            };

        }]);
})();