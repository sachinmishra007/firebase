﻿
(function () {
    'use strict';

    angular.module('adminApp.controllers')
        .controller('guaranteedGrowthRateController', ['$scope', '$filter', 'guaranteedGrowthRateService', function ($scope, $filter, guaranteedGrowthRateService) {
            $scope.productTypes = guaranteedGrowthRateService.GetProductTypes();
            $scope.guarantors = guaranteedGrowthRateService.GetGuarantors();
            $scope.selectedProduct = {};
            $scope.selectedGuarantor = {};
            $scope.capturedRates = {};
            $scope.canAuth = false;
            $scope.minStartDate = new Date();
            $scope.maxMaturityDate = new Date();
            $scope.maxRateDate = new Date();
            $scope.maxPlacementDate = new Date();
            $scope.canSave = true;

            // On Load
            $scope.init = function () {
                //debugger;
                var offsetMs = 1000 * 60 * 60 * 24 * 7; // Offset by 7 Days;
                //var offsetMsMaturity = 1000 * 60 * 60 * 24 * 1825;// Offset by 7 Days;
                var offsetMsMaturity = 1000 * 60 * 60 * 24 * 3650;// Offset by 7 Days;
                var offsetMsrateEndDate = 1000 * 60 * 60 * 24 * 15;// Offset by 7 Days;

                $scope.minStartDate.setTime($scope.minStartDate.getTime() - offsetMs);
                $scope.maxMaturityDate.setTime($scope.maxMaturityDate.getTime() + offsetMsMaturity);
                //$scope.maxRateDate.setTime($scope.maxRateDate.getTime() + offsetMsrateEndDate);

                $scope.capturedRates.StartDate = $scope.formatDate(new Date());
                $scope.populateDates();
                $scope.capturedRates.User = $scope.application.userProfile.Id;
                $scope.determineAccess();
            };


            //Behaviors
            $scope.determineAccess = function () {
                //debugger;
                //if (($scope.application.userProfile.Role === 'SuperUser') && $scope.application.userProfile.Id !== $scope.capturedRates.User && $scope.capturedRates.EffectiveRate1 > 0)
                if (($scope.application.userProfile.Role === 'SuperUser') && $scope.application.userProfile.Id !== $scope.capturedRates.User && $scope.capturedRates.FeeStatus === "Pending")
                {
                    $scope.canAuth = true;
                    $scope.canSave = false;
                }
                
                else
                {
                    $scope.canAuth = false;
                    $scope.canSave = true;

                }

                if ($scope.capturedRates.FeeStatus === "Authorised")
                    $scope.canSave = false;
                    
                   
            };

            $scope.getLatestRatesAndUser = function () {
                guaranteedGrowthRateService.GetLatestRates($scope.selectedProduct).success(function (response) {
                    $scope.capturedRates = response;
                   
                    $scope.determineAccess();
                });
            };

            $scope.captureRates = function () {
                //debugger;
                $scope.capturedRates.Guarantor = $scope.selectedGuarantor.Code;
                $scope.capturedRates.ProductCode = $scope.selectedProduct.Code;
                $scope.capturedRates.User = $scope.application.userProfile.Id;

                guaranteedGrowthRateService.CaptureRates($scope.capturedRates).success(function (response) {
                    $scope.capturedRates = response;
                    $scope.selectedGuarantor.Code = $scope.capturedRates.Guarantor;
                    $scope.determineAccess();
                });
            };

            $scope.updateRates = function () {
               // debugger;
                guaranteedGrowthRateService.GetLatestRates($scope.selectedProduct.Code).success(function (response) {
                    $scope.capturedRates = response;
                    $scope.selectedGuarantor.Code = $scope.capturedRates.Guarantor;
                    $scope.populateDates();
                    $scope.determineAccess();
                });
            };

            $scope.authoriseRates = function () {

                //debugger;
                $scope.capturedRates.ProductCode = $scope.selectedProduct.Code;
                guaranteedGrowthRateService.AuthoriseRates($scope.capturedRates).success(function (response) {
                    $scope.canAuth = false;
                   
                });
            };

            $scope.rejectRates = function () {
                var jsonCode = angular.toJson($scope.selectedProduct.Code);

                guaranteedGrowthRateService.RejectRates(jsonCode).success(function () {
                    $scope.canAuth = false;
                  
                });
            };

            $scope.populateDates = function () {
                //debugger;
                var date = new Date();
                var day = date.getUTCDate();

                if ($scope.capturedRates.StartDate !== null) {
                    if ($scope.capturedRates.StartDate.length !== 10) {
                        $scope.capturedRates.StartDate = $scope.formatDate($scope.capturedRates.StartDate);
                    }
                }
                else
                {
                    $scope.capturedRates.StartDate = $scope.formatDate(new Date());
                }
               
                //var startDate = $filter('date')($scope.capturedRates, "yyyy/MM/dd");

                var convertedDate = new Date(Date.parse($scope.capturedRates.StartDate.replace(/-/g, " "))) ;
                //var convertedDate = new Date(Date.parse(startDate.replace(/-/g, " ")));
                $scope.capturedRates.PlacementDate = $scope.formatDate($scope.getPlacementDate(convertedDate));
                $scope.capturedRates.EndDate = $scope.formatDate($scope.getEndDate(convertedDate));
                if ($scope.capturedRates.MaturityDate === null || $scope.capturedRates.MaturityDate === undefined) {
                    $scope.capturedRates.MaturityDate = $scope.getMaturityDate();
                }
            };

            $scope.getPlacementDate = function (date) {
                //debugger;
                var date = new Date($scope.getNextWeekMonday(date));
                $scope.maxPlacementDate.setTime(date);
                return date;
            };

            $scope.getEndDate = function (date) {
               //debugger;

                var date = new Date($scope.getNextWeekSaturday(date));
                $scope.maxRateDate.setTime(date);
                return date;

            };

            $scope.getMaturityDate = function () {
                //debugger;
                var padLeft = new RegExp(".{2}$");
                var month = $scope.capturedRates.StartDate.substring(5, 7);
                var year = parseInt($scope.capturedRates.StartDate.substring(0, 4)) + 5;
                var day = $scope.capturedRates.StartDate.substring(8, 10);

                return (year + "/" + month + "/" + day);
            };

            $scope.getNextDayOfWeek = function (date, dayOfWeek) {
                //debugger;
                var date1 = Date();
                var date2 = date1.getDate();
                var resultDate = new date2.getTime();

                resultDate.setDate(date2.getDate() + (7 + dayOfWeek - date2.getDay()) % 7);

                return resultDate;
            };

            $scope.getNextWeekMonday = function (SDate) {
              //debugger;
                var date = new Date();

                var d = new Date(SDate);

                var d1 = d.getDate();
                var d2 = d.getDay();
                var diff = d.getDate() - d.getDay() + 1

                if (d.getDay() == 0)
                    diff -= 7;
                diff += 7; // ugly hack to get next monday instead of current one
                return new Date(d.setDate(diff));
            };

            //$scope.getNextWeekMonday = function ()
            //{
            //    debugger;
            //    var date = new Date();
            //    var d = new Date(date.getTime());
            //    var d1 = d.getDate();
            //    var d2 = d.getDay();

            //    var diff = d.getDate() - d.getDay() + 1;
            //    if (d.getDay() == 0)
            //        diff -= 7;
            //    diff += 7; // ugly hack to get next monday instead of current one
            //    return new Date(d.setDate(diff));
            //};

            $scope.getNextWeekSaturday = function (SDate) {
               //debugger;
                
                var date = new Date(SDate);
                var date0 = new Date()
                var d = $scope.getNextWeekMonday(date);
                var d0 = new Date(date0.getTime());
                //return d.getDate() < d0.getDate() ? new Date(d.setDate(d.getDate() - 2)) : new Date(d.setDate(d.getDate() + 5));

                return new Date(d.setDate(d.getDate()- 2));
            };

            //$scope.getNextWeekSaturday = function () {
            //    debugger;
            //    //debugger;
            //    var date = new Date();
            //    var d = $scope.getNextWeekMonday();
            //    return new Date(d.setDate(d.getDate() + 5));
            //    //return new Date(d.setDate(d.getDate() + 10));
            //};

            $scope.formatDate = function (date) {
                // debugger;
                var year, month, day;
                year = String(date.getFullYear());
                month = String(date.getMonth() + 1);
                if (month.length == 1) {
                    month = "0" + month;
                }
                day = String(date.getDate());
                if (day.length == 1) {
                    day = "0" + day;
                }
                return year + "/" + month + "/" + day;
            };
        }]);
})();
