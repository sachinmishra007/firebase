﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('taxRebateService', ['$http', function ($http)
        {
            var taxRebateService = {};
            
            taxRebateService.getTaxRebates = function ()
            {
                return $http({ url: 'api/TaxInformation/GetTaxRebates' });
            }

            taxRebateService.saveTaxRebates = function (rebates)
            {
                return $http.post('api/TaxInformation/SaveTaxRebates', rebates);
            }

            taxRebateService.authoriseRebates = function (rebates)
            {
                
                return $http.post('api/TaxInformation/AuthoriseRebates', rebates);
            };

            taxRebateService.rejectRebates = function (rebates)
            {
                return $http.post('api/TaxInformation/rejectRebates', rebates);
            };

            return taxRebateService;
        }]);
})();

