﻿using System.Web.Optimization;

namespace WIMQuotesAdmin.UI
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            RegisterCommonBundles(bundles);
            RegisterCustomBundles(bundles);
        }

        private static void RegisterCommonBundles(BundleCollection bundles)
        {

            // Scripts 

            var ckEditorBundle = new ScriptBundle("~/Scripts/common/ckeditor/bundle").Include("~/Scripts/common/ckeditor/ckeditor.js");
            ckEditorBundle.Transforms.Clear(); // Skips Transformation and will not minify bundle
            bundles.Add(ckEditorBundle);

            var chartsBundle = new ScriptBundle("~/Scripts/common/charts/bundle").Include(
                "~/Scripts/common/charts/chart.min.js",
                "~/Scripts/common/angular-chart.min.js");
            chartsBundle.Transforms.Clear(); // Skips Transformation and will not minify bundle
            bundles.Add(chartsBundle);

            bundles.Add(new ScriptBundle("~/Scripts/common/bundle").Include(
                "~/Scripts/common/jquery-{version}.js",
                "~/Scripts/common/chosen.jquery.min.js",
                "~/Scripts/common/angular-1.4.2.js",
                "~/Scripts/common/angular-sanitize-1.4.2.min.js",
                "~/Scripts/common/angular-file-upload.min.js",
                "~/Scripts/common/angular.directives.js"));


            // CSS

            bundles.Add(new StyleBundle("~/Content/styles/common/bundle").Include(
                "~/Content/styles/common/bootstrap.css",
                "~/Content/styles/common/chosen.css"));

            bundles.Add(new StyleBundle("~/Content/styles/site/bundle").Include(
                "~/Content/styles/site/master.css",
                "~/Content/styles/site/input.css",
                "~/Content/styles/site/site.css"));
        }

        private static void RegisterCustomBundles(BundleCollection bundles)
        {

            bundles.Add(new ScriptBundle("~/Scripts/app/bundle")
                .Include("~/Scripts/app/app.js",
                    "~/Scripts/app/filters.js")
                .IncludeDirectory("~/Scripts/app/controllers/", "*.js", true)
                .IncludeDirectory("~/Scripts/app/directives/", "*.js", true)
                .IncludeDirectory("~/Scripts/app/services/", "*.js", true));

        }
    }
}
