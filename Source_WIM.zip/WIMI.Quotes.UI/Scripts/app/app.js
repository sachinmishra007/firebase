﻿
(function () {
    'use strict';
     
    var quotesApp = angular.module('quotesApp', [
        'quotesApp.services',
        'quotesApp.controllers',
        'common.directives'
    ]);

    angular.module('quotesApp.controllers', []);
    angular.module('quotesApp.services', []);


    // Global Configuration

    quotesApp.constant('numberFormat', {
        fraction: 2,
        thousandSeparator: ',',
        separatorRegex: /\B(?=(\d{3})+(?!\d))/g
    });

    //DEV-19457
    quotesApp.constant('sectionType', {
        sectionNames: {
            FEE: 'FEE',
            INCOME:'INCOME'
        }
    });

    quotesApp.config(['$httpProvider', '$compileProvider', function ($httpProvider, $compileProvider) {
        $httpProvider.interceptors.push('authInterceptorService');
        //$compileProvider.debugInfoEnabled(false); //Set to false in Production for performance increase
    }]);

})();
