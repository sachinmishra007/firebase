﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMQuotesAdmin.Entities
{
    public class TaxTables
    {
        public int Id { get; set; }
        public double MinimumAmount { get; set; }
        public double MaximumAmount { get; set; }
        public double RateAmount { get; set; }
        public double RatePercent { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public StagingStatus Status { get; set; }
        public string UserId { get; set; }
    }
}
