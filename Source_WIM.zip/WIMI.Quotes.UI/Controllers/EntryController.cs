﻿using System;
using System.Linq;
using System.Web.Mvc;
using System.Web.Security;

using WIMI.Quotes.Model.Domain.Contracts;

namespace WIMI.Quotes.UI.Controllers
{
    public class EntryController : Controller
    {
        #region Contructors & DI

        private readonly IUserLogic _userLogic;
        private readonly IIntegrationLogic _integrationLogic;

        public EntryController(
            IUserLogic userLogic,
            IIntegrationLogic integrationLogic)
        {
            _userLogic = userLogic;
            _integrationLogic = integrationLogic;
        }

        #endregion

        [Route("Entry/TransferApi/{sessionApiKey}")]
        [AllowAnonymous]
        public ActionResult TransferApi(string sessionApiKey)
        {
            if (String.IsNullOrWhiteSpace(sessionApiKey))
                return RedirectToAction("Index", "Error");

            var userId = _integrationLogic.GetSolutionUserIdForSession(sessionApiKey);

            if (String.IsNullOrWhiteSpace(userId) || !_userLogic.IsValidUser(userId))
                return RedirectToAction("Index", "Error");

            var quoteGroupId = Guid.NewGuid();
            var quoteItemGuids = _integrationLogic.ProcessSolutionQuoteItem(quoteGroupId, sessionApiKey);

            if (quoteItemGuids.Any(guid => guid == Guid.Empty))
            {
                return RedirectToAction("Index", "Error");
            }

            FormsAuthentication.SetAuthCookie(userId, false);

            return RedirectToAction("Index", "QuoteForm", new { QuoteGroupId = quoteGroupId });
        }
        
        [AllowAnonymous]
        public ActionResult TransferApiUser(string enterprise)
        {
            if (String.IsNullOrWhiteSpace(enterprise))
            {
                Common.Helpers.AuditHelper.Log("No transfer settings set");
                return RedirectToAction("Index", "Error");
            }

            var user = _integrationLogic.GetSessionUser(enterprise);

            if (String.IsNullOrEmpty(user))
            {
                Common.Helpers.AuditHelper.Log(String.Format("Transfer Api User failed for enterprise key {0}, broker could not be retrieved", enterprise));
                return RedirectToAction("Index", "Error");
            }

            FormsAuthentication.SetAuthCookie(user, false);

            return RedirectToAction("Index", "QuoteForm");
        }
    }
}
