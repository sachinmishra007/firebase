﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.DataAccess.Repositories.Mappings
{
    public static class SLAApplicationServiceMapping
    {
        public static SLAService.FundZeroFee ToFundZeroFee(Entities.FundZeroFee fundZeroFee)
        {
            if (fundZeroFee == null)
                return null;

            return new SLAService.FundZeroFee
            {
                FundId = fundZeroFee.FundId,
                AIMSInitialFee = fundZeroFee.AIMSInitialFee,
                AIMSOngoingFee = fundZeroFee.AIMSOngoingFee,
                AIMSRecurringFee = fundZeroFee.AIMSRecurringFee,
                FAInitialFee = fundZeroFee.FAInitialFee,
                FAOngoingFee = fundZeroFee.FAOngoingFee,
                FARecurringFee = fundZeroFee.FARecurringFee,
                EACAdminFee = fundZeroFee.EACAdminFee

            };
        }

        public static SLAService.FundProductRule ToFundMinimum(Entities.FundMinimum fundMinimum)
        {
            if (fundMinimum == null)
                return null;

            return new SLAService.FundProductRule
            {
                FundId = fundMinimum.FundCode,
                ProductId = fundMinimum.ProductId,
                MinimumAmnt = fundMinimum.FundMinimumAmount,
                TransactionTypeId = fundMinimum.TransactionTypeId,
                TransactionTypeDesc = fundMinimum.TransactionDesc,
            };
        }


    }
}
