﻿(function () {
    "use strict";

    angular.module('morningStar.controllers')
        .controller('MorningStarFundScreener', ['$scope', 'MorningStarService', 'lookupService',
            function ($scope, MorningStarService, lookupService) {

                $scope.init = function () {
                    
                };

                $scope.init();


            }]);
})();