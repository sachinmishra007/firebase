﻿namespace WIMQuotesAdmin.Entities
{
    public class GrowthRates
    {
        public double EffectiveRate { get; set; }
        public double Yield { get; set; }
        public string StartDate { get; set; }
        public string ProductCode { get; set; }
        public string MaturityValue { get; set; }
        public string Guarantor { get; set; }
        public string EndDate { get; set; }
        public string PlacementDate { get; set; }
        public string MaturityDate { get; set; }
        public string User { get; set; }
        public double TaxLossFee1 { get; set; }
        public double EffectiveRate1 { get; set; }
        public double UnderwriterFee1 { get; set; }
        public double AIMSFee1 { get; set; }
        public double SemiAnnual { get; set; }
        public double TaxLossFee2 { get; set; }
        public double EffectiveRate2 { get; set; }
        public double UnderwriterFee2 { get; set; }
        public double AIMSFee2 { get; set; }
        public double TaxLossFee3 { get; set; }
        public double EffectiveRate3 { get; set; }
        public double UnderwriterFee3 { get; set; }
        public double AIMSFee3 { get; set; }
        public double TaxLossFee4 { get; set; }
        public double EffectiveRate4 { get; set; }
        public double UnderwriterFee4 { get; set; }
        public double AIMSFee4 { get; set; }
        public string FeeStatus { get; set; }

    }
}