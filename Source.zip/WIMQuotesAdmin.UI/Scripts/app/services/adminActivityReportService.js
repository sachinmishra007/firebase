﻿
(function ()
{
    'use strict';

    angular.module('adminApp.services')
        .factory('adminActivityReportService', ['$http', function ($http)
        {
            var adminActivityReportService = {};

            adminActivityReportService.getAdminActivityReports = function (dtoReportDetails)
            {
                return $http({ method: 'GET', url: 'api/AdminActivityReport/Get', params: dtoReportDetails });
            };

            return adminActivityReportService;
        }]);
})();

    