﻿using System;
using System.Collections.Generic;
using System.Linq;

using WIMQuotesAdmin.Common;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class FundFactSheetRepository : Contracts.IFundFactSheetRepository
    {
        public List<Entities.FundFactSheet> GetFundFactSheets(Entities.FundType fundType, string fundCode)
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var fundFactSheets = context.GetFundFactSheetsDetails(Mappings.PortfolioAdminServiceMapping.ToFundType(fundType), fundCode);

                if (fundFactSheets == null)
                    return null;

                return fundFactSheets.Select(f => new Entities.FundFactSheet
                {
                    FundCode = f.FundCode,
                    FundName = f.FundName,
                    FileUrl = f.MorningStarURL,
                    HasFileAvailable = f.HasFileAvailable,
                    ModifiedDateTime = f.DateModified,
                    MorningStarURL = f.MorningStarURL,
                   Type = Mappings.PortfolioAdminServiceMapping.FromFundType(f.Type)
                
                }).ToList();
            }
        }

        public List<Entities.FundFactSheet> GetPendingFundFactSheets()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.pGetPendingFundFactSheets()
                    .Where(f => f.Status == (int)Entities.StagingStatus.PendingAuthorise)
                    .Select(Mappings.WIMQuotesAdminStagingMapping.FromFundFactSheetStaging).ToList();
            }
        }

        public Entities.FundFactSheet GetPendingFundFactSheet(string fundCode)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                return context.FundFactSheetStagings
                    .Where(f => f.Status == (int)Entities.StagingStatus.PendingAuthorise && f.FundCode == fundCode)
                    .Select(Mappings.WIMQuotesAdminStagingMapping.FromFundFactSheetStaging)
                    .FirstOrDefault();
            }
        }

        public List<Entities.Fund> GetUnmappedFunds()
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                PortfolioAdminService.FundType type = Mappings.PortfolioAdminServiceMapping.ToFundType(Entities.FundType.Individual);
                var funds = context.GetUnmappedFactSheetFunds(type);
                return funds == null ? new List<Entities.Fund>() : funds.Select(Mappings.PortfolioAdminServiceMapping.FromFund).ToList();
            }
        }

        public void SaveFundFactSheetToStaging(Entities.FundFactSheet fundFactSheet)
        {
            if (fundFactSheet == null || string.IsNullOrWhiteSpace(fundFactSheet.UserId))
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundFactSheet = Mappings.WIMQuotesAdminStagingMapping.ToFundFactSheetStaging(fundFactSheet);

                if (contextFundFactSheet == null)
                    return;

                context.FundFactSheetStagings.Add(contextFundFactSheet);
                context.SaveChanges();
            }
        }

        public void UpdateFundFactSheetStagingStatus(string fundCode, Entities.StagingStatus status, string userId)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundFactSheets = context.FundFactSheetStagings
                    .Where(f => f.FundCode == fundCode &&
                                f.Status == (int)Entities.StagingStatus.PendingAuthorise);

                foreach (var contextFundFactSheet in contextFundFactSheets)
                {
                    contextFundFactSheet.Status = (int)status;
                    contextFundFactSheet.ModifiedUserId = userId;
                    contextFundFactSheet.ModifiedDateTime = DateTime.Now;
                }

                context.SaveChanges();
            }
        }

        public void SaveAuthorisedFundFactSheet(Entities.FundFactSheet fundFactSheet)
        {
            if (fundFactSheet == null)
                return;

            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.SaveFundFactSheet(Mappings.PortfolioAdminServiceMapping.ToFundFactSheet(fundFactSheet));
            }
        }

        public void DeleteAuthorisedFundFactSheet(string fundCode)
        {
            if (string.IsNullOrWhiteSpace(fundCode))
                return;

            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.DeleteFundFactSheet(new PortfolioAdminService.FundFactSheet
                {
                    FundCode = fundCode
                });
            }
        }

        public Entities.File GetFundFactSheetFile(string fundCode)
        {
            if (string.IsNullOrWhiteSpace(fundCode))
                return null;

            using (var context = new PortfolioPerformanceService.PortfolioPerformanceServiceClient())
            {
                var fundFactSheet = context.GetFundFactSheets(fundCode).FirstOrDefault();

                if (fundFactSheet == null)
                    return null;

                string fileName = String.Format("{0}.{1}", fundFactSheet.FundCode, Constants.FileExtensions.Pdf);

                return new Entities.File
                {
                    Name = fileName,
                    FullQualifiedName = fileName,
                    Data = fundFactSheet.File
                };
            }
        }


        public List<Entities.Fund> GetUnmappedFundsByType(Entities.FundType fundType)
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                PortfolioAdminService.FundType type = Mappings.PortfolioAdminServiceMapping.ToFundType(fundType);
                
                var funds = context.GetUnmappedFactSheetFunds(type);
                var pendingFundFactSheets = GetPendingFundFactSheets();

                if (pendingFundFactSheets == null)
                    pendingFundFactSheets = new List<Entities.FundFactSheet>();

                funds = funds.Where(f => !pendingFundFactSheets.Any(pf => pf.FundCode == f.Code)).ToList();

                return funds == null ? new List<Entities.Fund>() : funds.Select(Mappings.PortfolioAdminServiceMapping.FromFund).ToList();
            }
        }
    }
}

