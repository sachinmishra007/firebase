﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IinactiveFundLogic
    {
        List<Entities.InactiveFund> GetInactiveFunds();
        List<Entities.InactiveFund> GetUnmappedFunds(); 
        void AddInactiveFund(Entities.InactiveFund inactiveFund, string userId);
        void DeleteInactiveFund(string fundCode, string userId);
    }
}
