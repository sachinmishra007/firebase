﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMQuotesAdmin.Entities
{
    public class TaxRebates
    {
        public double PrimaryRebate { get; set; }
        public double SecondaryRebate { get; set; }
        public double ThirdRebate { get; set; }
        public string ModifiedUser {  get; set; }
        public Entities.StagingStatus Status { get; set; }
        public string CapturedUser { get; set; }
        public string LoggedInUser { get; set; }
    }
}
