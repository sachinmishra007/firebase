﻿
(function ()
{
    'use strict';

    angular
        .module('adminApp.services')
        .factory('productService', ['$http', function ($http)
        {
            var productService = {};

            productService.getNotesProducts = function ()
            {
                return $http({ url: 'api/ProductNotes/Products' });
            };

            productService.getProductNotes = function (productCode, language)
            {
                return $http({ url: 'api/ProductNotes/?productCode=' + productCode + '&language=' + language });
            };

            productService.getPendingProductNotes = function ()
            {
                return $http({ url: 'api/ProductNotes/Pending' });
            };

            productService.saveProductNote = function (note)
            {
                return $http.post('api/ProductNotes', note);
            };

            productService.updatePendingNotesStatus = function (notes)
            {
                return $http.post('api/ProductNotes/UpdatePendingNotesStatus', notes);
            };

            return productService;
        }]);
})();

