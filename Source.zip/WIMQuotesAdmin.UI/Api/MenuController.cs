﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.UI.Web.ActionFilters;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class MenuController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IMenuLogic _menuLogic;

        public MenuController(Domain.Logic.Contracts.IMenuLogic menuLogic)
        {
            _menuLogic = menuLogic;
        }

        #endregion

        // GET api/Menu
        public List<Entities.MenuItem> Get([ModelBinder]IPrincipal user)
        {
            if (user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return new List<Entities.MenuItem>();

            return _menuLogic.Get(user.Identity.Name);
        }
    }
}
