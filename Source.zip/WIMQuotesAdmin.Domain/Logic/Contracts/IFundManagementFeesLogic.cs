﻿
using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IFundManagementFeesLogic
    {
        List<Entities.FundManagementFees> GetFundManagementFees(Entities.FundType fundType, string fundCode);
        void StageFundManagementFees(Entities.FundManagementFees fundManagementFees, string userId);
        List<Entities.Fund> GetUnmappedFunds();
        List<Entities.FundManagementFees> GetPendingFundManagementFees();
        void PendingFundManagementFeesUpdateStatus(List<Entities.FundManagementFees> fundManagementFees, string userId);
    }
}
