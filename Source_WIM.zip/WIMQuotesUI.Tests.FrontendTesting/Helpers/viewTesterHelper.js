﻿/// <reference path="../../wimi.quotes.ui/scripts/jasmine/jasmine.js" />
/// <reference path="../../wimi.quotes.ui/scripts/common/jquery-1.10.2.js" />

(function (window)
{
    'use strict';

    window.$viewTester = function (compiledView, scope)
    {
        var viewTester = {};

        viewTester.byModel = function (propertyName)
        {
            return compiledView.find('[ng-model="' + propertyName + '"]');
        };

        viewTester.byNgShow = function (propertyName)
        {
            return compiledView.find('[ng-show="' + propertyName + '"]');
        }

        viewTester.byModelPartial = function (modelPropertyName)
        {
            return compiledView.find('[ng-model*="' + modelPropertyName + '"]');
        };

        viewTester.byClass = function (className)
        {
            return compiledView.find('.' + className);
        };

        viewTester.byRepeater = function (repeaterValue)
        {
            return compiledView.find('[ng-repeat*="' + repeaterValue + '"]');
        };

        viewTester.byButtonText = function (buttonText)
        {
            return compiledView.find(':button[value="' + buttonText + '"]');
        };

        viewTester.byNgClick = function (clickValue)
        {
            return compiledView.find('[ng-click="' + clickValue + '"]');
        };

        viewTester.byQuery = function (query)
        {
            return compiledView.find(query);
        };


        jQuery.fn.extend({
            thenByValue: function (value)
            {
                return this.filter('[value="' + value + '"]');
            },
            simulateClick: function ()
            {
                if (this.is(':radio'))
                    this.click().trigger('click');
                else
                    this.triggerHandler('click');

                scope.$digest();
            },
            setDropDownValue: function (value)
            {
                this.val(value);

                if (this.val() === null)
                    this.val('string:' + value)

                this.trigger('change').trigger('chosen:updated');

                scope.$digest();
            },
            sendKeys: function (value)
            {
                this.val(value).trigger('change');
                scope.$digest();
            }
        });


        return viewTester;
    };


    // Jasmine BDD Extensions

    var count = 1;

    window.given = function (scenarioDescription, func)
    {
        describe('Scenario ' + count++ + ': Given ' + scenarioDescription, func);
    };

    window.when = function (whenDescription, func)
    {
        describe('When ' + whenDescription, func);
    };

    window.then = function (thenDescription, func)
    {
        it('Then ' + thenDescription, func);
    };

})(window);

