﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class QuotesAdminRepository : Contracts.IQuoteAdminRepository
    {
        #region Public Methods

        public Entities.UserAccess GetUserAccess(string userId)
        {
            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                var contextMenuItems = context.pGetUserAccessibility(userId).ToList();

                if (contextMenuItems.Count == 0)
                    return null;

                var menuItems = contextMenuItems
                    .Where(v => !v.ParentId.HasValue && v.IsActive)
                    .Select(Mappings.WIMQuotesAdminMapping.ToMenuItem).ToList();

                GetMenuItemsRecursive(contextMenuItems, menuItems);

                return new Entities.UserAccess
                {
                    UserId = userId,
                    MenuItems = menuItems
                };
            }
        }

        public void SaveUser(Entities.User user, string currentSystemUser)
        {
            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                var contextUser = context.Users.FirstOrDefault(u => u.UserName == user.Id);

                if (contextUser == null)
                {
                    context.Users.Add(new DataModel.User
                    {
                        UserName = user.Id,
                        RoleId = user.Role.HasValue ? (int)user.Role : 0,
                        IsActive = user.IsActive,
                        CreatedOn = DateTime.Now,
                        SuperUser = currentSystemUser
                    });
                }
                else
                {
                    contextUser.UserName = user.Id;
                    contextUser.RoleId = user.Role.HasValue ? (int)user.Role : 0;
                    contextUser.IsActive = user.IsActive;
                    contextUser.CreatedOn = DateTime.Now;
                    contextUser.SuperUser = currentSystemUser;
                }

                context.SaveChanges();
            }
        }

        public void UpdateUserActive(string userId, bool isActive, string currentSystemUser)
        {
            if (string.IsNullOrWhiteSpace(userId) || string.IsNullOrWhiteSpace(currentSystemUser))
                return;

            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                var contextUser = context.Users.FirstOrDefault(u => u.UserName == userId);

                if (contextUser == null) 
                    return;

                contextUser.IsActive = isActive;
                contextUser.CreatedOn = DateTime.Now;
                context.SaveChanges();
            }
        }

        public List<Entities.MenuItem> GetMenuItems(string userId)
        {
            List<DataModel.UserAccessMenuItem> contextMenuItems;

            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                contextMenuItems = context.pGetMenuItems(userId).ToList();
            }

            var menuItems = contextMenuItems
                .Where(v => !v.ParentId.HasValue && v.IsActive)
                .Select(Mappings.WIMQuotesAdminMapping.ToMenuItem).ToList();

            GetMenuItemsRecursive(contextMenuItems, menuItems);

            return menuItems;
        }

        public void SaveMenuItems(List<Entities.MenuItem> menuItems, string userId, string currentSystemUser)
        {
            if (menuItems == null || menuItems.Count == 0 || string.IsNullOrWhiteSpace(userId))
                return;

            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                var contextUser = context.Users.FirstOrDefault(u => u.UserName == userId);

                if (contextUser == null || string.IsNullOrWhiteSpace(contextUser.UserName))
                    return;

                DeleteMenuItems(contextUser.Id);

                var collapsedMenuItems = new List<Entities.MenuItem>();
                collapsedMenuItems.AddRange(menuItems);
                collapsedMenuItems.AddRange(menuItems.SelectMany(m => m.Items));

                var contextMenuItems = collapsedMenuItems.Select(m => new DataModel.UserMenuItem
                {
                    MenuItemId = m.Id,
                    AccessLevelId = (int?)m.AccessLevel,
                    UserId = contextUser.Id
                });

                context.UserMenuItems.AddRange(contextMenuItems);
                context.SaveChanges();
            }
        }

        public List<Entities.User> SearchUnmappedUsers(string searchTerm)
        {
            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                var users = context.pSearchUnmappedUsers(searchTerm).ToList();
                return users.Count == 0 ? new List<Entities.User>() : users.Select(Mappings.WIMQuotesAdminMapping.ToUser).ToList();
            }
        }

        public List<Entities.User> SearchExistingUsers(string searchTerm)
        {
            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                var users = context.pSearchExistingUsers(searchTerm).ToList();
                return users.Count == 0 ? new List<Entities.User>() : users.Select(Mappings.WIMQuotesAdminMapping.ToUser).ToList();
            }
        }

        #endregion

        #region Private Methods

        private void GetMenuItemsRecursive(List<DataModel.UserAccessMenuItem> contextMenuItems, IEnumerable<Entities.MenuItem> menuItems)
        {
            foreach (var menuItem in menuItems)
            {
                menuItem.Items = contextMenuItems
                    .Where(v => v.ParentId == menuItem.Id)
                    .Select(Mappings.WIMQuotesAdminMapping.ToMenuItem).ToList();

                GetMenuItemsRecursive(contextMenuItems, menuItem.Items);
            }
        }

        private void DeleteMenuItems(int userUniqueId)
        {
            using (var context = new DataModel.WIMQuotesAdminEntities())
            {
                var existingMenuItems = context.UserMenuItems.Where(m => m.UserId == userUniqueId);

                context.UserMenuItems.RemoveRange(existingMenuItems);
                context.SaveChanges();
            }
        }

        #endregion
    }
}
