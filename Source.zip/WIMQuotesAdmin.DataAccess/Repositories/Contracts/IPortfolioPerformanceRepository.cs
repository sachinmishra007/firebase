﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IPortfolioPerformanceRepository
    {
        List<Entities.AssetClass> GetFundAssetClasses(string fundCode);
        List<Entities.AssetClass> GetAssetClassesTypes();

        //void SaveFundAssetsStaging(string fundCode, List<Entities.AssetClass> assetClasses, string userId);

        //void SaveFundAssetsStaging(Entities.FundAssets fundAssets, string userId);
        void SaveFundAssetsStaging(Entities.AssetClass assetClass,string fundCode, string userId);

        List<Entities.FundAssets> GetPendingFundAssets();
        void UpdateFundAssetsStagingStatus(string fundCode, Entities.StagingStatus status, string userId, int assetClasId);
        void SaveAuthorisedFundAsset(Entities.FundAssets fundAsset);
        void DeleteAuthorisedFundAsset(Entities.FundAssets fundAsset);

        Entities.FundAssets GetPendingFundAsset(string fundCode);

        Entities.FundAssets GetFundWithAssetClasses(string fundCode);

        List<Entities.Fund> GetAvailableWraps();

        List<Entities.Fund> GetFundsForWrap(string wrapCode);
    }
}
