﻿(function ()
{
    'use strict';

    angular.module('common.directives')
        .directive('ngInputAmount', function ()
        {
            return {
                require: '?ngModel',
                link: function (scope, element, attrs, ngModelCtrl)
                {
                    if (!ngModelCtrl)
                        return;

                    ngModelCtrl.$formatters.push(function (value)
                    {
                        var amount = parseFloat(value);
                        return (isNaN(amount) ? 0 : amount).toFixed(2);
                    });

                    ngModelCtrl.$parsers.unshift(function (value)
                    {
                        if (angular.isUndefined(value))
                            value = '';

                        var clean = value.replace(/[^0-9\.]+/g, '');

                        if (value !== clean)
                        {
                            ngModelCtrl.$setViewValue(clean);
                            ngModelCtrl.$render();
                        }

                        return Number(clean);
                    });

                    element.bind('keypress', function (event)
                    {
                        if (event.keyCode === 32)
                            event.preventDefault();
                    });

                    element.bind('blur', function ()
                    {
                        var amount = parseFloat(element.val());
                        element.val((isNaN(amount) ? 0 : amount).toFixed(2));
                    });
                }
            };
        });

})();