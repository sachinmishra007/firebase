﻿ 
(function () {
    'use strict';
     
    angular.module('quotesApp.controllers')
        .controller('incomeController', ['$scope', '$rootScope', 'lookupService', 'sectionType', function ($scope, $rootScope, lookupService, sectionType) {
            $scope.profile = {};
            if ($scope.maxPSP() > 0 && $scope.quoteItem.Product.Code === 'LIVANN') {
                $scope.frequencies = lookupService.getFrequenciesPSP();
            } else {
                $scope.frequencies = lookupService.getFrequencies();
            }
            $scope.isAmountSelected = false;

            // Behaviours 

            $scope.init = function (profile) {
                $scope.profile = profile;

                $scope.profile.ShowUseLumpSumFunds = true;

                $scope.profile.Funds = $scope.profile.Funds || [];
                $scope.profile.Frequency = $scope.profile.Frequency || $scope.frequencies[0].Code;
                $scope.profile.IncomeType = $scope.profile.IncomeType || 'Percentage';
                $scope.profile.TaxationMethod = $scope.profile.TaxationMethod || 'PAYE';

                //DEV-19457
                $scope.$ProductFieldDisplay = lookupService
                  .getDisplayLabels($scope.quoteItem.Product.Code, sectionType.sectionNames.INCOME);
            };

            $scope.calculateIncomeAmount = function () {
                $scope.profile.Amount = isNaN($scope.quoteItem.lumpSumProfile.Amount) ? 0.00 :
                    ($scope.quoteItem.lumpSumProfile.Amount * ($scope.profile.Percentage / 100.00)).toFixed(2);

                $scope.$broadcast('profile.AmountChanged', null);
            }

            $scope.calculateIncomePercentage = function () {
                $scope.profile.Percentage = isNaN($scope.quoteItem.lumpSumProfile.Amount) ? 0.00 :
                    ($scope.profile.Amount / $scope.quoteItem.lumpSumProfile.Amount * 100.00).toFixed(2);

                $scope.$broadcast('profile.AmountChanged', null);
            }

            $scope.amountChanged = function () {
                $scope.calculateIncomePercentage();
            };

            $scope.incomeTypeChanged = function () {
                $scope.isAmountSelected = $scope.profile.IncomeType !== 'Percentage';
            };


            // Events

            var lumpSumAmountChanged = $rootScope.$on('lumpSum.AmountChanged', function () {
                if ($scope.profile.IncomeType === 'Percentage') {
                    $scope.calculateIncomeAmount();
                }
                else {
                    $scope.calculateIncomePercentage();
                }
            });

            var incomeFrequencyChanged = $rootScope.$on('profile.IncomeFrequencyChanged', function (event, eventarg) {
                if (eventarg.IsAdd) {
                    $scope.frequencies = lookupService.getFrequenciesPSP();
                }
                if (eventarg.IsRemove) {
                    $scope.frequencies = lookupService.getFrequencies();
                }
            });

            // On Unload

            $scope.$on("$destroy", function () {
                lumpSumAmountChanged();
                incomeFrequencyChanged();
            });
        }]);
})();
