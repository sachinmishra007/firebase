﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class CDSBreakdownLogic : WIMQuotesAdmin.Domain.Logic.Contracts.ICDSBreakdownLogic
    {
        private readonly WIMQuotesAdmin.DataAccess.Repositories.Contracts.ICDSBreakdownRepository _CDSBreakdownRepository;

        public CDSBreakdownLogic(WIMQuotesAdmin.DataAccess.Repositories.Contracts.ICDSBreakdownRepository CDSBreakdownRepository)
        {
            _CDSBreakdownRepository = CDSBreakdownRepository;
        }



        public List<Entities.CDSBreakdownReport> GetCDSBreakdownReport(Entities.QuoteFrequencyReportDetail reportDetail)
        {
            return _CDSBreakdownRepository.GetCDSBreakdownReport(reportDetail.StartDate,reportDetail.EndDate,reportDetail.BrokerCode);
        }
    }
}
