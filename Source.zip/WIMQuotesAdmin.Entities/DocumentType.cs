﻿namespace WIMQuotesAdmin.Entities
{
    public enum DocumentType
    {
        Unspecified,
        ProductBrochure,
        ApplicationForm,
        FundFactSheet
    }
}
