﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.Domain.Logic.Contracts;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class FundPerformanceFeesLogic : IFundPerformanceFeesLogic
    {
        #region Constructor

        private readonly DataAccess.Repositories.Contracts.IFundPerformanceFeesRepository _fundPerformanceFeesRepository;
        private readonly DataAccess.Repositories.Contracts.IPortfolioAdminRepository _portfolioAdminRepository;

        public FundPerformanceFeesLogic(DataAccess.Repositories.Contracts.IFundPerformanceFeesRepository fundPerformanceFeesRepository,
            DataAccess.Repositories.Contracts.IPortfolioAdminRepository portfolioAdminRepository)
        {
            _fundPerformanceFeesRepository = fundPerformanceFeesRepository;
            _portfolioAdminRepository = portfolioAdminRepository;
        }
        #endregion

        public Entities.FundPerformanceFees GetFundPerformanceFees(string fundCode)
        {
            return _fundPerformanceFeesRepository.GetFundPerformaneFees(fundCode);
        }


        public List<Entities.Fund> GetAvailableFunds()
        {
            return _fundPerformanceFeesRepository.GetAvailablePerformanceFeeFunds();
        }


        public void SaveFundPerformanceFeesStaging(Entities.PerformanceFees performanceFees, string fundCode, string userId)
        {
            if (performanceFees == null || string.IsNullOrWhiteSpace(fundCode) || string.IsNullOrWhiteSpace(userId))
                return;

            _fundPerformanceFeesRepository.SaveFundPerformanceFeesStaging(performanceFees, fundCode, userId);
        }


        public List<Entities.Fund> GetUnmappedFunds()
        {
            return _fundPerformanceFeesRepository.GetUnmappedFunds();
        }


        public List<Entities.TimePeriod> GetMorningStarTimePeriod(string fundCode)
        {
            if (string.IsNullOrWhiteSpace(fundCode))
                return null;

            var unavailPerFees = new List<Entities.PerformanceFees>();
            var allTimePeroids = _fundPerformanceFeesRepository.GetMorningStarTimePeriod();
            var fundAuthTimePeriods = _fundPerformanceFeesRepository.GetFundPerformaneFees(fundCode).PerformanceFees;
            var pendingTimePeriods = _fundPerformanceFeesRepository.GetPendingFundPerformanceFees();

            var pendingPerformanceFees = from pendingTps in pendingTimePeriods
                                           where pendingTimePeriods.Any(x=> x.FundCode == fundCode)
                                            select  pendingTps;

           foreach(var perFees in pendingPerformanceFees)
           {
               unavailPerFees = perFees.PerformanceFees;

           }

            var unavailableTimePeriods = from availableTps in allTimePeroids
                              where !fundAuthTimePeriods.Any(x => x.TimePeriod == availableTps.TimePeriodId)
                              select availableTps;

            var unavailPending = from pendingTps in unavailableTimePeriods
                                 where !unavailPerFees.Any(x => x.TimePeriod == pendingTps.TimePeriodId)
                                 select pendingTps;

            if (unavailPerFees == null &&  unavailPerFees.Count == 0 && unavailableTimePeriods == null ||
                unavailableTimePeriods.Count() == 0)
                return null;

            return unavailPending.ToList();
        }


        public List<Entities.FundPerformanceFees> GetPendingFundPerformanceFees()
        {
            return _fundPerformanceFeesRepository.GetPendingFundPerformanceFees();
        }

        public void PendingFundPerformanceFeesAuthoriseSave(string fundCode, string userId, int timePeriod)
        {
            if (string.IsNullOrWhiteSpace(fundCode) || string.IsNullOrWhiteSpace(userId))
                return;
            var pendingFundPerformFees = _fundPerformanceFeesRepository.GetPendingFundPerformanceFees(fundCode);

            if (pendingFundPerformFees == null || pendingFundPerformFees.PerformanceFees == null || pendingFundPerformFees.PerformanceFees.Count == 0)
                return;

            var performFeeToUpdate = from updatePerfomFeeList in pendingFundPerformFees.PerformanceFees
                                     where updatePerfomFeeList.TimePeriod == timePeriod
                                     select updatePerfomFeeList;
            pendingFundPerformFees.PerformanceFees = performFeeToUpdate.ToList();
            
            _fundPerformanceFeesRepository.UpdateFundAssetsStagingStatus(fundCode,Entities.StagingStatus.Authorise ,userId, timePeriod);

            if (pendingFundPerformFees == null)
                return;

            _fundPerformanceFeesRepository.SaveAuthorisedFundAsset(pendingFundPerformFees); 

        }

        public void PendingFundPerformanceFeesAuthoriseDelete(string fundCode, string userId, int timePeriod)
        {
            if (string.IsNullOrWhiteSpace(fundCode) || string.IsNullOrWhiteSpace(userId))
                return;
            var pendingFundPerformFees = _fundPerformanceFeesRepository.GetPendingFundPerformanceFees(fundCode);

            if (pendingFundPerformFees == null || pendingFundPerformFees.PerformanceFees == null || pendingFundPerformFees.PerformanceFees.Count == 0)
                return;

            var performFeeToUpdate = from updatePerfomFeeList in pendingFundPerformFees.PerformanceFees
                                     where updatePerfomFeeList.TimePeriod == timePeriod
                                     select updatePerfomFeeList;
            pendingFundPerformFees.PerformanceFees = performFeeToUpdate.ToList();

            _fundPerformanceFeesRepository.UpdateFundAssetsStagingStatus(fundCode, Entities.StagingStatus.Authorise, userId, timePeriod);

            if (pendingFundPerformFees == null)
                return;

            _fundPerformanceFeesRepository.DeleteAuthorisedFundAsset(pendingFundPerformFees);

        }

        public void PendingFundPerformanceFeesAuthoriseReject(string fundCode, string userId, int timePeriod)
        {
            if (string.IsNullOrWhiteSpace(fundCode) || string.IsNullOrWhiteSpace(userId))
                return;
            _fundPerformanceFeesRepository.UpdateFundAssetsStagingStatus(fundCode,Entities.StagingStatus.Reject,userId,timePeriod);

        }



        public void PendingFundPerformanceFeesUpdateStatus(List<Entities.FundPerformanceFees> fundPeformanceFees, string userId)
        {
            foreach(var fundPeformanceFee in fundPeformanceFees)
            {
                foreach(var performanceFee in fundPeformanceFee.PerformanceFees)
                {
                    switch(performanceFee.Status)
                    {
                        case Entities.StagingStatus.Authorise:
                            switch(performanceFee.InstructionType)
                            {
                                case Entities.InstructionType.Add:
                                    PendingFundPerformanceFeesAuthoriseSave(fundPeformanceFee.FundCode, userId, performanceFee.TimePeriod);
                                    break;

                                case Entities.InstructionType.Update:
                                    PendingFundPerformanceFeesAuthoriseSave(fundPeformanceFee.FundCode, userId, performanceFee.TimePeriod);
                                    break;

                                case Entities.InstructionType.Delete:
                                    PendingFundPerformanceFeesAuthoriseDelete(fundPeformanceFee.FundCode, userId, performanceFee.TimePeriod);
                                    break;
                            }
                            break;
                        case Entities.StagingStatus.Reject:
                            PendingFundPerformanceFeesAuthoriseReject(fundPeformanceFee.FundCode, userId, performanceFee.TimePeriod);

                            break;
                    }
                }

            }
        }
    }
}
