﻿using System.Web.Http;

using WIMQuotesAdmin.Domain.Logic.Contracts;
using WIMQuotesAdmin.UI.Web.ActionFilters;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class IncomeRatesController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IIncomeRatesLogic _incomeRateController;

        public IncomeRatesController(IIncomeRatesLogic incomeRateController)
        {
            _incomeRateController = incomeRateController;
        }

        #endregion

        [Route("api/IncomeRates/CaptureRates")]
        public Entities.IncomeRates SaveRates(Entities.IncomeRates rates)
        {
            return _incomeRateController.CaptureRates(rates);
        }

        [Route("api/IncomeRates/AuthoriseRates")]
        public void AuthoriseRates(Entities.IncomeRates rates)
        {
            _incomeRateController.AutoriseRates(rates);
        }
        
        [Route("api/IncomeRates/GetLatestRates")]
        public Entities.IncomeRates GetLatestRates(string productCode)
        {
            return _incomeRateController.GetLatestRates(productCode);
        }

        [HttpPost]
        [Route("api/IncomeRates/RejectRates")]
        public void RejectRates([FromBody]string value)
        {
            _incomeRateController.RejectRates(value);
        }
    }
}
