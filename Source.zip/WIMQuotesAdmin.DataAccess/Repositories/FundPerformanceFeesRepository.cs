﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.DataAccess.Repositories.Contracts;

namespace WIMQuotesAdmin.DataAccess.Repositories
{
    public class FundPerformanceFeesRepository : IFundPerformanceFeesRepository
    {
        public Entities.FundPerformanceFees GetFundPerformaneFees(string fundCode)
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                return new Entities.FundPerformanceFees
                {
                    FundCode = fundCode,
                    PerformanceFees = context.GetFundPerformanceFees(fundCode).Select(p => new Entities.PerformanceFees
                    {
                        TimePeriod = p.TimePeriod,
                        ClosePrice = p.ClosePrice,
                        DateModified = p.DateModified,
                        Percentage = p.Percentage

                    }).ToList()
                };
            }
        }


        public void SaveFundPerformanceFeesStaging(Entities.PerformanceFees performanceFees, string fundCode, string userId)
        {
            if (performanceFees == null || string.IsNullOrWhiteSpace(fundCode) || string.IsNullOrWhiteSpace(userId))
                return;

            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundPerFees = Mappings.WIMQuotesAdminStagingMapping.ToFundPerformanceFeesStaging(performanceFees, fundCode, userId);
                if (contextFundPerFees == null)
                    return;
                context.FundPerformanceFeeStagings.Add(contextFundPerFees);
                context.SaveChanges();
 
            }
        }


        public List<Entities.Fund> GetUnmappedFunds()
        {
            using(var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var unmappedFunds = context.GetUnmappedFundPerformanceFeeFund();

                return unmappedFunds.Select(f => new Entities.Fund 
                {
                    Code = f.Code,
                    Name = f.Name,
                    SplitPercentage = f.PercentageSplit
                
                }).ToList();
            }
        }


        public List<Entities.TimePeriod> GetMorningStarTimePeriod()
        {
            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                var contextTimePer = context.GetMorningStarTimePeriod();
           
                return contextTimePer.Select(t => new Entities.TimePeriod
                {
                    TimePeriodId = t.TimePeriodId,
                    TimePeriodDescription = t.TimePeriodDescription
                }).ToList();
            }
        }


        public List<Entities.FundPerformanceFees> GetPendingFundPerformanceFees()
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundPerFees = context.FundPerformanceFeeStagings
                    .Where(fp=> fp.Status == (int) Entities.StagingStatus.PendingAuthorise).ToList();

                return Mappings.WIMQuotesAdminStagingMapping.FromFundPerformanceFeeStagings(contextFundPerFees);
            }
        }


        public void UpdateFundAssetsStagingStatus(string fundCode, Entities.StagingStatus status, string userId, int timePeriod)
        {
            using (var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundPerfFees = context.FundPerformanceFeeStagings
                                         .Where(
                                                    fp => fp.FundCode == fundCode && 
                                                    fp.Status == (int)Entities.StagingStatus.PendingAuthorise && 
                                                    fp.TimePeriod == timePeriod
                                                ); 

                foreach(var contextFundPerfFee in contextFundPerfFees)
                {
                    contextFundPerfFee.TimePeriod = timePeriod;
                    contextFundPerfFee.Status = (int)status;
                    contextFundPerfFee.ModifiedUserId = userId;
     
                }

                context.SaveChanges();
                       
            }
        }

        public void SaveAuthorisedFundAsset(Entities.FundPerformanceFees fundPerformanceFees)
        {
            if (fundPerformanceFees == null || fundPerformanceFees.PerformanceFees == null || fundPerformanceFees.PerformanceFees.Count == 0)
                return;
            using(var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.SaveFundPerformanceFee(Mappings.PortfolioAdminServiceMapping.ToFundPerformanceFees(fundPerformanceFees));
            }
        }



        public void DeleteAuthorisedFundAsset(Entities.FundPerformanceFees fundPerformanceFees)
        {
            if (fundPerformanceFees == null || fundPerformanceFees.PerformanceFees == null || fundPerformanceFees.PerformanceFees.Count == 0)
                return;

            using (var context = new PortfolioAdminService.PortfolioAdminServiceClient())
            {
                context.DeleteFundPerformanceFee(Mappings.PortfolioAdminServiceMapping.ToFundPerformanceFees(fundPerformanceFees));
            }
        }


        public Entities.FundPerformanceFees GetPendingFundPerformanceFees(string fundCode)
        {
            using(var context = new DataModel.WIMQuotesAdminStagingEntities())
            {
                var contextFundPerFormFees = context.FundPerformanceFeeStagings
                                            .Where(fps => fps.FundCode == fundCode && fps.Status == (int)Entities.StagingStatus.PendingAuthorise).ToList();

                var mappedFundPerfFees = Mappings.WIMQuotesAdminStagingMapping.FromFundPerformanceFeeStagings(contextFundPerFormFees);

                return mappedFundPerfFees.Count == 0 ? null : mappedFundPerfFees.FirstOrDefault();
            }
        }


        public List<Entities.Fund> GetAvailablePerformanceFeeFunds()
        {
           using(var context = new PortfolioAdminService.PortfolioAdminServiceClient())
           {
               var funds = context.GetAvailablePerformanceFeeFunds();

               return funds.Select(f => new Entities.Fund
               {
                   Code = f.Code,
                   Name = f.Name,
                   SplitPercentage = f.PercentageSplit
               }).ToList();
           }

        }
    }
}
