﻿namespace WIMQuotesAdmin.Common
{
    public struct Constants
    {
        public struct Roles
        {
            public const string SuperUser = "SuperUser";
            public const string Admin = "AdminUser";
            public const string ReadOnly = "ReadOnly";
        }

        public struct MimeTypes
        {
            public const string Pdf = "application/pdf";
        }

        public struct FileExtensions
        {
            public const string Pdf = "pdf";
        }
    }
}
