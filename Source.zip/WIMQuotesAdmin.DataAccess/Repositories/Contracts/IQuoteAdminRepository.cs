﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.DataAccess.Repositories.Contracts
{
    public interface IQuoteAdminRepository
    {
        Entities.UserAccess GetUserAccess(string userId);
        void SaveUser(Entities.User user, string currentSystemUser);
        void UpdateUserActive(string userId, bool isActive, string currentSystemUser);

        List<Entities.MenuItem> GetMenuItems(string userId);
        void SaveMenuItems(List<Entities.MenuItem> menuItems, string userId, string currentSystemUser);

        List<Entities.User> SearchUnmappedUsers(string searchTerm);
        List<Entities.User> SearchExistingUsers(string searchTerm);
    }
}
