﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ModelBinders;

namespace WIMQuotesAdmin.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class FundAssetClassesController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IAssetClassesLogic _assetClassesLogic;

        public FundAssetClassesController(Domain.Logic.Contracts.IAssetClassesLogic assetClassesLogic)
        {
            _assetClassesLogic = assetClassesLogic;
        }

        #endregion

        // GET api/FundMapping/ABMM
        [Route("api/FundAssetClasses/{fundCode}")]
        /*
        public IEnumerable<Entities.AssetClass> Get(string fundCode)    
        {
            return _assetClassesLogic.Get(fundCode);
        }
        */

        public Entities.FundAssets Get(string fundCode)
        {
            return _assetClassesLogic.GetFundAssets(fundCode);
        }



        // GET: api/FundMapping/GetAvailableFunds
        [Route("api/FundAssetClasses/GetAvailableFunds")]
        public IEnumerable<Entities.Fund> GetAvailableFunds()
        {
            return _assetClassesLogic.GetAvailableFunds();
        }

        [Route("api/FundAssetClasses/UnmappedAssetClasses/{fundCode}")]
        public IEnumerable<Entities.AssetClass> GetAssetClassTypes(string fundCode)
        {
            List<Entities.AssetClass> list =  _assetClassesLogic.GetUnmappedAssetClassesTypes(fundCode);

            return list;
        }

       // [Route("api/FundAssetClasses")]
        [AuthorizeRoles(Constants.Roles.SuperUser, Constants.Roles.Admin)]
        public void Post([FromBody] Entities.AssetClass assetClass,string fundCode ,[ModelBinder]IPrincipal user)
        {
            if (assetClass == null || string.IsNullOrWhiteSpace(fundCode) || user == null || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;

           _assetClassesLogic.SaveFundAssetsStaging(assetClass,fundCode, user.Identity.Name);
        }

        [Route("api/FundAssetClasses/Pending")]
        [AuthorizeRoles(Constants.Roles.SuperUser)]
        public List<Entities.FundAssets> GetPendingFundAssets()
        {
            return _assetClassesLogic.GetPendingFundAssets();
        }

        [HttpPost]
        [Route("api/FundAssetClasses/UpdatePendingFundAssetsStatus")]
        public void PendingFundAssetsUpdateStatus([FromBody]List<Entities.FundAssets> fundAssets, [ModelBinder(typeof(PrincipalApiModelBinder))]IPrincipal user)
        {
            if (fundAssets == null || fundAssets.Count == 0 || user.Identity == null || string.IsNullOrWhiteSpace(user.Identity.Name))
                return;
            
            _assetClassesLogic.PendingFundAssetsUpdateStatus(fundAssets, user.Identity.Name);

        }
    }
}
