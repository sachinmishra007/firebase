﻿namespace WIMQuotesAdmin.Entities
{
    public enum Platform
    {
        Intranet,
        Extranet
    }
}
