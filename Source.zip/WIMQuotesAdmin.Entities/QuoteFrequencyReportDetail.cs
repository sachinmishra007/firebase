﻿using System;

namespace WIMQuotesAdmin.Entities
{
    public class QuoteFrequencyReportDetail
    {

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public ReportType ReportType { get; set; }
        public string BrokerCode { get; set; }
    }
}
