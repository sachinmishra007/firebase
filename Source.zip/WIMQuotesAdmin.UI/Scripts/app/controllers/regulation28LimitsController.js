﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('regulation28LimitsController', ['$scope', '$timeout', 'regulation28LimitsService', function ($scope, $timeout, regulation28LimitsService)
        {
            $scope.regulation28List = [];
            $scope.pendingRegulation28List = [];

            $scope.limitNameFilter = '';
            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];

            $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' || 
                $scope.application.currentMenuItem.AccessLevel === 'AdminRights';

            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
            $scope.isViewVisible = false;


            // Private Methods

            var removePendingLimit = function (fundCode)
            {
                for (var i = 0; i < $scope.pendingRegulation28List.length; i++)
                {
                    if ($scope.pendingRegulation28List[i].FundCode === fundCode)
                        $scope.pendingRegulation28List.splice(i, 1);
                }
            }

            var filteredLimitCount = function ()
            {
                var count = 0;

                for (var i = 0; i < $scope.regulation28List.length; i++)
                {
                    if ($scope.filterLimit($scope.regulation28List[i]))
                        count++;
                }

                return count;
            };

            var retrieveLimitList = function ()
            {
                
                $scope.application.showLoading = true;

                regulation28LimitsService.getRegulation28Limits().success(function (response)
                {
                    $scope.regulation28List = response;
                    $scope.application.showLoading = false;
                });
            }

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 3000);
            }

            // On Load

            retrieveLimitList();

            if ($scope.isPendingVisible)
            {
                debugger;
                regulation28LimitsService.getPendingLimits().success(function (response)
                {
                    debugger;
                    $scope.pendingRegulation28List = response;
                    $scope.isViewVisible = response.length === 0;
                });
            }
            else
            {
                debugger;
                $scope.isViewVisible = true;
            }


            // Behaviours

            $scope.filterLimit = function (item)
            {
                return (item.Name.toLowerCase().indexOf($scope.limitNameFilter.toLowerCase()) !== -1 ||
                    item.Code.toLowerCase().indexOf($scope.limitNameFilter.toLowerCase()) !== -1);
            };

            $scope.editLimit = function (limit)
            {
                limit.OriginalValue = limit.Value;
                limit.$editMode = true;
            };

            $scope.cancelEditLimit = function (fundLimit)
            {
                fundLimit.Value = fundLimit.OriginalValue;
                fundLimit.$editMode = false;
            };

            $scope.saveEditLimit = function (limit)
            {
                debugger;
                regulation28LimitsService.stageRegulation28Limits(limit).success(function ()
                {
                    limit.Status = 'PendingAuthorise';
                    limit.$editMode = false;

                    showMessage('Regulation 28 Limits saved successfully');
                });
            };

            $scope.updatePendingStatuses = function ()
            {
                debugger;
                $scope.application.showLoading = true;

                var pendingLimits = [];

                for (var i = 0; i < $scope.pendingRegulation28List.length; i++)
                {
                    if ($scope.pendingRegulation28List[i].Status !== "PendingAuthorise")
                        pendingLimits.push($scope.pendingRegulation28List[i]);
                }

                regulation28LimitsService.updatePendingStatuses(pendingLimits).success(function ()
                {
                    for (var i = 0; i < pendingLimits.length; i++)
                    {
                        Limit(pendingLimits[i].FundCode);
                    }

                    showMessage("Selected Fund Total Expense Ratios were updated successfully");

                    if ($scope.pendingRegulation28List.length === 0)
                    {
                        $scope.isViewVisible = true;
                        $scope.regulation28List = [];
                        retrieveLimitList();
                    }

                    $scope.application.showLoading = false;
                });
            };

            $scope.setPendingLimitStatus = function (limit, status)
            {
                limit.Status = limit.Status !== status ? status : "PendingAuthorise";
            };

            $scope.anyPendingLimitSelected = function ()
            {
                for (var i = 0; i < $scope.pendingRegulation28List.length; i++)
                {
                    if ($scope.pendingRegulation28List[i].Status !== "PendingAuthorise")
                        return true;
                }

                return false;
            };

            // Pagination

            $scope.firstPage = function ()
            {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function ()
            {
                if ($scope.currentPage > 0)
                {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function ()
            {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function ()
            {
                return Math.ceil(filteredLimitCount() / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function ()
            {
                if ($scope.currentPage < $scope.pageCount())
                {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function ()
            {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function ()
            {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n)
            {
                $scope.currentPage = n;
            };

            $scope.range = function ()
            {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0)
                {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize)
                {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++)
                {
                    range.push(i);
                }

                return range;
            };
        }]);
})();