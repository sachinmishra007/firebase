﻿
(function ()
{
    'use strict';

    angular.module('adminApp.controllers')
        .controller('productNotesController', ['$scope', '$timeout', 'lookupService', 'productService', function ($scope, $timeout, lookupService, productService)
        {
            $scope.ckeditorIsReady = false;
            $scope.editingNote = undefined;
            $scope.productsList = [];
            $scope.productNotesList = [];
            $scope.pendingProductNotesList = [];

            $scope.languagesList = lookupService.getLanguages();
            $scope.selectedLanguage = $scope.languagesList[0];

            $scope.isEditable = $scope.application.userProfile.Role === 'SuperUser' ||
                $scope.application.currentMenuItem.AccessLevel === 'AdminRights';

            $scope.isPendingVisible = $scope.application.userProfile.Role === 'SuperUser';
            $scope.isViewVisible = false;


            // Private Methods

            var removePendingNote = function (noteId)
            {
                for (var i = 0; i < $scope.pendingProductNotesList.length; i++)
                {
                    if ($scope.pendingProductNotesList[i].Id === noteId)
                        $scope.pendingProductNotesList.splice(i, 1);
                }
            }

            var showMessage = function (message)
            {
                $scope.notificationMessage = message;
                $scope.showSuccessMessage = true;

                $timeout(function ()
                {
                    $scope.showSuccessMessage = false;
                }, 3000);
            }

          
            // Behaviours

            $scope.getProductNotes = function (productCode, language)
            {
                if (typeof productCode === "undefined" || productCode === null || productCode === "")
                    return;
                if (typeof language === "undefined" || language === null || language === "")
                    return;

                $scope.application.showLoading = true;

                productService.getProductNotes(productCode, language).success(function (response)
                {
                    $scope.productNotesList = response;
                    $scope.application.showLoading = false;
                });
            };

            $scope.editNoteOpen = function (note)
            {
                note.HeaderRevised = note.Header;
                note.DescriptionRevised = note.Description;

                $scope.editingNote = note;
                $scope.$editMode = true;
            };

            $scope.editNoteCancel = function (note)
            {
                note.HeaderRevised = undefined;
                note.DescriptionRevised = undefined;

                $scope.editingNote = undefined;
                $scope.$editMode = false;
            };

            $scope.editNoteSave = function (note)
            {
                note.ProductName = $scope.selectedProduct.Name;
                note.LanguageName = $scope.selectedLanguage.Name;

                productService.saveProductNote(note).success(function ()
                {
                    note.Header = note.HeaderRevised;
                    note.Description = note.DescriptionRevised;
                    note.Status = 'PendingAuthorise';

                    $scope.editingNote = undefined;
                    $scope.$editMode = false;
                });
            };

            $scope.updatePendingNotesStatus = function ()
            {
                $scope.application.showLoading = true;

                var pendingNotes = [];

                for (var i = 0; i < $scope.pendingProductNotesList.length; i++)
                {
                    if ($scope.pendingProductNotesList[i].Status !== "PendingAuthorise")
                        pendingNotes.push($scope.pendingProductNotesList[i]);
                }

                productService.updatePendingNotesStatus(pendingNotes).success(function ()
                {
                    for (var i = 0; i < pendingNotes.length; i++)
                    {
                        removePendingNote(pendingNotes[i].Id);
                    }

                    showMessage("Selected note(s) were updated successfully");

                    if ($scope.pendingProductNotesList.length === 0)
                        $scope.isViewVisible = true;

                    $scope.application.showLoading = false;
                });
            };

            $scope.setPendingNoteStatus = function (note, status)
            {
                note.Status = note.Status !== status ? status : "PendingAuthorise";
            };

            $scope.anyPendingNotesSelected = function ()
            {
                for (var i = 0; i < $scope.pendingProductNotesList.length; i++)
                {
                    if ($scope.pendingProductNotesList[i].Status !== "PendingAuthorise")
                        return true;
                }
                
                return false;
            };


            // On Load

            $scope.application.showLoading = true;

            productService.getNotesProducts().success(function (response)
            {
                $scope.productsList = response;
                $scope.application.showLoading = false;
            });

            if ($scope.isPendingVisible)
            {
                productService.getPendingProductNotes().success(function (response)
                {
                    $scope.pendingProductNotesList = response;
                    $scope.isViewVisible = response.length === 0;
                });
            }
            else
            {
                $scope.isViewVisible = true;
            }


            // Register Events

            $scope.$on("ckeditor.ready", function ()
            {
                $scope.ckeditorIsReady = true;
            });

        }]);
})();
