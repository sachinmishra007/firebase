﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMQuotesAdmin.DataAccess.SLAService;
using WIMQuotesAdmin.Domain.Logic.Contracts;
using WIMQuotesAdmin.Entities;

namespace WIMQuotesAdmin.Domain.Logic
{
    public class GrowthRatesLogic : IGrowthRatesLogic
    {
        public GrowthRates CaptureRates(GrowthRates rates)
        {
            var sla = new DataAccess.SLAService.SLAMaintenanceClient();
            var calculatedRates = sla.Capture(rates.ProductCode, rates.MaturityValue, rates.Guarantor, rates.StartDate, rates.EndDate, rates.PlacementDate, rates.MaturityDate, rates.User);
            return MapGrowthRates(calculatedRates);
        }

        public void AutoriseRates(GrowthRates rates)
        {
            var sla = new DataAccess.SLAService.SLAMaintenanceClient();
            sla.Authorise(rates.EffectiveRate1, rates.Yield, rates.StartDate, rates.ProductCode, rates.MaturityValue, rates.Guarantor, rates.EndDate, rates.PlacementDate, rates.MaturityDate, rates.User);
        }

        public Entities.GrowthRates GetLatestRates(string productCode)
        {
            var sla = new DataAccess.SLAService.SLAMaintenanceClient();
            Entities.GrowthRates rates = MapGrowthRates(sla.GetLatestRates(productCode));
            return rates;
        }

        //TODO: Move this into it's own class for growth and income to use.
        public void RejectRates(string productCode)
        {
            var sla = new DataAccess.SLAService.SLAMaintenanceClient();
            sla.RejectRates(productCode);
        }

        public Entities.GrowthRates MapGrowthRates(Dictionary<string, string> calculatedRates)
        {
            GrowthRates rates = new GrowthRates();

            if (calculatedRates.Count > 0)
            {
                rates.StartDate = Convert.ToString((from pv in calculatedRates
                    where pv.Key.Contains("startDate")
                    select pv.Value).First());

                rates.EndDate = Convert.ToString((from pv in calculatedRates
                    where pv.Key.Contains("endDate")
                    select pv.Value).First());

                rates.PlacementDate = Convert.ToString((from pv in calculatedRates
                    where pv.Key.Contains("trancheDate")
                    select pv.Value).First());

                rates.MaturityDate = Convert.ToString((from pv in calculatedRates
                    where pv.Key.Contains("MaturityDate")
                    select pv.Value).First());

                rates.User = Convert.ToString((from pv in calculatedRates
                    where pv.Key.Contains("Capturer")
                    select pv.Value).First());

                rates.Guarantor = Convert.ToString((from pv in calculatedRates
                    where pv.Key.Contains("Guarantor")
                    select pv.Value).First());

                rates.MaturityValue = Convert.ToString((from pv in calculatedRates
                    where pv.Key.Contains("AbcapMaturity")
                    select pv.Value).First());

                rates.Yield = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Yield")
                    select pv.Value).First());

                rates.TaxLossFee1 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Tax Loss Fee 1")
                    select pv.Value).First());

                rates.TaxLossFee2 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Tax Loss Fee 2")
                    select pv.Value).First());

                rates.TaxLossFee3 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Tax Loss Fee 3")
                    select pv.Value).First());

                rates.TaxLossFee4 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Tax Loss Fee 4")
                    select pv.Value).First());

                rates.EffectiveRate1 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Effective Rate 1")
                    select pv.Value).First());

                rates.EffectiveRate2 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Effective Rate 2")
                    select pv.Value).First());

                rates.EffectiveRate3 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Effective Rate 3")
                    select pv.Value).First());

                rates.EffectiveRate4 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Effective Rate 4")
                    select pv.Value).First());

                rates.UnderwriterFee1 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Underwriter Fee 1")
                    select pv.Value).First());

                rates.UnderwriterFee2 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Underwriter Fee 2")
                    select pv.Value).First());

                rates.UnderwriterFee3 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Underwriter Fee 3")
                    select pv.Value).First());

                rates.UnderwriterFee4 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Underwriter Fee 4")
                    select pv.Value).First());

                rates.AIMSFee1 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("AIMS Fee 1")
                    select pv.Value).First());

                rates.AIMSFee2 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("AIMS Fee 2")
                    select pv.Value).First());

                rates.AIMSFee3 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("AIMS Fee 3")
                    select pv.Value).First());

                rates.AIMSFee4 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("AIMS Fee 4")
                    select pv.Value).First());

                rates.AIMSFee2 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("AIMS Fee 2")
                    select pv.Value).First());

                rates.AIMSFee3 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("AIMS Fee 3")
                    select pv.Value).First());

                rates.AIMSFee4 = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("AIMS Fee 4")
                    select pv.Value).First());

                rates.SemiAnnual = Convert.ToDouble((from pv in calculatedRates
                    where pv.Key.Contains("Semi Annual")
                    select pv.Value).First());

                rates.FeeStatus = Convert.ToString((from pv in calculatedRates
                                                    where pv.Key.Contains("FeeStatus")
                                                     select pv.Value).First());
            }
            return rates;
        }
    }
}
