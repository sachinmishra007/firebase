﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
namespace WIMQuotesAdmin.Entities
{
    public class AssetClass
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal? Value { get; set; }
        public DateTime TimeStamp { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public InstructionType InstructionType { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public StagingStatus Status { get; set; }
        public string UserId { get; set; }
    }
}
