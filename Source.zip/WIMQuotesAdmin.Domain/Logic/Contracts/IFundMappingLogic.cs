﻿using System.Collections.Generic;

namespace WIMQuotesAdmin.Domain.Logic.Contracts
{
    public interface IFundMappingLogic
    {
        Entities.FundMapping Get(string fundCode);
        List<Entities.FundMapping> GetFundMappings();
        void Save(Entities.FundMapping fundMapping);
        List<Entities.FundMapping> GetPendingFundMappings();
        void StageLimit(Entities.FundMapping mapping, string userId);
        void PendingFundMappingUpdateStatus(List<Entities.FundMapping> mappings, string userId);
        List<Entities.Fund> GetUnmappedFunds();
        void DeleteFundMapping(string fundCode);
        void UpdateMSRetriveFundMapping(Entities.FundMapping mappings, string userId);
    }
}
