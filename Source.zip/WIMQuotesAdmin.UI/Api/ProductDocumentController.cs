﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using WIMQuotesAdmin.Common;
using WIMQuotesAdmin.UI.Web.ActionFilters;
using WIMQuotesAdmin.UI.Web.ActionResults;

namespace WIMQuotesAdmin.UI.Api
{
    public class ProductDocumentController : ApiController
    {
        #region Constructor

        private readonly Domain.Logic.Contracts.IProductDocumentLogic _productDocumentLogic;

        public ProductDocumentController(Domain.Logic.Contracts.IProductDocumentLogic productDocumentLogic)
        {
            _productDocumentLogic = productDocumentLogic;
        }

        #endregion

        // GET: api/ProductDocument/
        [HttpGet]
        [Route("api/ProductDocument/Document")]
        public HttpResponseMessage GetDocument(string productCode, Entities.Language language, Entities.DocumentType documentType, Entities.Platform platform)
        {
            try
            {
                if (String.IsNullOrWhiteSpace(productCode))
                    return Request.CreateResponse(HttpStatusCode.BadRequest);

                var file = _productDocumentLogic.GetProductDocumentFile(productCode, language, documentType);

                if (file == null)
                    return Request.CreateResponse(HttpStatusCode.BadRequest);

                return new FileHttpResponseMessage(file.Data, file.Name, Constants.MimeTypes.Pdf);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        [HttpGet]
        [Route("api/ProductDocument/DocumentExists")]
        public bool CheckDocumentExists(string productCode, Entities.Language language, Entities.DocumentType documentType, Entities.Platform platform)
        {
            return _productDocumentLogic.CheckDocumentExists(productCode, language, documentType, platform);
        }

        // GET api/ProductDocument/Products
        [ValidateApiAntiForgeryToken]
        [Route("api/ProductDocument/Products")]
        public List<Entities.Product> GetProducts()
        {
            return _productDocumentLogic.GetProducts();
        }
    }
}
